(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-seller-seller-module"],{

/***/ "MENS":
/*!***********************************************!*\
  !*** ./src/app/pages/seller/seller.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #5f8ff8, #ffffff);\n}\n\nion-content ion-row {\n  justify-content: center;\n}\n\nion-content ion-row ion-col {\n  background: var(--ion-color-success);\n  box-shadow: 4px 10px 30px -3px #050505;\n  min-width: 15rem;\n  max-width: 15rem;\n  height: 17rem;\n  margin: 10px;\n  text-align: center;\n  justify-content: center;\n  border-radius: 20px;\n}\n\nion-content ion-row ion-col ion-item {\n  margin: -8px;\n  text-align: center;\n  justify-content: center;\n  --background: transparent;\n}\n\nion-content ion-row ion-col ion-item ion-label {\n  font-size: 0.8rem;\n  color: var(--ion-color-light);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlbGxlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxzQ0FBQTtBQUNKOztBQUNBO0VBQ0UsMERBQUE7QUFFRjs7QUFESTtFQUNJLHVCQUFBO0FBR1I7O0FBRlE7RUFDSSxvQ0FBQTtFQUNBLHNDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBSVo7O0FBSFk7RUFDSSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtFQUNBLHlCQUFBO0FBS2hCOztBQUpnQjtFQUNJLGlCQUFBO0VBQ0EsNkJBQUE7QUFNcEIiLCJmaWxlIjoic2VsbGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFyIHtcclxuICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXN1Y2Nlc3MpO1xyXG59XHJcbmlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICM1ZjhmZjgsICNmZmZmZmYpO1xyXG4gICAgaW9uLXJvdyB7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgaW9uLWNvbCB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcclxuICAgICAgICAgICAgYm94LXNoYWRvdzogNHB4IDEwcHggMzBweCAtM3B4ICMwNTA1MDU7XHJcbiAgICAgICAgICAgIG1pbi13aWR0aDogMTVyZW07XHJcbiAgICAgICAgICAgIG1heC13aWR0aDogMTVyZW07XHJcbiAgICAgICAgICAgIGhlaWdodDogMTdyZW07XHJcbiAgICAgICAgICAgIG1hcmdpbjogMTBweDtcclxuICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgICAgICAgICAgaW9uLWl0ZW0ge1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAtOHB4O1xyXG4gICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICAgICAgaW9uLWxhYmVsIHtcclxuICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDAuOHJlbTtcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0= */");

/***/ }),

/***/ "cUCh":
/*!***********************************************!*\
  !*** ./src/app/pages/seller/seller.module.ts ***!
  \***********************************************/
/*! exports provided: SellerPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SellerPageModule", function() { return SellerPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _seller_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./seller-routing.module */ "jSFV");
/* harmony import */ var _seller_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./seller.page */ "p/XO");







let SellerPageModule = class SellerPageModule {
};
SellerPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _seller_routing_module__WEBPACK_IMPORTED_MODULE_5__["SellerPageRoutingModule"]
        ],
        declarations: [_seller_page__WEBPACK_IMPORTED_MODULE_6__["SellerPage"]]
    })
], SellerPageModule);



/***/ }),

/***/ "jSFV":
/*!*******************************************************!*\
  !*** ./src/app/pages/seller/seller-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: SellerPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SellerPageRoutingModule", function() { return SellerPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _seller_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./seller.page */ "p/XO");




const routes = [
    {
        path: '',
        component: _seller_page__WEBPACK_IMPORTED_MODULE_3__["SellerPage"]
    }
];
let SellerPageRoutingModule = class SellerPageRoutingModule {
};
SellerPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SellerPageRoutingModule);



/***/ }),

/***/ "p/XO":
/*!*********************************************!*\
  !*** ./src/app/pages/seller/seller.page.ts ***!
  \*********************************************/
/*! exports provided: SellerPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SellerPage", function() { return SellerPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_seller_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./seller.page.html */ "ssBt");
/* harmony import */ var _seller_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./seller.page.scss */ "MENS");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/provider/apicall.service */ "G1p3");
/* harmony import */ var src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/provider/global.service */ "Lb7+");








let SellerPage = class SellerPage {
    constructor(router, menu, apicall, global) {
        this.router = router;
        this.menu = menu;
        this.apicall = apicall;
        this.global = global;
    }
    ngOnInit() {
        this.global.Detail.subscribe(res => {
            this.data = res;
        });
    }
    adddetail() {
        this.router.navigate(['type']);
    }
};
SellerPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["MenuController"] },
    { type: src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_6__["ApicallService"] },
    { type: src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_7__["GlobalService"] }
];
SellerPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-seller',
        template: _raw_loader_seller_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_seller_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SellerPage);



/***/ }),

/***/ "ssBt":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/seller/seller.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Dairy Links</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-row color=\"success\" >\n    <ion-col *ngFor=\"let data of data\" >\n      <ion-item text-center lines=\"none\"><ion-label>Medicine Name:{{data.name}}</ion-label></ion-item>\n      <ion-item text-center lines=\"none\"><ion-label>Quantity:{{data.quantity}}</ion-label></ion-item>\n      <ion-item text-center lines=\"none\"><ion-label>Packing Name:{{data.packing}}</ion-label></ion-item>\n      <ion-item text-center lines=\"none\"><ion-label>Purchasing Price:{{data.purchasing}}</ion-label></ion-item>\n      <ion-item  text-center lines=\"none\"><ion-label>Selling Price:{{data.selling}}</ion-label></ion-item>\n      <ion-item text-center lines=\"none\"><ion-label>Practioner Price:{{data.practioner}}</ion-label></ion-item>\n      <ion-item text-center lines=\"none\"><ion-label>Expiry:{{data.expiry}}</ion-label></ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-fab horizontal=\"end\" vertical=\"bottom\" slot=\"fixed\">\n    <ion-fab-button color=\"dark\" (click)=\"adddetail()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=pages-seller-seller-module-es2015.js.map