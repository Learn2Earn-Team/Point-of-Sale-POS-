(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"],{

/***/ "Aluc":
/*!*******************************************!*\
  !*** ./src/app/provider/alert.service.ts ***!
  \*******************************************/
/*! exports provided: AlertService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AlertService", function() { return AlertService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "TEn/");



let AlertService = class AlertService {
    constructor(Alert, nav) {
        this.Alert = Alert;
        this.nav = nav;
    }
    loginAlert() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Welcome',
                message: 'Your Are Successfully Login',
                buttons: [
                    {
                        text: 'Okay',
                    }
                ]
            });
            yield alert.present();
        });
    }
    signup() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Congrats',
                subHeader: 'Your Are Successfully Registered',
                message: 'Now please Login',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    password() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Sorry',
                message: 'Password not Matched',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    email() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Wooow',
                subHeader: 'Oops!',
                message: 'Invalid Email',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    invalidlogin() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Wooow',
                subHeader: 'Oops!',
                message: 'Invalid User name or Password',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    connection() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Ooops',
                subHeader: 'Check your Internet connection',
                message: 'Connection failed!',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    invalidpass() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Ooops',
                subHeader: 'please inter Valid password',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    call(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Al Nafay',
                subHeader: message,
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    country() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Sorry',
                message: 'Sorry We Dont Deliver to Any Country Except Orange',
                buttons: [{
                        text: 'Okay',
                        handler: () => {
                            this.nav.navigateForward('/Home');
                        },
                    }]
            });
            yield alert.present();
        });
    }
    allready() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Ooops',
                subHeader: 'This Email is Already Exist',
                message: 'Please login',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    oldincorrect() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Ooops',
                subHeader: 'Old Password Incorrect',
                message: 'Please Try Again',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    newmatch() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Ooops',
                subHeader: 'New Passwords Dont Match',
                message: 'Try Again',
                buttons: ['Ok']
            });
            yield alert.present();
        });
    }
    updateprofile() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Succesfull',
                subHeader: 'Profile updated',
                buttons: [
                    {
                        text: 'Okay',
                        handler: () => {
                            this.nav.navigateForward('/tabs/tab3');
                        },
                    }
                ]
            });
            yield alert.present();
        });
    }
    passupdate() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Succesfull',
                subHeader: 'Password updated',
                buttons: [
                    {
                        text: 'Okay',
                        handler: () => {
                            this.nav.navigateForward('/editprofile');
                        },
                    }
                ]
            });
            yield alert.present();
        });
    }
    addpost() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Succesfull',
                subHeader: 'Your Add has Been Posted',
                buttons: [
                    {
                        text: 'Okay',
                        handler: () => {
                            this.nav.navigateForward('/tabs/tab3');
                        },
                    }
                ]
            });
            yield alert.present();
        });
    }
    services() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Ooops',
                subHeader: 'please select appropriate services related  sub service',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
};
AlertService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] }
];
AlertService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AlertService);



/***/ }),

/***/ "G1p3":
/*!*********************************************!*\
  !*** ./src/app/provider/apicall.service.ts ***!
  \*********************************************/
/*! exports provided: ApicallService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApicallService", function() { return ApicallService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./auth.service */ "nCAS");
/* harmony import */ var _global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./global.service */ "Lb7+");
/* harmony import */ var _alert_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./alert.service */ "Aluc");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "tyNb");







let ApicallService = class ApicallService {
    constructor(router, menuCtrl, authservice, global, Alert, navigate) {
        this.router = router;
        this.menuCtrl = menuCtrl;
        this.authservice = authservice;
        this.global = global;
        this.Alert = Alert;
        this.navigate = navigate;
    }
    api_login(signin) {
        this.authservice.con(signin, 'login').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res));
            if (this.response.error === false) {
                console.log(this.response);
                this.global.set_User(this.response.user);
                this.Alert.loginAlert();
                this.navigate.navigateForward("/start");
                return;
            }
            this.Alert.invalidlogin();
            console.log(this.response.error);
            // tslint:disable-next-line: whitespace
        }), (err) => { this.Alert.connection(); });
    }
    api_getmedicinedetail() {
        this.authservice.getdata('getmedicine').then((result) => {
            this.data = JSON.parse(String(result));
            this.data = this.data.filter(data => data.total_quantity > 0);
            this.global.set_Medicinedetail(this.data);
            console.log(this.data, "data Updated");
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getmedicine() {
        this.authservice.getdata('getmedicine').then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Medicine(this.data);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getcustomerdetails(id) {
        this.authservice.getdata('getcustomerdetail/' + id).then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Customerdetails(this.data);
            // this.router.navigate(['customerdetail']);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getbankdetail(id) {
        this.authservice.getdata('getbankdetail/' + id).then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Bankdetail(this.data);
            // this.router.navigate(['customerdetail']);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getemployeedetail(id) {
        this.authservice.getdata('getemployeedetail/' + id).then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Employeedetails(this.data);
            // this.router.navigate(['customerdetail']);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getsellerdetails(id) {
        this.authservice.getdata('getsellerdetail/' + id).then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Sellerdetails(this.data);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getdetail(id) {
        this.authservice.getdata('getmedicinedetail/' + id).then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Detail(this.data);
            console.log(this.data);
            this.router.navigate(['seller']);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getexpensesdetail(id) {
        this.authservice.getdata('getexpensesdetail/' + id).then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Expensedetail(this.data);
            this.global.set_Ids(id);
            console.log(this.data);
            this.router.navigate(['expense']);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_gettype() {
        this.authservice.getdata('gettype').then((result) => {
            this.global.set_Type(JSON.parse(String(result)));
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_addtype(data) {
        this.authservice.con(data, 'inserttype').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Type Added");
                this.api_gettype();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_insertexpensedetail(data) {
        this.authservice.con(data, 'insertexpensedetail').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Data Added");
                this.api_getexpensesdetail(data.id);
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_adddetail(data) {
        this.authservice.con(data, 'insertmedicinedetail').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Data Added");
                this.router.navigate(['medicine']);
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_addorder(data) {
        this.authservice.con(data, 'addorder').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New order Added");
                this.global.set_Cart(null);
                this.router.navigate(['main']);
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_addorderemp(data) {
        this.authservice.con(data, 'addorderemp').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New order Added");
                this.global.set_Cart(null);
                this.router.navigate(['main']);
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_getcustomer() {
        this.authservice.getdata('getcustomer').then((result) => {
            this.global.set_Customer(JSON.parse(String(result)));
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getbanks() {
        this.authservice.getdata('getbank').then((result) => {
            this.global.set_Bank(JSON.parse(String(result)));
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getemployee() {
        this.authservice.getdata('getemployee').then((result) => {
            this.global.set_Employee(JSON.parse(String(result)));
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getexpense() {
        this.authservice.getdata('getexpenses').then((result) => {
            this.global.set_Expense(JSON.parse(String(result)));
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_addexpense(data) {
        this.authservice.con(data, 'insertexpense').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Expense Added");
                this.api_getexpense();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_addcustomer(data) {
        this.authservice.con(data, 'insertcustomer').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Customer Added");
                this.api_getcustomer();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_addbank(data) {
        this.authservice.con(data, 'insertbank').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Bank Added");
                this.api_getbanks();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_addbankdetail(data) {
        this.authservice.con(data, 'insertbankdetail').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Bank Detail Added");
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    detail(data) {
        this.authservice.con(data, 'insertbankdetail').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Bank Detail Added");
                // this.api_getbanks();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_addemployer(data) {
        this.authservice.con(data, 'insertemployee').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Employee Added");
                this.api_getemployee();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_insertmedicine(data) {
        this.authservice.con(data, 'insertmedicine').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Medicine Added");
                this.api_gettype();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_deletetype(data) {
        this.authservice.con(data, 'deletetype').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("Type Deleted");
                this.api_gettype();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_deleteexpense(data) {
        this.authservice.con(data, 'deleteexpense').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("Expense Deleted");
                this.api_getexpense();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_getcompany() {
        this.authservice.getdata('getcompany').then((result) => {
            this.global.set_Company(JSON.parse(String(result)));
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_addcompany(data) {
        this.authservice.con(data, 'insertcompany').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Company Added");
                this.api_getcompany();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_deletecompany(data) {
        this.authservice.con(data, 'deletecompany').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("Company Deleted");
                this.api_getcompany();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_getseller() {
        this.authservice.getdata('getseller').then((result) => {
            this.global.set_Seller(JSON.parse(String(result)));
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_addseller(data) {
        this.authservice.con(data, 'insertseller').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Seller Added");
                this.api_getseller();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_deleteseller(data) {
        this.authservice.con(data, 'deleteseller').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("Seller Deleted");
                this.api_getseller();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_getinvoices() {
        this.authservice.getdata('getinvoices').then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Invoice(this.data);
            console.log(this.data);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getinvoicespur() {
        this.authservice.getdata('getinvoicespur').then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Invoicepur(this.data);
            console.log(this.data);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getinvoicesemp() {
        this.authservice.getdata('getinvoicesemp').then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Invoiceemp(this.data);
            console.log(this.data);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getinvoicedetail(id) {
        this.authservice.getdata('getinvoicedetail/' + id).then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Invoicedetail(this.data);
            console.log(this.data);
            //this.router.navigate(['detail']);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getinvoicedetailpur(id) {
        this.authservice.getdata('getinvoicedetailpur/' + id).then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Invoicedetail(this.data);
            console.log(this.data);
            //this.router.navigate(['detail']);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getinvoicedetailemp(id) {
        this.authservice.getdata('getinvoicedetailemp/' + id).then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Invoicedetail(this.data);
            console.log(this.data);
            //this.router.navigate(['detail']);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_showtransaction(data) {
        this.authservice.con(data, 'gettransaction').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.data = JSON.parse(String(res));
            this.global.set_Transactiondetail(this.data);
            // this.router.navigate(['detail']);
        }), (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_showmedidetail(data) {
        this.authservice.con(data, 'showdetail11').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.data = JSON.parse(String(res));
            this.global.set_Detail(this.data);
            console.log(this.data);
            this.router.navigate(['seller']);
        }), (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getcustomerbalance(id) {
        this.authservice.getdata('getcustomerbalance/' + id).then((result) => {
            this.data = JSON.parse(String(result));
            // this.global.set_Customerdetails(this.data);
            //this.router.navigate(['customerdetail']);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_updatecustomerbalance(data) {
        this.authservice.con(data, 'updatecustomerbalance').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.data = JSON.parse(String(res));
            this.router.navigate(['company']);
        }), (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_updateemployeebalance(data) {
        this.authservice.con(data, 'updateemployeebalance').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.data = JSON.parse(String(res));
            this.router.navigate(['company']);
        }), (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_updatesellerbalance(data) {
        this.authservice.con(data, 'updatesellerrbalance').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.data = JSON.parse(String(res));
            this.router.navigate(['company']);
        }), (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_salereturn(data) {
        this.authservice.con(data, 'salereturn').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.data = JSON.parse(String(res));
        }), (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_salereturnemp(data) {
        this.authservice.con(data, 'salereturnemp').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.data = JSON.parse(String(res));
        }), (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getpurchase(id) {
        this.authservice.getdata('getpurchasedetail/' + id).then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Purchasedetail(this.data);
            console.log(this.data);
            //this.router.navigate(['detail']);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_purchasereturn(data) {
        this.authservice.con(data, 'purchasereturn').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.data = JSON.parse(String(res));
        }), (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_inserthistory(data) {
        this.authservice.con(data, 'inserthistory').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                return;
            }
        }), (err) => {
            console.log(err);
        });
    }
    api_purchasemedicine(data) {
        this.authservice.con(data, 'addpurchase').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                return;
            }
        }), (err) => {
            console.log(err);
        });
    }
    api_totalpurchase(data) {
        this.authservice.con(data, 'gettotalsale').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.data = JSON.parse(String(res));
            this.global.set_Totalsale(this.data);
        }), (err) => {
            this.Alert.connection();
            console.log(err);
        });
        this.authservice.con(data, 'gettotalexpense').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.data = JSON.parse(String(res));
            this.global.set_Totalex(this.data);
        }), (err) => {
            this.Alert.connection();
            console.log(err);
        });
        this.authservice.con(data, 'gettotalpurchase').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.data = JSON.parse(String(res));
            this.global.set_Totalpur(this.data);
        }), (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_updatemedicine(data) {
        this.authservice.con(data, 'updatemedicine').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                return;
            }
        }), (err) => {
            console.log(err);
        });
    }
    // update apis data
    api_updatecompany(data) {
        this.authservice.con(data, 'updatecompany').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call('Data Updated Succfully');
                this.api_getcompany();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_updatetype(data) {
        this.authservice.con(data, 'updatetype').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call('Data Updated Succfully');
                this.api_gettype();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_updateseller(data) {
        this.authservice.con(data, 'updateseller').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call('Data Updated Succfully');
                this.api_getcompany();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
};
ApicallService.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["MenuController"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"] },
    { type: _global_service__WEBPACK_IMPORTED_MODULE_3__["GlobalService"] },
    { type: _alert_service__WEBPACK_IMPORTED_MODULE_4__["AlertService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] }
];
ApicallService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ApicallService);



/***/ }),

/***/ "nCAS":
/*!******************************************!*\
  !*** ./src/app/provider/auth.service.ts ***!
  \******************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "tk/3");



//const apiUrl = 'http://localhost/dairylinks/public/';
const apiUrl = 'https://Learn2earnn.com/dairylinks/public/';
let AuthService = class AuthService {
    constructor(http) {
        this.http = http;
    }
    con(data, type) {
        return new Promise((resolve, reject) => {
            this.http.post(apiUrl + type, JSON.stringify(data)).
                subscribe(res => {
                resolve(JSON.stringify(res));
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    // geting posts
    getdata(type) {
        return new Promise((resolve, reject) => {
            this.http.get(apiUrl + type).
                subscribe(res => {
                resolve(JSON.stringify(res));
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
AuthService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AuthService);



/***/ })

}]);
//# sourceMappingURL=default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac-es2015.js.map