(function () {
  function _objectDestructuringEmpty(obj) { if (obj == null) throw new TypeError("Cannot destructure undefined"); }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-employeedetail-employeedetail-module"], {
    /***/
    "/O/j":
    /*!*****************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/employeedetail/employeedetail.page.html ***!
      \*****************************************************************************************************/

    /*! exports provided: default */

    /***/
    function OJ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Employee Ledger</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <table>\n    <thead>\n    <tr>\n      <th style=\"background: #333; \">Date</th>\n      <th style=\"background: #333; \">Invoice ID</th>\n      <th style=\"background: rgb(4, 151, 70); \">Debit</th>\n      <th style=\"background: rgb(204, 13, 13); \">Credit</th>\n      <th style=\"background: rgb(204, 13, 13); \">Net Balance</th>\n    </tr>\n    </thead>\n    <tbody>\n\n    <tr *ngFor=\"let a of data\">\n      <td>{{a.other}}</td>\n      <td (click)=\"getdetail(a.invoice_id)\">{{a.invoice_id}}</td>\n      <td>{{a.credit}}</td>\n      <td>{{a.debit}}</td>\n      <td>{{a.net_balance}}</td>\n      <!--       <ion-button style=\"margin: 1px\" (click)=\"updatecustomerbalance(a)\"></ion-button>-->\n    </tr>\n    </tbody>\n  </table>\n  <ion-item style=\"--background: transparent;\">\n    <ion-label style=\"width: 80%;\">\n      Recevied\n    </ion-label>\n    <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"rece\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n  </ion-item>\n  <ion-button  expand=\"block\" color=\"success\" style=\"margin:10px;height:2.5rem\" (click) = updatecustomerbalance()>Total</ion-button>\n\n</ion-content>\n";
      /***/
    },

    /***/
    "YadB":
    /*!***************************************************************!*\
      !*** ./src/app/pages/employeedetail/employeedetail.page.scss ***!
      \***************************************************************/

    /*! exports provided: default */

    /***/
    function YadB(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #5f8ff8, #ffffff);\n  /* Zebra striping */\n}\n\n@media screen and (max-width: 550px) {\n  ion-content td, ion-content th {\n    font-size: 14px;\n  }\n}\n\n@media screen and (max-width: 500px) {\n  ion-content td, ion-content th {\n    font-size: 12px;\n  }\n}\n\n@media screen and (max-width: 450px) {\n  ion-content td, ion-content th {\n    font-size: 11px;\n  }\n}\n\n@media screen and (max-width: 400px) {\n  ion-content td, ion-content th {\n    font-size: 10px;\n  }\n}\n\n@media screen and (max-width: 370px) {\n  ion-content td, ion-content th {\n    font-size: 9px;\n  }\n}\n\nion-content table {\n  width: 100%;\n  border-collapse: collapse;\n}\n\nion-content tr:nth-of-type(odd) {\n  background: #eee;\n}\n\nion-content th {\n  background: #333;\n  color: white;\n}\n\nion-content td, ion-content th {\n  padding: 3px;\n  border: 1px solid #ccc;\n  text-align: left;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL2VtcGxveWVlZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHNDQUFBO0FBQ0Y7O0FBQ0E7RUFDRSwwREFBQTtFQStCQSxtQkFBQTtBQTVCRjs7QUFGRTtFQUNFO0lBQ0UsZUFBQTtFQUlKO0FBQ0Y7O0FBRkU7RUFDRTtJQUNFLGVBQUE7RUFJSjtBQUNGOztBQUZFO0VBQ0U7SUFDRSxlQUFBO0VBSUo7QUFDRjs7QUFGRTtFQUNFO0lBQ0UsZUFBQTtFQUlKO0FBQ0Y7O0FBRkU7RUFDRTtJQUNFLGNBQUE7RUFJSjtBQUNGOztBQURFO0VBQ0UsV0FBQTtFQUNBLHlCQUFBO0FBR0o7O0FBQUU7RUFDRSxnQkFBQTtBQUVKOztBQUFFO0VBQ0UsZ0JBQUE7RUFDQSxZQUFBO0FBRUo7O0FBQUU7RUFDRSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxnQkFBQTtBQUVKIiwiZmlsZSI6ImVtcGxveWVlZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFyIHtcclxuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjNWY4ZmY4LCAjZmZmZmZmKTtcclxuICBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA1NTBweCkge1xyXG4gICAgdGQsdGggIHtcclxuICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgfVxyXG4gIH1cclxuICBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgdGQsdGggIHtcclxuICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgfVxyXG4gIH1cclxuICBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA0NTBweCkge1xyXG4gICAgdGQsdGggIHtcclxuICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgfVxyXG4gIH1cclxuICBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA0MDBweCkge1xyXG4gICAgdGQsdGggIHtcclxuICAgICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgfVxyXG4gIH1cclxuICBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAzNzBweCkge1xyXG4gICAgdGQsdGggIHtcclxuICAgICAgZm9udC1zaXplOiA5cHg7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB0YWJsZSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XHJcbiAgfVxyXG4gIC8qIFplYnJhIHN0cmlwaW5nICovXHJcbiAgdHI6bnRoLW9mLXR5cGUob2RkKSB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZWVlO1xyXG4gIH1cclxuICB0aCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjMzMzO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gIH1cclxuICB0ZCwgdGgge1xyXG4gICAgcGFkZGluZzogM3B4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgfVxyXG5cclxufVxyXG4iXX0= */";
      /***/
    },

    /***/
    "dr1m":
    /*!***************************************************************!*\
      !*** ./src/app/pages/employeedetail/employeedetail.module.ts ***!
      \***************************************************************/

    /*! exports provided: EmployeedetailPageModule */

    /***/
    function dr1m(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EmployeedetailPageModule", function () {
        return EmployeedetailPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _employeedetail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./employeedetail-routing.module */
      "sulr");
      /* harmony import */


      var _employeedetail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./employeedetail.page */
      "sVWB");

      var EmployeedetailPageModule = function EmployeedetailPageModule() {
        _classCallCheck(this, EmployeedetailPageModule);
      };

      EmployeedetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _employeedetail_routing_module__WEBPACK_IMPORTED_MODULE_5__["EmployeedetailPageRoutingModule"]],
        declarations: [_employeedetail_page__WEBPACK_IMPORTED_MODULE_6__["EmployeedetailPage"]]
      })], EmployeedetailPageModule);
      /***/
    },

    /***/
    "sVWB":
    /*!*************************************************************!*\
      !*** ./src/app/pages/employeedetail/employeedetail.page.ts ***!
      \*************************************************************/

    /*! exports provided: EmployeedetailPage */

    /***/
    function sVWB(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EmployeedetailPage", function () {
        return EmployeedetailPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_employeedetail_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./employeedetail.page.html */
      "/O/j");
      /* harmony import */


      var _employeedetail_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./employeedetail.page.scss */
      "YadB");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../provider/apicall.service */
      "G1p3");
      /* harmony import */


      var _provider_global_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../provider/global.service */
      "Lb7+");

      var EmployeedetailPage = /*#__PURE__*/function () {
        function EmployeedetailPage(loadingController, alert, router, menu, apicall, global) {
          _classCallCheck(this, EmployeedetailPage);

          this.loadingController = loadingController;
          this.alert = alert;
          this.router = router;
          this.menu = menu;
          this.apicall = apicall;
          this.global = global;
          this.history = {
            invoice_id: null,
            name: 'customer',
            type: null,
            quantity: null,
            action: null,
            user: null
          };
          this.updatedetail = {
            customer_id: '',
            net_balance: '',
            received: ''
          };
        }

        _createClass(EmployeedetailPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.global.Employeedetails.subscribe(function (res) {
              console.log(res);
              _this.data = res;
              _this.last = _this.data[_this.data.length - 1]; // console.log(this.last.net_balance);
            });
          } // getdetail(invoice_id) {
          //   this.apicall.api_getinvoicedetail(invoice_id);
          //   console.log(invoice_id);
          // }
          // async updatecustomerbalance()
          // {
          //   this.updatedetail.customer_id = this.data[0].customer_id;
          //   this.updatedetail.net_balance = this.last.net_balance;
          //   this.global.User.subscribe(res => {
          //     this.history.user = res.username;
          //   });
          //   this.updatedetail.received = this.rece;
          //   console.log(this.updatedetail);
          //   this.apicall.api_updatecustomerbalance(this.updatedetail);
          //   this.history.invoice_id = this.data[0].invoice_id;
          //   this.history.type = this.data[0].customer_name ;
          //   this.history.action = 'get balance';
          //   this.history.quantity = this.rece;
          //   this.global.User.subscribe(res => {
          //     this.history.user = res.username;
          //   });
          //   this.apicall.api_inserthistory(this.history);
          // }

        }, {
          key: "presentLoadingWithOptions",
          value: function presentLoadingWithOptions() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var loading, _yield$loading$onDidD;

              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.loadingController.create({
                        spinner: "circular",
                        duration: 200,
                        message: 'Order Is Being Placed',
                        translucent: true,
                        cssClass: 'custom-class custom-loading',
                        backdropDismiss: true
                      });

                    case 2:
                      loading = _context.sent;
                      _context.next = 5;
                      return loading.present();

                    case 5:
                      _context.next = 7;
                      return loading.onDidDismiss();

                    case 7:
                      _yield$loading$onDidD = _context.sent;

                      _objectDestructuringEmpty(_yield$loading$onDidD);

                    case 9:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }]);

        return EmployeedetailPage;
      }();

      EmployeedetailPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"]
        }, {
          type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_6__["ApicallService"]
        }, {
          type: _provider_global_service__WEBPACK_IMPORTED_MODULE_7__["GlobalService"]
        }];
      };

      EmployeedetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-employeedetail',
        template: _raw_loader_employeedetail_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_employeedetail_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], EmployeedetailPage);
      /***/
    },

    /***/
    "sulr":
    /*!***********************************************************************!*\
      !*** ./src/app/pages/employeedetail/employeedetail-routing.module.ts ***!
      \***********************************************************************/

    /*! exports provided: EmployeedetailPageRoutingModule */

    /***/
    function sulr(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EmployeedetailPageRoutingModule", function () {
        return EmployeedetailPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _employeedetail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./employeedetail.page */
      "sVWB");

      var routes = [{
        path: '',
        component: _employeedetail_page__WEBPACK_IMPORTED_MODULE_3__["EmployeedetailPage"]
      }];

      var EmployeedetailPageRoutingModule = function EmployeedetailPageRoutingModule() {
        _classCallCheck(this, EmployeedetailPageRoutingModule);
      };

      EmployeedetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], EmployeedetailPageRoutingModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-employeedetail-employeedetail-module-es5.js.map