(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-cart-cart-module"], {
    /***/
    "2Cor":
    /*!*********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/cart/cart.page.html ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function Cor(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Cart</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-segment color=\"dark\" [(ngModel)]=\"sign\">\n    <ion-segment-button value=\"customer\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Customer</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"employee\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Employee</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n  <div color=\"success\" class=\"main\" [ngSwitch]=\"sign\">\n    <ion-list class=\"f\" *ngSwitchCase=\"'customer'\">\n    <ion-item lines=\"none\" class=\"option\">\n    <ion-label>Customer Name</ion-label>\n<!--    <ion-select name=\"customer_id\" [(ngModel)]=\"customer_id\" interface=\"action-sheet\">-->\n<!--      <ion-select-option value={{a.customer_id}} *ngFor=\"let a of customer\">{{a.name}}</ion-select-option>-->\n<!--    </ion-select>-->\n\n      <ionic-selectable\n              [(ngModel)]=\"customer_id\"\n              [items]=\"customer\"\n              itemValueField=\"customer_id\"\n              itemTextField=\"name\"\n              [canSearch]=\"true\"\n              [ngModelOptions]=\"{standalone: true}\"\n              >\n      </ionic-selectable>\n\n\n  </ion-item>\n      <ion-item style=\"--background: transparent;\">\n        <ion-label style=\"width: 30%;\">\n          Enter The Custome Invoice ID\n        </ion-label>\n        <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"invoice_idc\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n      </ion-item>\n<ion-item>\n  <ion-label style=\"width: 30%;\">\n    Enter the Date\n  </ion-label>\n   <ion-datetime display-format=\"YYYY-MM-DD\" min=\"2000-01-01\" max=\"2100-10-31\" picker-format=\"YYYY-MM-DD\" name=\"date\" [(ngModel)]=\"date\">Select Date</ion-datetime>\n</ion-item>\n  <table>\n    <thead>\n    <tr>\n      <th>Product Name</th>\n      <th>Packing Size</th>\n      <th>Quantity</th>\n      <th>Unit Price</th>\n      <th>Purchasing</th>\n      <th>Partitioner</th>\n      <th>Net Ammount</th>\n      <th>Remove</th>\n    </tr>\n    </thead>\n    <tbody>\n\n    <tr *ngFor=\"let a of cart ; let i = index\">\n      <td>{{a.name}}</td>\n      <td>{{a.packing}}</td>\n      <td>\n        <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.number\"></ion-input>\n      </td>\n      <td>{{a.selling}}</td>\n      <td>{{a.purchasing}}</td>\n      <td>{{a.practioner}}</td>\n      <td>\n        <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.price\"></ion-input>\n      </td>\n\n      <td><ion-button (click)=\"remove(i)\" color=\"success\" style=\"margin:2px;\">Remove</ion-button></td>\n    </tr>\n    </tbody>\n  </table>\n  <ion-button (click)=\"total()\" expand=\"block\" color=\"success\" style=\"margin:10px;height:2.5rem\">Total</ion-button>\n  <ion-item *ngIf=\"to!=0\"  style=\"--background: transparent;\">\n    <ion-label >\n      Total\n    </ion-label>\n    <ion-label text-right >\n      {{to}}\n    </ion-label>\n  </ion-item>\n      <ion-item>\n        <ion-label>Bank Receive</ion-label>\n        <ion-toggle name=\"blueberry\" (ionChange)=\"togle()\" checked [(ngModel)]=\"banks\" ></ion-toggle>\n      </ion-item>\n  <ion-list style=\"--background: transparent;\" *ngIf=\"banks == 'true'\">\n    <ion-item lines=\"none\" class=\"option\">\n      <ion-label>Select Bank</ion-label>\n      <ion-select name=\"b_id\" [(ngModel)]=\"this.bank.b_id\" interface=\"action-sheet\" (ionChange)=\"change()\">\n        <ion-select-option value={{a.b_id}} *ngFor=\"let a of bankname\">{{a.name}}</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item style=\"--background: transparent;\">\n      <ion-label style=\"width: 30%;\">\n        Bank Name / Title\n      </ion-label>\n      <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"bank.name\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n    </ion-item>\n<!--    <ion-item style=\"&#45;&#45;background: transparent;\">-->\n<!--      <ion-label style=\"width: 30%;\">-->\n<!--        Acc Title-->\n<!--      </ion-label>-->\n<!--      <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"bank.title\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>-->\n<!--    </ion-item>-->\n<!--    <ion-item style=\"&#45;&#45;background: transparent;\">-->\n<!--      <ion-label style=\"width: 30%;\">-->\n<!--        Acc no-->\n<!--      </ion-label>-->\n<!--      <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"bank.no\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>-->\n<!--    </ion-item>-->\n    <ion-item style=\"--background: transparent;\">\n      <ion-label style=\"width: 30%;\">\n        Received Ammount\n      </ion-label>\n      <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"bank.recei\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n    </ion-item>\n  </ion-list>\n      <ion-item style=\"--background: transparent;\" *ngIf=\"banks == 'false'\">\n        <ion-label style=\"width: 30%;\">\n          Received Ammount\n        </ion-label>\n        <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"bank.recei\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n      </ion-item>\n      <button\n              [printStyle]=\"{ div : {'color': 'black' } ,img : {'height':'180px' , 'width':'180px', 'margin-left': '20%'} , p:{'font-size': '14px' , 'color':'black' , 'font-weight': 'bold' } , th : {'font-size' : '14px' , 'color': 'black' , 'text-align': 'center' , 'border': '1px solid grey'} , td : {'font-size' : '14px' , 'color': 'black' , 'text-align': 'center' , 'border': '1px solid grey'} , h6: {'text-align': 'center' , 'margin-top' : '0px'} , visit : {'text-align': 'center'}}\"\n              printSectionId=\"print-section\"\n              ngxPrint\n      >print</button>\n  <ion-button (click)=\"placeorder()\" expand=\"block\" color=\"success\"  [disabled]=\"cart==[]\"  style=\"margin:10px;height:3rem\"> Order </ion-button>\n    </ion-list>\n  </div>\n\n  <div color=\"success\" class=\"main\" [ngSwitch]=\"sign\">\n    <ion-list class=\"f\" *ngSwitchCase=\"'employee'\">\n      <ion-item lines=\"none\" class=\"option\">\n        <ion-label>Employee Name</ion-label>\n        <ion-select name=\"e_id\" [(ngModel)]=\"e_id\" interface=\"action-sheet\">\n          <ion-select-option value={{a.e_id}} *ngFor=\"let a of employee\">{{a.name}}</ion-select-option>\n        </ion-select>\n      </ion-item>\n      <ion-item style=\"--background: transparent;\">\n        <ion-label style=\"width: 30%;\">\n          Enter The Custome Invoice ID\n        </ion-label>\n        <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"invoice_idc\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n      </ion-item>\n      <ion-item>\n        <ion-label style=\"width: 30%;\">\n          Enter the Date\n        </ion-label>\n        <ion-datetime display-format=\"YYYY-MM-DD\" min=\"2000-01-01\" max=\"2100-10-31\" picker-format=\"YYYY-MM-DD\" name=\"date\" [(ngModel)]=\"date\">Select Date</ion-datetime>\n      </ion-item>\n      <table>\n        <thead>\n        <tr>\n          <th>Product Name</th>\n          <th>Packing Size</th>\n          <th>Quantity</th>\n          <th>Unit Price</th>\n          <th>Purchasing</th>\n          <th>Partitioner</th>\n          <th>Net Ammount</th>\n          <th>Total Price</th>\n        </tr>\n        </thead>\n        <tbody>\n\n        <tr *ngFor=\"let a of cart\">\n          <td>{{a.name}}</td>\n          <td>{{a.packing}}</td>\n          <td>\n            <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.number\"></ion-input>\n          </td>\n          <td>{{a.selling}}</td>\n          <td>{{a.purchasing}}</td>\n          <td>{{a.practioner}}</td>\n          <td>\n            <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.price\"></ion-input>\n          </td>\n          <td>{{a.number}} * {{a.price}}</td>\n        </tr>\n        </tbody>\n      </table>\n\n      <ion-button (click)=\"totalemp()\" expand=\"block\" color=\"success\" style=\"margin:10px;height:2.5rem\">Total</ion-button>\n      <ion-item *ngIf=\"to!=0\"  style=\"--background: transparent;\">\n        <ion-label >\n          Total\n        </ion-label>\n        <ion-label text-right >\n          {{to}}\n        </ion-label>\n      </ion-item>\n      <ion-item style=\"--background: transparent;\">\n        <ion-label style=\"width: 80%;\">\n          Recevied\n        </ion-label>\n        <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"re\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n      </ion-item>\n\n      <ion-button (click)=\"placeorderemp()\" expand=\"block\" color=\"success\"  [disabled]=\"e_id==null || cart==[]\"  style=\"margin:10px;height:3rem\"> Order </ion-button>\n    </ion-list>\n  </div>\n\n  <div id=\"print-section\" >\n  <div class=\"main2\" style=\"width: 85% ; margin-left: auto; margin-right: auto\">\n\n\n    <div style=\" width: 100% ; height: 150px\">\n      <p style=\"text-align: end\">Invoice ID: {{invoice_idc}}</p>\n      <div style=\"width: 70px ; height: 70px ; margin-left: 40px;float: left\">\n        <img src=\"./assets/WhatsApp%20Image%202021-11-22%20at%205.30.56%20AM.jpeg\" style=\"width: 70px; height: 70px\">\n      </div>\n      <div style=\"float: right; margin-top: 30px\">\n        Date: {{date}}\n      </div>\n    </div>\n    <p>\n      Client Name :\n    </p>\n    <p>\n      Client Address :\n    </p>\n    <p>\n      Client Mobile No :\n    </p>\n\n    <table style=\"margin-left: 30px; margin-top: 30px\" >\n      <thead style=\"width: 100%\">\n      <tr>\n        <th style=\"width: 10%\"> Sr No</th>\n        <th style=\"width: 40%\">Product Name</th>\n        <th style=\"width: 10%\">Quantity</th>\n        <th style=\"width: 20%\">Unit Price</th>\n        <th style=\"width: 20%\">Total Price</th>\n      </tr>\n      </thead>\n      <tbody>\n\n      <tr *ngFor=\"let a of cart ; let i = index\">\n        <td>{{i}}</td>\n        <td>{{a.name}}</td>\n        <td>\n          {{a.number}}\n        </td>\n        <td>\n          {{a.price}}\n        </td>\n        <td>\n          {{a.number * a.price}}\n        </td>\n      </tr>\n      </tbody>\n    </table>\n  <p style=\"text-align: end\"> Total : {{to}}</p>\n    <p style=\"text-align: end\"> Advance :{{bank.recei}}</p>\n    <p style=\"text-align: end\"> Remaining :{{bank.recei - to}}</p>\n\n    <div style=\" width: 100% ;  margin-top: 50px\">\n      <div style=\" width: 25%;  float: left ; margin-left: 30px\" >\n        <p style=\"border-top: 2px solid black\">Prepared BY</p>\n      </div>\n      <div style=\" width: 25%; float: left ; margin-left: 30px\" >\n       <p style=\"border-top: 2px solid black\">Approved By</p>\n      </div>\n      <div style=\" width: 25%; float: left ; margin-left: 30px\" >\n        <p>\n          Address Main Gate , Shalimaar Town , Sahiwal Bypass\n        </p>\n        <p>\n          +92 300 3508484 / +92 300 2048484\n        </p>\n        <p>\n          dairylinks.pk@gmail.com\n        </p>\n      </div>\n\n\n    </div>\n  </div>\n\n  </div>\n\n\n</ion-content>\n";
      /***/
    },

    /***/
    "Y+Iu":
    /*!***************************************************!*\
      !*** ./src/app/pages/cart/cart-routing.module.ts ***!
      \***************************************************/

    /*! exports provided: CartPageRoutingModule */

    /***/
    function YIu(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CartPageRoutingModule", function () {
        return CartPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _cart_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./cart.page */
      "rqSi");

      var routes = [{
        path: '',
        component: _cart_page__WEBPACK_IMPORTED_MODULE_3__["CartPage"]
      }];

      var CartPageRoutingModule = function CartPageRoutingModule() {
        _classCallCheck(this, CartPageRoutingModule);
      };

      CartPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], CartPageRoutingModule);
      /***/
    },

    /***/
    "rqSi":
    /*!*****************************************!*\
      !*** ./src/app/pages/cart/cart.page.ts ***!
      \*****************************************/

    /*! exports provided: CartPage */

    /***/
    function rqSi(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CartPage", function () {
        return CartPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_cart_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./cart.page.html */
      "2Cor");
      /* harmony import */


      var _cart_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./cart.page.scss */
      "vwaP");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! src/app/provider/apicall.service */
      "G1p3");
      /* harmony import */


      var src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/app/provider/global.service */
      "Lb7+");

      var CartPage = /*#__PURE__*/function () {
        function CartPage(loadingController, global, apicall) {
          _classCallCheck(this, CartPage);

          this.loadingController = loadingController;
          this.global = global;
          this.apicall = apicall;
          this.cart = [];
          this.order = {
            customer: {
              customer_id: null,
              received: null,
              net_balance: null,
              date: null,
              invoice_idc: null
            },
            cart: {},
            bank: {}
          };
          this.orderemp = {
            employee: {
              e_id: null,
              received: null,
              net_balance: null,
              date: null,
              invoice_idc: null
            },
            cart: {}
          };
          this.customer_id = null;
          this.e_id = null;
          this.to = 0;
          this.re = 0;
          this.last1 = {
            net_balance: 0
          };
          this.banks = 'false';
          this.bank = {
            b_id: null,
            invoice_id: '',
            customer_id: '',
            name: '',
            title: '',
            no: '',
            ammount: '',
            credit: '0',
            net_balance: ''
          };
          this.lastemp1 = {
            net_balance: 0
          };
          this.customer4 = [];
        }

        _createClass(CartPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.apicall.api_getbanks();
            this.global.Bank.subscribe(function (res) {
              _this.bankname = res;
              console.log(_this.bankname);
            });
            this.sign = 'customer';
            this.global.Cart.subscribe(function (res) {
              _this.cart = res;
            });
            this.apicall.api_getcustomer();
            this.global.Customer.subscribe(function (res) {
              console.log(_this.customer);
              _this.customer = res;
            });
            this.apicall.api_getemployee();
            this.global.Employee.subscribe(function (res) {
              _this.employee = res;
            });
          }
        }, {
          key: "total",
          value: function total() {
            var _this2 = this;

            console.log(this.customer_id);
            this.apicall.api_getcustomerdetails(this.customer_id.customer_id);
            this.presentLoadingWithOptions();
            this.global.Customerdetails.subscribe(function (res) {
              _this2.last = res;
              console.log(_this2.last);
            });
            this.to = 0;

            for (var index = 0; index < this.cart.length; index++) {
              this.to = this.cart[index].price * this.cart[index].number + this.to;
            }

            console.log(this.to);
          }
        }, {
          key: "totalemp",
          value: function totalemp() {
            var _this3 = this;

            console.log(this.e_id);
            this.apicall.api_getemployeedetail(this.e_id);
            this.presentLoadingWithOptions();
            this.global.Employeedetails.subscribe(function (res) {
              _this3.lastemp = res;
              console.log(_this3.lastemp);
            });
            this.to = 0;

            for (var index = 0; index < this.cart.length; index++) {
              this.to = this.cart[index].price * this.cart[index].number + this.to;
            }

            console.log(this.to);
          }
        }, {
          key: "change",
          value: function change() {
            var _this4 = this;

            console.log(this.bank.b_id);
            this.apicall.api_getbankdetail(this.bank.b_id);
            this.global.Bankdetail.subscribe(function (res) {
              _this4.last2 = res;
              console.log(_this4.last2);
            });
          }
        }, {
          key: "placeorder",
          value: function placeorder() {
            if (this.last2.length !== 0) {
              this.last3 = this.last2[this.last2.length - 1];
              this.bank.net_balance = this.last3.net_balance;
              console.log(this.bank);
            } else {
              this.bank.net_balance = 0;
              console.log(this.bank);
            }

            console.log(this.re);
            console.log(this.last.length);

            if (this.last.length !== 0) {
              this.last1 = this.last[this.last.length - 1];
              this.order.customer.net_balance = this.last1.net_balance;
              console.log(this.last1.net_balance);
              console.log(this.order.customer.net_balance);
            } else {
              this.order.customer.net_balance = 0;
              console.log(this.order.customer.net_balance);
            }

            this.bank.customer_id = this.customer_id.customer_id;
            this.order.customer.customer_id = this.customer_id.customer_id;
            this.order.customer.received = this.bank.recei;
            this.date = this.date.slice(0, 10);
            this.order.customer.date = this.date;
            this.order.customer.invoice_idc = this.invoice_idc;
            this.order.cart = this.cart;
            this.order.bank = this.bank;
            console.log(this.order);
            this.apicall.api_addorder(this.order);
            this.cart = [];
            this.global.set_Cart(null);
            this.order = {
              customer_id: null,
              cart: {}
            };
            this.presentLoadingWithOptions();
            this.apicall.api_getmedicinedetail();
          }
        }, {
          key: "placeorderemp",
          value: function placeorderemp() {
            console.log(this.re);
            console.log(this.lastemp);

            if (this.lastemp.length !== 0) {
              this.lastemp1 = this.lastemp[this.lastemp.length - 1];
              console.log(this.lastemp1.net_balance);
              this.orderemp.employee.net_balance = this.lastemp1.net_balance;
              console.log(this.lastemp1.net_balance);
            } else {
              this.orderemp.employee.net_balance = 0;
              console.log(this.orderemp.employee.net_balance);
            }

            this.orderemp.employee.e_id = this.e_id;
            this.orderemp.employee.received = this.re;
            this.date = this.date.slice(0, 10);
            this.orderemp.employee.date = this.date;
            this.orderemp.employee.invoice_idc = this.invoice_idc;
            this.orderemp.cart = this.cart;
            console.log(this.orderemp);
            this.apicall.api_addorderemp(this.orderemp);
            this.cart = [];
            this.global.set_Cart(null);
            this.order = {
              customer_id: null,
              cart: {}
            };
            this.presentLoadingWithOptions();
            this.apicall.api_getmedicinedetail();
          }
        }, {
          key: "presentLoadingWithOptions",
          value: function presentLoadingWithOptions() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var loading, _yield$loading$onDidD, role, data;

              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.loadingController.create({
                        spinner: 'circular',
                        duration: 400,
                        message: 'Order Is Being Placed',
                        translucent: true,
                        cssClass: 'custom-class custom-loading',
                        backdropDismiss: true
                      });

                    case 2:
                      loading = _context.sent;
                      _context.next = 5;
                      return loading.present();

                    case 5:
                      _context.next = 7;
                      return loading.onDidDismiss();

                    case 7:
                      _yield$loading$onDidD = _context.sent;
                      role = _yield$loading$onDidD.role;
                      data = _yield$loading$onDidD.data;
                      this.apicall.api_getmedicinedetail();

                    case 11:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "togle",
          value: function togle() {
            if (this.banks === true) {
              this.banks = 'true';
              console.log(this.banks);
            } else {
              this.banks = 'false';
              console.log(this.banks);
            }
          }
        }, {
          key: "remove",
          value: function remove(i) {
            this.cart.splice(i, 1);
          }
        }]);

        return CartPage;
      }();

      CartPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
        }, {
          type: src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__["GlobalService"]
        }, {
          type: src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__["ApicallService"]
        }];
      };

      CartPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-cart',
        template: _raw_loader_cart_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_cart_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], CartPage);
      /***/
    },

    /***/
    "sFz8":
    /*!*******************************************!*\
      !*** ./src/app/pages/cart/cart.module.ts ***!
      \*******************************************/

    /*! exports provided: CartPageModule */

    /***/
    function sFz8(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CartPageModule", function () {
        return CartPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _cart_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./cart-routing.module */
      "Y+Iu");
      /* harmony import */


      var _cart_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./cart.page */
      "rqSi");
      /* harmony import */


      var ngx_print__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ngx-print */
      "m1XX");
      /* harmony import */


      var ionic_selectable__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ionic-selectable */
      "8xsl");

      var CartPageModule = function CartPageModule() {
        _classCallCheck(this, CartPageModule);
      };

      CartPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _cart_routing_module__WEBPACK_IMPORTED_MODULE_5__["CartPageRoutingModule"], ngx_print__WEBPACK_IMPORTED_MODULE_7__["NgxPrintModule"], ionic_selectable__WEBPACK_IMPORTED_MODULE_8__["IonicSelectableModule"]],
        declarations: [_cart_page__WEBPACK_IMPORTED_MODULE_6__["CartPage"]]
      })], CartPageModule);
      /***/
    },

    /***/
    "vwaP":
    /*!*******************************************!*\
      !*** ./src/app/pages/cart/cart.page.scss ***!
      \*******************************************/

    /*! exports provided: default */

    /***/
    function vwaP(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #5f8ff8, #ffffff);\n}\n\nion-col {\n  background-color: #f7f7f7;\n  border: solid 1px #ddd;\n}\n\n@media screen and (max-width: 550px) {\n  td, th {\n    font-size: 14px;\n  }\n}\n\n@media screen and (max-width: 500px) {\n  td, th {\n    font-size: 12px;\n  }\n}\n\n@media screen and (max-width: 450px) {\n  td, th {\n    font-size: 11px;\n  }\n}\n\n@media screen and (max-width: 400px) {\n  td, th {\n    font-size: 10px;\n  }\n}\n\n@media screen and (max-width: 370px) {\n  td, th {\n    font-size: 9px;\n  }\n}\n\ntable {\n  width: 100%;\n  border-collapse: collapse;\n}\n\n/* Zebra striping */\n\ntr:nth-of-type(odd) {\n  background: #eee;\n}\n\nth {\n  background: #333;\n  color: white;\n}\n\ntd, th {\n  padding: 3px;\n  border: 1px solid #ccc;\n  text-align: left;\n}\n\nbutton {\n  max-width: 90%;\n  width: 90%;\n  justify-content: center;\n  height: 50px;\n  color: white;\n  border-radius: 10%;\n  font-size: 18px;\n  background: red;\n  margin-left: 5%;\n}\n\n.main2 {\n  opacity: 0%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL2NhcnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usc0NBQUE7QUFDRjs7QUFDQTtFQUNFLDBEQUFBO0FBRUY7O0FBQUE7RUFDSSx5QkFBQTtFQUNBLHNCQUFBO0FBR0o7O0FBREU7RUFDRTtJQUNJLGVBQUE7RUFJTjtBQUNGOztBQUZFO0VBQ0U7SUFDSSxlQUFBO0VBSU47QUFDRjs7QUFGRTtFQUNFO0lBQ0ksZUFBQTtFQUlOO0FBQ0Y7O0FBRkU7RUFDRTtJQUNJLGVBQUE7RUFJTjtBQUNGOztBQUZFO0VBQ0U7SUFDSSxjQUFBO0VBSU47QUFDRjs7QUFERTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtBQUdGOztBQURDLG1CQUFBOztBQUNBO0VBQ0MsZ0JBQUE7QUFJRjs7QUFGQztFQUNDLGdCQUFBO0VBQ0EsWUFBQTtBQUtGOztBQUhDO0VBQ0MsWUFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QUFNRjs7QUFEQTtFQUNFLGNBQUE7RUFDQSxVQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FBSUY7O0FBREE7RUFDRSxXQUFBO0FBSUYiLCJmaWxlIjoiY2FydC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc3VjY2Vzcyk7XHJcbn1cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgIzVmOGZmOCwgI2ZmZmZmZik7XHJcbn1cclxuaW9uLWNvbCAge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2Y3ZjdmNztcclxuICAgIGJvcmRlcjogc29saWQgMXB4ICNkZGQ7XHJcbiAgfVxyXG4gIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDU1MHB4KSB7XHJcbiAgICB0ZCx0aCAge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgfVxyXG4gIH1cclxuICBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgdGQsdGggIHtcclxuICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgIH1cclxuICB9XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDUwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgICB9XHJcbiAgfVxyXG4gIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDQwMHB4KSB7XHJcbiAgICB0ZCx0aCAge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgICAgfVxyXG4gIH1cclxuICBAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAzNzBweCkge1xyXG4gICAgdGQsdGggIHtcclxuICAgICAgICBmb250LXNpemU6IDlweDtcclxuICAgICAgfVxyXG4gIH1cclxuXHJcbiAgdGFibGUgeyBcclxuXHRcdHdpZHRoOiAxMDAlOyBcclxuXHRcdGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7IFxyXG5cdH1cclxuXHQvKiBaZWJyYSBzdHJpcGluZyAqL1xyXG5cdHRyOm50aC1vZi10eXBlKG9kZCkgeyBcclxuXHRcdGJhY2tncm91bmQ6ICNlZWU7IFxyXG5cdH1cclxuXHR0aCB7IFxyXG5cdFx0YmFja2dyb3VuZDogIzMzMzsgXHJcblx0XHRjb2xvcjogd2hpdGU7IFxyXG5cdH1cclxuXHR0ZCwgdGggeyBcclxuXHRcdHBhZGRpbmc6IDNweDsgXHJcblx0XHRib3JkZXI6IDFweCBzb2xpZCAjY2NjOyBcclxuXHRcdHRleHQtYWxpZ246IGxlZnQ7IFxyXG5cdH1cclxuXHJcblxyXG5cclxuYnV0dG9ue1xyXG4gIG1heC13aWR0aDogOTAlO1xyXG4gIHdpZHRoOiA5MCU7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBib3JkZXItcmFkaXVzOiAxMCU7XHJcbiAgZm9udC1zaXplOiAxOHB4O1xyXG4gIGJhY2tncm91bmQ6IHJlZDtcclxuICBtYXJnaW4tbGVmdDogNSU7XHJcbn1cclxuXHJcbi5tYWluMntcclxuICBvcGFjaXR5OiAwJTtcclxufVxyXG4iXX0= */";
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-cart-cart-module-es5.js.map