(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-return-return-module"], {
    /***/
    "3Llr":
    /*!*******************************************************!*\
      !*** ./src/app/pages/return/return-routing.module.ts ***!
      \*******************************************************/

    /*! exports provided: ReturnPageRoutingModule */

    /***/
    function Llr(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ReturnPageRoutingModule", function () {
        return ReturnPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _return_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./return.page */
      "8zAv");

      var routes = [{
        path: '',
        component: _return_page__WEBPACK_IMPORTED_MODULE_3__["ReturnPage"]
      }];

      var ReturnPageRoutingModule = function ReturnPageRoutingModule() {
        _classCallCheck(this, ReturnPageRoutingModule);
      };

      ReturnPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ReturnPageRoutingModule);
      /***/
    },

    /***/
    "8zAv":
    /*!*********************************************!*\
      !*** ./src/app/pages/return/return.page.ts ***!
      \*********************************************/

    /*! exports provided: ReturnPage */

    /***/
    function zAv(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ReturnPage", function () {
        return ReturnPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_return_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./return.page.html */
      "Y+OQ");
      /* harmony import */


      var _return_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./return.page.scss */
      "YcaQ");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _provider_global_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../provider/global.service */
      "Lb7+");
      /* harmony import */


      var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../provider/apicall.service */
      "G1p3");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");

      var ReturnPage = /*#__PURE__*/function () {
        function ReturnPage(router, global, apicall, loadingController) {
          _classCallCheck(this, ReturnPage);

          this.router = router;
          this.global = global;
          this.apicall = apicall;
          this.loadingController = loadingController;
          this.cart = [];
          this.givemoney = 0;
          this.givemoney1 = 0; // tslint:disable-next-line:variable-name

          this.invoice_id = ''; // tslint:disable-next-line:variable-name

          this.p_invoice_id = '';
          this.seller1 = {
            s_id: null,
            pi_id: null
          };
          this.employee1 = {
            e_id: null,
            invoice_id: null
          };
          this.history = {
            invoice_id: null,
            name: null,
            type: 'medicine',
            quantity: null,
            action: null,
            user: null
          };
        }

        _createClass(ReturnPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.sign = 'sale';
            this.apicall.api_getseller();
            this.global.Seller.subscribe(function (res) {
              _this.seller = res;
            });
            this.apicall.api_getemployee();
            this.global.Employee.subscribe(function (res) {
              _this.employee = res;
            });
          }
        }, {
          key: "onChange",
          value: function onChange() {
            var _this2 = this;

            console.log(this.seller1.s_id);
            this.apicall.api_getsellerdetails(this.seller1.s_id);
            this.global.Sellerdetails.subscribe(function (res) {
              _this2.sellerdetail = res;
            });
          }
        }, {
          key: "onChange1",
          value: function onChange1() {
            var _this3 = this;

            this.apicall.api_getemployeedetail(this.employee1.e_id);
            this.global.Employeedetails.subscribe(function (res) {
              _this3.employeedetail = res;
            });
          }
        }, {
          key: "total",
          value: function total() {
            var _this4 = this;

            this.apicall.api_getinvoicedetail(this.invoice_id);
            console.log(this.invoice_id);
            this.global.Invoicedetail.subscribe(function (res) {
              _this4.invo = res;
              console.log(_this4.invo);
            }); // this.apicall.api_getcustomerbalance(this.invoice_id) ;
            // this.global.Customerdetails.subscribe(res => {
            //   this.detail = res;
            //   console.log(this.detail);
            //   this.givemoney = 0;
            // });
          }
        }, {
          key: "empinvoice",
          value: function empinvoice() {
            var _this5 = this;

            this.apicall.api_getinvoicedetailemp(this.employee1.invoice_id);
            console.log(this.invoice_id);
            this.global.Invoicedetailemp.subscribe(function (res) {
              _this5.invoemp = res;
              console.log(_this5.invoemp);
            }); // this.apicall.api_getcustomerbalance(this.invoice_id) ;
            // this.global.Customerdetails.subscribe(res => {
            //   this.detail = res;
            //   console.log(this.detail);
            //   this.givemoney = 0;
            // });
          }
        }, {
          key: "totalpurchase",
          value: function totalpurchase() {
            var _this6 = this;

            console.log(this.seller1);
            this.apicall.api_getpurchase(this.seller1.pi_id);
            this.global.Purchasedetail.subscribe(function (res) {
              _this6.purchase = res;
              console.log(_this6.purchase);
            });
          }
        }, {
          key: "updateinvoice",
          value: function updateinvoice(a) {
            var _this7 = this;

            this.a = a;
            this.givemoney1 = a.quantity * a.unitprice;
            this.givemoney = this.givemoney + this.givemoney1;
            console.log(this.a);
            this.history.invoice_id = a.invoice_id;
            this.history.type = a.med_name;
            this.history.action = ' sale return';
            this.history.quantity = a.quantity;
            this.global.User.subscribe(function (res) {
              _this7.history.user = res.username;
            });
            console.log(this.history);
            this.apicall.api_salereturn(a);
            a = '';
            this.presentLoadingWithOptions();
            this.router.navigate(['return']);
          }
        }, {
          key: "updateinvoiceemp",
          value: function updateinvoiceemp(a) {
            this.a = a;
            this.givemoney1 = a.quantity * a.unitprice;
            this.givemoney = this.givemoney + this.givemoney1;
            console.log(this.a);
            this.apicall.api_salereturnemp(a);
            this.presentLoadingWithOptions();
            this.router.navigate(['return']);
          }
        }, {
          key: "updatepurchase",
          value: function updatepurchase(a) {
            var _this8 = this;

            console.log(a);
            this.history.invoice_id = a.pi_id;
            this.history.name = a.med_name;
            this.history.type = a.packing;
            this.history.action = 'purchase return';
            this.history.quantity = a.quantity;
            this.global.User.subscribe(function (res) {
              _this8.history.user = res.username;
            });
            this.apicall.api_purchasereturn(a);
            this.presentLoadingWithOptions();
            this.router.navigate(['return']);
          }
        }, {
          key: "presentLoadingWithOptions",
          value: function presentLoadingWithOptions() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var loading, _yield$loading$onDidD, role, data;

              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.loadingController.create({
                        spinner: 'circular',
                        duration: 400,
                        message: 'return Is Being Placed',
                        translucent: true,
                        cssClass: 'custom-class custom-loading',
                        backdropDismiss: true
                      });

                    case 2:
                      loading = _context.sent;
                      _context.next = 5;
                      return loading.present();

                    case 5:
                      _context.next = 7;
                      return loading.onDidDismiss();

                    case 7:
                      _yield$loading$onDidD = _context.sent;
                      role = _yield$loading$onDidD.role;
                      data = _yield$loading$onDidD.data;
                      this.apicall.api_getmedicinedetail();

                    case 11:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }]);

        return ReturnPage;
      }();

      ReturnPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"]
        }, {
          type: _provider_global_service__WEBPACK_IMPORTED_MODULE_4__["GlobalService"]
        }, {
          type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__["ApicallService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"]
        }];
      };

      ReturnPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-return',
        template: _raw_loader_return_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_return_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ReturnPage);
      /***/
    },

    /***/
    "Y+OQ":
    /*!*************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/return/return.page.html ***!
      \*************************************************************************************/

    /*! exports provided: default */

    /***/
    function YOQ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Dairy Links</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <ion-segment color=\"dark\" [(ngModel)]=\"sign\">\n    <ion-segment-button value=\"sale\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Sale Return</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"empsale\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Emp Return</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"med\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Product Return</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n\n  <div color=\"success\" class=\"main\" [ngSwitch]=\"sign\">\n    <ion-list class=\"f\" *ngSwitchCase=\"'sale'\"  >\n  <ion-item lines=\"none\" class=\"option\" >\n      <ion-label position=\"floating\"  >Invoice No:</ion-label>\n      <ion-input type=\"text\" name=\"name\" [(ngModel)]=\"invoice_id\" ></ion-input>\n  </ion-item>\n  <ion-button (click)=\"total()\" expand=\"block\" color=\"success\" style=\"margin:10px;height:2.5rem\">Total</ion-button>\n\n  <table>\n    <thead>\n    <tr>\n      <th>Invoice_id</th>\n      <th>Product Name</th>\n      <th>Quantity</th>\n      <th>Packing Size</th>\n      <th>Unit Price</th>\n      <th>Total Price</th>\n      <th>Update</th>\n    </tr>\n    </thead>\n    <tbody>\n\n    <tr *ngFor=\"let a of invo\">\n      <td>{{a.invoice_id}}</td>\n      <td>{{a.med_name}}</td>\n      <td>\n        <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.quantity\"></ion-input>\n      </td>\n      <td>{{a.packing_name}}</td>\n      <td>\n        <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.unitprice\"></ion-input>\n      </td>\n      <td>\n        <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.ammount\"></ion-input>\n      </td>\n      <td>\n        <ion-button style=\"margin: 1px\" (click)=\"updateinvoice(a)\">Update</ion-button>\n      </td>\n    </tr>\n    </tbody>\n  </table>\n<div *ngFor=\"let c of detail\">\n  <ion-item   style=\"--background: transparent;\">\n    <ion-label >\n      total\n    </ion-label>\n    <ion-label text-right>\n      {{c.debit + c.credit}}\n    </ion-label>\n  </ion-item>\n  <ion-item style=\"--background: transparent;\">\n    <ion-label style=\"width: 80%;\">\n      Debit\n    </ion-label>\n    <ion-input name=\"name\" type=\"number\"text-right [(ngModel)]=\"c.debit\"  style=\"border-bottom: 1px solid black;\"></ion-input>\n  </ion-item>\n  <ion-item style=\"--background: transparent;\">\n    <ion-label style=\"width: 80%;\">\n      Credit\n    </ion-label>\n    <ion-input name=\"name\" type=\"number\"text-right [(ngModel)]=\"c.credit\"  style=\"border-bottom: 1px solid black;\"></ion-input>\n  </ion-item>\n</div>\n    <ion-item   style=\"--background: transparent;\">\n      <ion-label >\n        Refund\n      </ion-label>\n      <ion-label text-right>\n        {{this.givemoney}}\n      </ion-label>\n    </ion-item>\n    </ion-list>\n    <ion-list class=\"f\" *ngSwitchCase=\"'empsale'\">\n      <ion-item lines=\"none\" class=\"option\">\n        <ion-label>Select Employee</ion-label>\n        <ion-select name=\"e_id\" [(ngModel)]=\"employee1.e_id\" interface=\"action-sheet\" (ngModelChange) = \"onChange1()\">\n          <ion-select-option value={{a.e_id}} *ngFor=\"let a of employee\">{{a.name}}</ion-select-option>\n        </ion-select>\n      </ion-item>\n      <ion-item lines=\"none\" class=\"option\">\n        <ion-label>Select Seller invoice</ion-label>\n        <ion-select name=\"invoice_id\" [(ngModel)]=\"employee1.invoice_id\" interface=\"action-sheet\">\n          <ion-select-option value={{a.invoice_id}} *ngFor=\"let a of employeedetail\">{{a.invoice_id}}</ion-select-option>\n        </ion-select>\n      </ion-item>\n      <ion-button (click)=\"empinvoice()\" expand=\"block\" color=\"success\" style=\"margin:10px;height:2.5rem\">Total</ion-button>\n\n      <table>\n        <thead>\n        <tr>\n          <th>Invoice_id</th>\n          <th>Product Name</th>\n          <th>Quantity</th>\n          <th>Packing Size</th>\n          <th>Unit Price</th>\n          <th>Total Price</th>\n          <th>Update</th>\n        </tr>\n        </thead>\n        <tbody>\n\n        <tr *ngFor=\"let a of invoemp\">\n          <td>{{a.invoice_id}}</td>\n          <td>{{a.med_name}}</td>\n          <td>\n            <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.quantity\"></ion-input>\n          </td>\n          <td>{{a.packing_name}}</td>\n          <td>\n            <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.unitprice\"></ion-input>\n          </td>\n          <td>\n            <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.ammount\"></ion-input>\n          </td>\n          <td>\n            <ion-button style=\"margin: 1px\" (click)=\"updateinvoiceemp(a)\">Update</ion-button>\n          </td>\n        </tr>\n        </tbody>\n      </table>\n    </ion-list>\n    <ion-list class=\"f\" *ngSwitchCase=\"'med'\">\n      <ion-item lines=\"none\" class=\"option\">\n        <ion-label>Select Seller</ion-label>\n        <ion-select name=\"c_id\" [(ngModel)]=\"seller1.s_id\" interface=\"action-sheet\" (ngModelChange) = \"onChange()\">\n          <ion-select-option value={{a.s_id}} *ngFor=\"let a of seller\">{{a.s_name}}</ion-select-option>\n        </ion-select>\n      </ion-item>\n      <ion-item lines=\"none\" class=\"option\">\n        <ion-label>Select Seller invoice</ion-label>\n        <ion-select name=\"c_id\" [(ngModel)]=\"seller1.pi_id\" interface=\"action-sheet\">\n          <ion-select-option value={{a.pi_id}} *ngFor=\"let a of sellerdetail\">{{a.pi_id}}</ion-select-option>\n        </ion-select>\n      </ion-item>\n      <ion-button (click)=\"totalpurchase()\" expand=\"block\" color=\"success\" style=\"margin:10px;height:2.5rem\">Total</ion-button>\n\n      <table>\n        <thead>\n        <tr>\n          <th>Invoice_id</th>\n          <th>Med Name</th>\n          <th>Quantity</th>\n          <th>Packing Name</th>\n          <th>Purchasing</th>\n          <th>selling</th>\n          <th>update</th>\n        </tr>\n        </thead>\n        <tbody>\n\n        <tr *ngFor=\"let a of purchase\">\n          <td>{{a.p_invoice_id}}</td>\n          <td>{{a.med_name}}</td>\n          <td>\n            <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.quantity\"></ion-input>\n          </td>\n          <td>{{a.packing}}</td>\n          <td>\n            <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.purchasing\"></ion-input>\n          </td>\n          <td>\n            <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.selling\"></ion-input>\n          </td>\n          <td>\n            <ion-button style=\"margin: 1px\" (click)=\"updatepurchase(a)\">Update</ion-button>\n          </td>\n        </tr>\n        </tbody>\n      </table>\n    </ion-list>\n  </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "YcaQ":
    /*!***********************************************!*\
      !*** ./src/app/pages/return/return.page.scss ***!
      \***********************************************/

    /*! exports provided: default */

    /***/
    function YcaQ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #5f8ff8, #ffffff);\n}\n\nion-content ion-item {\n  --background: transparent;\n}\n\nion-content ion-item ion-input {\n  border-bottom: 1px solid black;\n}\n\nion-content ion-button {\n  margin: 15px 20px 15px 20px;\n  border-radius: 30px;\n  box-shadow: 4px 9px 29px -9px #050505;\n}\n\nion-content ion-list {\n  background: transparent;\n}\n\nion-col {\n  background-color: #f7f7f7;\n  border: solid 1px #ddd;\n}\n\n@media screen and (max-width: 550px) {\n  td, th {\n    font-size: 14px;\n  }\n}\n\n@media screen and (max-width: 500px) {\n  td, th {\n    font-size: 12px;\n  }\n}\n\n@media screen and (max-width: 450px) {\n  td, th {\n    font-size: 11px;\n  }\n}\n\n@media screen and (max-width: 400px) {\n  td, th {\n    font-size: 10px;\n  }\n}\n\n@media screen and (max-width: 370px) {\n  td, th {\n    font-size: 9px;\n  }\n}\n\ntable {\n  width: 100%;\n  border-collapse: collapse;\n}\n\n/* Zebra striping */\n\ntr:nth-of-type(odd) {\n  background: #eee;\n}\n\nth {\n  background: #333;\n  color: white;\n}\n\ntd, th {\n  padding: 3px;\n  border: 1px solid #ccc;\n  text-align: left;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3JldHVybi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxzQ0FBQTtBQUNGOztBQUNBO0VBQ0UsMERBQUE7QUFFRjs7QUFEQztFQUNLLHlCQUFBO0FBR047O0FBRk07RUFDSSw4QkFBQTtBQUlWOztBQURFO0VBQ0ksMkJBQUE7RUFDQSxtQkFBQTtFQUNBLHFDQUFBO0FBR047O0FBREU7RUFDSSx1QkFBQTtBQUdOOztBQUFBO0VBQ0UseUJBQUE7RUFDQSxzQkFBQTtBQUdGOztBQURBO0VBQ0U7SUFDRSxlQUFBO0VBSUY7QUFDRjs7QUFGQTtFQUNFO0lBQ0UsZUFBQTtFQUlGO0FBQ0Y7O0FBRkE7RUFDRTtJQUNFLGVBQUE7RUFJRjtBQUNGOztBQUZBO0VBQ0U7SUFDRSxlQUFBO0VBSUY7QUFDRjs7QUFGQTtFQUNFO0lBQ0UsY0FBQTtFQUlGO0FBQ0Y7O0FBREE7RUFDRSxXQUFBO0VBQ0EseUJBQUE7QUFHRjs7QUFEQSxtQkFBQTs7QUFDQTtFQUNFLGdCQUFBO0FBSUY7O0FBRkE7RUFDRSxnQkFBQTtFQUNBLFlBQUE7QUFLRjs7QUFIQTtFQUNFLFlBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0FBTUYiLCJmaWxlIjoicmV0dXJuLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFyIHtcclxuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjNWY4ZmY4LCAjZmZmZmZmKTtcclxuIGlvbi1pdGVte1xyXG4gICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICBpb24taW5wdXR7XHJcbiAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgYmxhY2s7XHJcbiAgICAgIH1cclxuICB9XHJcbiAgaW9uLWJ1dHRvbntcclxuICAgICAgbWFyZ2luOjE1cHggMjBweCAxNXB4IDIwcHg7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICAgIGJveC1zaGFkb3c6IDRweCA5cHggMjlweCAtOXB4ICMwNTA1MDU7XHJcbiAgfVxyXG4gIGlvbi1saXN0e1xyXG4gICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICB9XHJcbn1cclxuaW9uLWNvbCAge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmN2Y3Zjc7XHJcbiAgYm9yZGVyOiBzb2xpZCAxcHggI2RkZDtcclxufVxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA1NTBweCkge1xyXG4gIHRkLHRoICB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgfVxyXG59XHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgdGQsdGggIHtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICB9XHJcbn1cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDUwcHgpIHtcclxuICB0ZCx0aCAge1xyXG4gICAgZm9udC1zaXplOiAxMXB4O1xyXG4gIH1cclxufVxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA0MDBweCkge1xyXG4gIHRkLHRoICB7XHJcbiAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgfVxyXG59XHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDM3MHB4KSB7XHJcbiAgdGQsdGggIHtcclxuICAgIGZvbnQtc2l6ZTogOXB4O1xyXG4gIH1cclxufVxyXG5cclxudGFibGUge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7XHJcbn1cclxuLyogWmVicmEgc3RyaXBpbmcgKi9cclxudHI6bnRoLW9mLXR5cGUob2RkKSB7XHJcbiAgYmFja2dyb3VuZDogI2VlZTtcclxufVxyXG50aCB7XHJcbiAgYmFja2dyb3VuZDogIzMzMztcclxuICBjb2xvcjogd2hpdGU7XHJcbn1cclxudGQsIHRoIHtcclxuICBwYWRkaW5nOiAzcHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxuICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG59XHJcblxyXG5cclxuXHJcblxyXG4iXX0= */";
      /***/
    },

    /***/
    "fRlq":
    /*!***********************************************!*\
      !*** ./src/app/pages/return/return.module.ts ***!
      \***********************************************/

    /*! exports provided: ReturnPageModule */

    /***/
    function fRlq(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ReturnPageModule", function () {
        return ReturnPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _return_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./return-routing.module */
      "3Llr");
      /* harmony import */


      var _return_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./return.page */
      "8zAv");

      var ReturnPageModule = function ReturnPageModule() {
        _classCallCheck(this, ReturnPageModule);
      };

      ReturnPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _return_routing_module__WEBPACK_IMPORTED_MODULE_5__["ReturnPageRoutingModule"]],
        declarations: [_return_page__WEBPACK_IMPORTED_MODULE_6__["ReturnPage"]]
      })], ReturnPageModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-return-return-module-es5.js.map