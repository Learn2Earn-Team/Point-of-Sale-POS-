(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-customerdetail-customerdetail-module"],{

/***/ "3iRQ":
/*!***********************************************************************!*\
  !*** ./src/app/pages/customerdetail/customerdetail-routing.module.ts ***!
  \***********************************************************************/
/*! exports provided: CustomerdetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerdetailPageRoutingModule", function() { return CustomerdetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _customerdetail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./customerdetail.page */ "sDyA");




const routes = [
    {
        path: '',
        component: _customerdetail_page__WEBPACK_IMPORTED_MODULE_3__["CustomerdetailPage"]
    }
];
let CustomerdetailPageRoutingModule = class CustomerdetailPageRoutingModule {
};
CustomerdetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CustomerdetailPageRoutingModule);



/***/ }),

/***/ "DOzG":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/customerdetail/customerdetail.page.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">{{this.name}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <table>\n    <thead>\n      <tr>\n        <th style=\"background: #333; \">Date</th>\n        <th style=\"background: #333; \">Invoice ID</th>\n        <th style=\"background: rgb(4, 151, 70); \">Debit</th>\n        <th style=\"background: rgb(204, 13, 13); \">Credit</th>\n        <th style=\"background: rgb(204, 13, 13); \">Discount</th>\n        <th style=\"background: rgb(204, 13, 13); \">Net Balance</th>\n      </tr>\n    </thead>\n    <tbody>\n\n      <tr *ngFor=\"let a of data\">\n        <td>{{a.other}}</td>\n        <td>{{a.invoice_idc}}</td>\n        <td>{{a.credit}}</td>\n        <td>{{a.debit}}</td>\n        <td>{{a.discount}}</td>\n        <td>{{a.net_balance}}</td>\n        <td>     <ion-checkbox  (ionChange)=\"getdetail(a.invoice_id)\"></ion-checkbox></td>\n<!--       <ion-button style=\"margin: 1px\" (click)=\"updatecustomerbalance(a)\"></ion-button>-->\n      </tr>\n    </tbody>\n  </table>\n  <ion-item style=\"--background: transparent;\">\n    <ion-label style=\"width: 80%;\">\n      Recevied\n    </ion-label>\n    <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"rece\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n  </ion-item>\n\n  <ion-item style=\"--background: transparent;\">\n    <ion-label style=\"width: 80%;\">\n      Discount\n    </ion-label>\n    <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"dis\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n  </ion-item>\n\n  <ion-button  expand=\"block\" color=\"success\" style=\"margin:10px;height:2.5rem\" (click) = updatecustomerbalance()>Total</ion-button>\n<div>\n  <table>\n    <thead>\n    <tr>\n      <th style=\"background: #333; \">Product name </th>\n      <th style=\"background: #333; \">PAcking</th>\n      <th style=\"background: rgb(4, 151, 70); \">Total quantity</th>\n      <th style=\"background: rgb(204, 13, 13); \">unit price</th>\n      <th style=\"background: rgb(204, 13, 13); \">Total Price</th>\n    </tr>\n    </thead>\n    <tbody>\n\n    <tr *ngFor=\"let a of show1\">\n      <td>{{a.med_name}}</td>\n      <td>{{a.packing_name}}</td>\n      <td>{{a.quantity}}</td>\n      <td>{{a.unitprice}}</td>\n      <td>{{a.ammount}}</td>\n\n      <!--       <ion-button style=\"margin: 1px\" (click)=\"updatecustomerbalance(a)\"></ion-button>-->\n    </tr>\n    </tbody>\n  </table>\n</div>\n\n  <button\n          [printStyle]=\"{ div : {'color': 'black' } ,img : {'height':'180px' , 'width':'180px', 'margin-left': '20%'} , p:{'font-size': '14px' , 'color':'black' , 'font-weight': 'bold' } , th : {'font-size' : '14px' , 'color': 'black' , 'text-align': 'center' , 'border': '1px solid grey'} , td : {'font-size' : '14px' , 'color': 'black' , 'text-align': 'center' , 'border': '1px solid grey'} , h6: {'text-align': 'center' , 'margin-top' : '0px'} , visit : {'text-align': 'center'}}\"\n          printSectionId=\"print-section\"\n          ngxPrint\n  >print</button>\n\n  <div id=\"print-section\" >\n    <div class=\"main2\" style=\"width: 85% ; margin-left: auto; margin-right: auto\">\n\n\n      <div style=\" width: 100% ; height: 150px\">\n<!--        <p style=\"text-align: end\">Invoice ID: {{this.show1[0].invoice_id}}</p>-->\n        <div style=\"width: 70px ; height: 70px ; margin-left: 40px;float: left\">\n          <img src=\"./assets/WhatsApp%20Image%202021-11-22%20at%205.30.56%20AM.jpeg\" style=\"width: 70px; height: 70px\">\n        </div>\n        <div style=\"float: right; margin-top: 30px\">\n\n        </div>\n      </div>\n      <p>\n        Client Name : {{this.name}}\n      </p>\n\n      <table style=\"margin-left: 30px; margin-top: 30px\" >\n        <thead style=\"width: 100%\">\n        <tr>\n          <th style=\"background: #333; \">Product name </th>\n          <th style=\"background: #333; \">PAcking</th>\n          <th style=\"background: rgb(4, 151, 70); \">Total quantity</th>\n          <th style=\"background: rgb(204, 13, 13); \">unit price</th>\n          <th style=\"background: rgb(204, 13, 13); \">Total Price</th>\n        </tr>\n        </thead>\n        <tbody>\n\n        <tr *ngFor=\"let a of show1\">\n          <td style=\"width: 30%\">{{a.med_name}}</td>\n          <td style=\"width: 30%\">{{a.packing_name}}</td>\n          <td style=\"width: 10%\">{{a.quantity}}</td>\n          <td style=\"width: 10%\">{{a.unitprice}}</td>\n          <td style=\"width: 20%\">{{a.ammount}}</td>\n\n          <!--       <ion-button style=\"margin: 1px\" (click)=\"updatecustomerbalance(a)\"></ion-button>-->\n        </tr>\n        </tbody>\n      </table>\n\n\n      <div style=\" width: 100% ;  margin-top: 50px\">\n        <div style=\" width: 25%;  float: left ; margin-left: 30px\" >\n          <p style=\"border-top: 2px solid black\">Prepared BY</p>\n        </div>\n        <div style=\" width: 25%; float: left ; margin-left: 30px\" >\n          <p style=\"border-top: 2px solid black\">Approved By</p>\n        </div>\n        <div style=\" width: 25%; float: left ; margin-left: 30px\" >\n          <p>\n            Address Main Gate , Shalimaar Town , Sahiwal Bypass\n          </p>\n          <p>\n            +92 300 3508484 / +92 300 2048484\n          </p>\n          <p>\n            dairylinks.pk@gmail.com\n          </p>\n        </div>\n\n\n      </div>\n    </div>\n\n  </div>\n\n\n</ion-content>\n");

/***/ }),

/***/ "Pg/l":
/*!***************************************************************!*\
  !*** ./src/app/pages/customerdetail/customerdetail.module.ts ***!
  \***************************************************************/
/*! exports provided: CustomerdetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerdetailPageModule", function() { return CustomerdetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _customerdetail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./customerdetail-routing.module */ "3iRQ");
/* harmony import */ var _customerdetail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./customerdetail.page */ "sDyA");
/* harmony import */ var ngx_print__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-print */ "m1XX");








let CustomerdetailPageModule = class CustomerdetailPageModule {
};
CustomerdetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _customerdetail_routing_module__WEBPACK_IMPORTED_MODULE_5__["CustomerdetailPageRoutingModule"],
            ngx_print__WEBPACK_IMPORTED_MODULE_7__["NgxPrintModule"]
        ],
        declarations: [_customerdetail_page__WEBPACK_IMPORTED_MODULE_6__["CustomerdetailPage"]]
    })
], CustomerdetailPageModule);



/***/ }),

/***/ "sDyA":
/*!*************************************************************!*\
  !*** ./src/app/pages/customerdetail/customerdetail.page.ts ***!
  \*************************************************************/
/*! exports provided: CustomerdetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerdetailPage", function() { return CustomerdetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_customerdetail_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./customerdetail.page.html */ "DOzG");
/* harmony import */ var _customerdetail_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./customerdetail.page.scss */ "uiNV");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/provider/apicall.service */ "G1p3");
/* harmony import */ var src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/provider/global.service */ "Lb7+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "tyNb");








let CustomerdetailPage = class CustomerdetailPage {
    constructor(loadingController, alert, router, menu, apicall, global) {
        this.loadingController = loadingController;
        this.alert = alert;
        this.router = router;
        this.menu = menu;
        this.apicall = apicall;
        this.global = global;
        this.show = [];
        this.history = { invoice_id: null, name: 'customer', type: null, quantity: null, action: null, user: null };
        this.updatedetail = { customer_id: '', net_balance: '', received: '', discount: 0 };
    }
    ngOnInit() {
        this.name = history.state.data;
        console.log(this.name);
        this.global.Customerdetails.subscribe(res => {
            console.log(res);
            this.data = res;
            this.last = this.data[this.data.length - 1];
            // console.log(this.last.net_balance);
        });
    }
    getdetail(invoice_id) {
        this.apicall.api_getinvoicedetail(invoice_id);
        this.global.Invoicedetail.subscribe(res => {
            console.log(res);
            this.show1 = res;
            // console.log(this.last.net_balance);
        });
    }
    updatecustomerbalance() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.updatedetail.customer_id = this.data[0].customer_id;
            this.updatedetail.net_balance = this.last.net_balance;
            this.global.User.subscribe(res => {
                this.history.user = res.username;
            });
            this.updatedetail.received = this.rece;
            this.updatedetail.discount = this.dis;
            console.log(this.updatedetail);
            this.apicall.api_updatecustomerbalance(this.updatedetail);
            this.history.invoice_id = this.data[0].invoice_id;
            this.history.type = this.data[0].customer_name;
            this.history.action = 'get balance';
            this.history.quantity = this.rece;
            this.global.User.subscribe(res => {
                this.history.user = res.username;
            });
            this.apicall.api_inserthistory(this.history);
        });
    }
    presentLoadingWithOptions() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                spinner: "circular",
                duration: 200,
                message: 'Order Is Being Placed',
                translucent: true,
                cssClass: 'custom-class custom-loading',
                backdropDismiss: true
            });
            yield loading.present();
            const {} = yield loading.onDidDismiss();
        });
    }
};
CustomerdetailPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"] },
    { type: src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__["ApicallService"] },
    { type: src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__["GlobalService"] }
];
CustomerdetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-customerdetail',
        template: _raw_loader_customerdetail_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_customerdetail_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CustomerdetailPage);



/***/ }),

/***/ "uiNV":
/*!***************************************************************!*\
  !*** ./src/app/pages/customerdetail/customerdetail.page.scss ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #5f8ff8, #ffffff);\n  /* Zebra striping */\n}\n\n@media screen and (max-width: 550px) {\n  ion-content td, ion-content th {\n    font-size: 14px;\n  }\n}\n\n@media screen and (max-width: 500px) {\n  ion-content td, ion-content th {\n    font-size: 12px;\n  }\n}\n\n@media screen and (max-width: 450px) {\n  ion-content td, ion-content th {\n    font-size: 11px;\n  }\n}\n\n@media screen and (max-width: 400px) {\n  ion-content td, ion-content th {\n    font-size: 10px;\n  }\n}\n\n@media screen and (max-width: 370px) {\n  ion-content td, ion-content th {\n    font-size: 9px;\n  }\n}\n\nion-content table {\n  width: 100%;\n  border-collapse: collapse;\n}\n\nion-content tr:nth-of-type(odd) {\n  background: #eee;\n}\n\nion-content th {\n  background: #333;\n  color: white;\n}\n\nion-content td, ion-content th {\n  padding: 3px;\n  border: 1px solid #ccc;\n  text-align: left;\n}\n\nbutton {\n  max-width: 90%;\n  width: 90%;\n  justify-content: center;\n  height: 50px;\n  color: white;\n  border-radius: 10%;\n  font-size: 18px;\n  background: red;\n  margin-left: 5%;\n}\n\n.main2 {\n  opacity: 0%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL2N1c3RvbWVyZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHNDQUFBO0FBQ0o7O0FBQ0U7RUFDRSwwREFBQTtFQStCSSxtQkFBQTtBQTVCUjs7QUFGSTtFQUNJO0lBQ0ksZUFBQTtFQUlWO0FBQ0Y7O0FBRk07RUFDRTtJQUNJLGVBQUE7RUFJVjtBQUNGOztBQUZNO0VBQ0U7SUFDSSxlQUFBO0VBSVY7QUFDRjs7QUFGTTtFQUNFO0lBQ0ksZUFBQTtFQUlWO0FBQ0Y7O0FBRk07RUFDRTtJQUNJLGNBQUE7RUFJVjtBQUNGOztBQURNO0VBQ00sV0FBQTtFQUNBLHlCQUFBO0FBR1o7O0FBQVE7RUFDSSxnQkFBQTtBQUVaOztBQUFRO0VBQ0ksZ0JBQUE7RUFDQSxZQUFBO0FBRVo7O0FBQVE7RUFDSSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxnQkFBQTtBQUVaOztBQUVBO0VBQ0UsY0FBQTtFQUNBLFVBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7QUFDRjs7QUFFQTtFQUNFLFdBQUE7QUFDRiIsImZpbGUiOiJjdXN0b21lcmRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcclxuICB9XHJcbiAgaW9uLWNvbnRlbnQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjNWY4ZmY4LCAjZmZmZmZmKTtcclxuICAgIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDU1MHB4KSB7XHJcbiAgICAgICAgdGQsdGggIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICAgICAgdGQsdGggIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDQ1MHB4KSB7XHJcbiAgICAgICAgdGQsdGggIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDQwMHB4KSB7XHJcbiAgICAgICAgdGQsdGggIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxMHB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDM3MHB4KSB7XHJcbiAgICAgICAgdGQsdGggIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiA5cHg7XHJcbiAgICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIFxyXG4gICAgICB0YWJsZSB7IFxyXG4gICAgICAgICAgICB3aWR0aDogMTAwJTsgXHJcbiAgICAgICAgICAgIGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7IFxyXG4gICAgICAgIH1cclxuICAgICAgICAvKiBaZWJyYSBzdHJpcGluZyAqL1xyXG4gICAgICAgIHRyOm50aC1vZi10eXBlKG9kZCkgeyBcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogI2VlZTsgXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoIHsgXHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICMzMzM7IFxyXG4gICAgICAgICAgICBjb2xvcjogd2hpdGU7IFxyXG4gICAgICAgIH1cclxuICAgICAgICB0ZCwgdGggeyBcclxuICAgICAgICAgICAgcGFkZGluZzogM3B4OyBcclxuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2NjYzsgXHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGxlZnQ7IFxyXG4gICAgICAgIH1cclxuICAgIFxyXG4gIH1cclxuYnV0dG9ue1xyXG4gIG1heC13aWR0aDogOTAlO1xyXG4gIHdpZHRoOiA5MCU7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBib3JkZXItcmFkaXVzOiAxMCU7XHJcbiAgZm9udC1zaXplOiAxOHB4O1xyXG4gIGJhY2tncm91bmQ6IHJlZDtcclxuICBtYXJnaW4tbGVmdDogNSU7XHJcbn1cclxuXHJcbi5tYWluMntcclxuICBvcGFjaXR5OiAwJTtcclxufVxyXG4iXX0= */");

/***/ })

}]);
//# sourceMappingURL=pages-customerdetail-customerdetail-module-es2015.js.map