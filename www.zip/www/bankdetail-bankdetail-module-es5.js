(function () {
  function _objectDestructuringEmpty(obj) { if (obj == null) throw new TypeError("Cannot destructure undefined"); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["bankdetail-bankdetail-module"], {
    /***/
    "4FKN":
    /*!***********************************************!*\
      !*** ./src/app/bankdetail/bankdetail.page.ts ***!
      \***********************************************/

    /*! exports provided: BankdetailPage */

    /***/
    function FKN(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "BankdetailPage", function () {
        return BankdetailPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_bankdetail_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./bankdetail.page.html */
      "7DDP");
      /* harmony import */


      var _bankdetail_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./bankdetail.page.scss */
      "g8K4");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../provider/apicall.service */
      "G1p3");
      /* harmony import */


      var _provider_global_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../provider/global.service */
      "Lb7+");

      var BankdetailPage = /*#__PURE__*/function () {
        function BankdetailPage(loadingController, alert, router, menu, apicall, global) {
          _classCallCheck(this, BankdetailPage);

          this.loadingController = loadingController;
          this.alert = alert;
          this.router = router;
          this.menu = menu;
          this.apicall = apicall;
          this.global = global;
          this.bank = {
            b_id: null,
            invoice_id: '',
            customer_id: '',
            name: '',
            title: '',
            no: '',
            ammount: '',
            credit: '',
            net_balance: '',
            cnet_balance: ''
          };
          this.customer4 = 0;
        }

        _createClass(BankdetailPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.apicall.api_getcustomer();
            this.global.Customer.subscribe(function (res) {
              console.log(_this.customer);
              _this.customer = res;
            });
            this.b_id = history.state.data;
            this.global.Bankdetail.subscribe(function (res) {
              _this.bankdetail = res;
              console.log(_this.bankdetail);
            });
          }
        }, {
          key: "getdetail",
          value: function getdetail(invoice_id) {
            this.apicall.api_getinvoicedetail(invoice_id);
            console.log(invoice_id);
          }
        }, {
          key: "presentLoadingWithOptions",
          value: function presentLoadingWithOptions() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var loading, _yield$loading$onDidD;

              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.loadingController.create({
                        spinner: "circular",
                        duration: 200,
                        message: 'Order Is Being Placed',
                        translucent: true,
                        cssClass: 'custom-class custom-loading',
                        backdropDismiss: true
                      });

                    case 2:
                      loading = _context.sent;
                      _context.next = 5;
                      return loading.present();

                    case 5:
                      _context.next = 7;
                      return loading.onDidDismiss();

                    case 7:
                      _yield$loading$onDidD = _context.sent;

                      _objectDestructuringEmpty(_yield$loading$onDidD);

                    case 9:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "addbankdetail",
          value: function addbankdetail() {
            var _this2 = this;

            console.log(this.b_id);
            this.apicall.api_getbankdetail(this.b_id);
            this.presentLoadingWithOptions();
            this.global.Bankdetail.subscribe(function (res) {
              _this2.last = res;
              console.log(_this2.last);
            });

            if (this.last.length !== 0) {
              this.last1 = this.last[this.last.length - 1];
              this.bank.net_balance = this.last1.net_balance;
              console.log(this.bank);
            } else {
              this.bank.net_balance = 0;
              console.log(this.bank);
            }

            this.apicall.api_getcustomerdetails(this.customer4);
            this.global.Customerdetails.subscribe(function (res) {
              _this2.last2 = res;
            });

            if (this.last2.length !== 0) {
              this.last3 = this.last2[this.last2.length - 1];
              this.bank.cnet_balance = this.last3.net_balance;
              console.log(this.bank);
            } else {
              this.bank.cnet_balance = 0;
              console.log(this.bank);
            }

            console.log(this.bank);
            this.bank.b_id = this.b_id;
            this.bank.customer_id = this.customer4;
            this.apicall.api_addbankdetail(this.bank);
            this.bank = null;
            this.router.navigate(['employeedetail1']);
          }
        }]);

        return BankdetailPage;
      }();

      BankdetailPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"]
        }, {
          type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_6__["ApicallService"]
        }, {
          type: _provider_global_service__WEBPACK_IMPORTED_MODULE_7__["GlobalService"]
        }];
      };

      BankdetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-bankdetail',
        template: _raw_loader_bankdetail_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_bankdetail_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], BankdetailPage);
      /***/
    },

    /***/
    "7DDP":
    /*!***************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/bankdetail/bankdetail.page.html ***!
      \***************************************************************************************/

    /*! exports provided: default */

    /***/
    function DDP(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">BANK Statments</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n\n  <form #form=\"ngForm\" (ngSubmit)=\"addbankdetail()\">\n    <ion-item lines=\"none\">\n      <ion-label position=\"floating\">Invoice ID</ion-label>\n      <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"bank.invoice_id\"></ion-input>\n    </ion-item>\n    <ion-item lines=\"none\" class=\"option\">\n      <ion-label>Customer Name</ion-label>\n          <ion-select name=\"customer_id\" [(ngModel)]=\"customer4\" interface=\"action-sheet\">\n            <ion-select-option value={{a.customer_id}} *ngFor=\"let a of customer\">{{a.name}}</ion-select-option>\n          </ion-select>\n\n<!--      <ionic-selectable-->\n<!--              [(ngModel)]=\"customer4\"-->\n<!--              [items]=\"customer\"-->\n<!--              itemValueField=\"customer_id\"-->\n<!--              itemTextField=\"name\"-->\n<!--              [canSearch]=\"true\"-->\n<!--              [ngModelOptions]=\"{standalone: true}\"-->\n<!--      >-->\n<!--      </ionic-selectable>-->\n\n\n    </ion-item>\n    <ion-item lines=\"none\">\n      <ion-label position=\"floating\">Bank Name / Title</ion-label>\n      <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"bank.name\"></ion-input>\n    </ion-item>\n<!--    <ion-item lines=\"none\">-->\n<!--      <ion-label position=\"floating\">Account Title</ion-label>-->\n<!--      <ion-input name=\"title\" type=\"text\" [(ngModel)]=\"bank.title\"></ion-input>-->\n<!--    </ion-item>-->\n<!--    <ion-item lines=\"none\">-->\n<!--      <ion-label position=\"floating\">Account No</ion-label>-->\n<!--      <ion-input name=\"no\" type=\"text\" [(ngModel)]=\"bank.no\"></ion-input>-->\n<!--    </ion-item>-->\n    <ion-item lines=\"none\">\n      <ion-label position=\"floating\">Received Ammount</ion-label>\n      <ion-input name=\"no\" type=\"text\" [(ngModel)]=\"bank.ammount\"></ion-input>\n    </ion-item>\n    <ion-item lines=\"none\">\n      <ion-label position=\"floating\">Credit Ammount</ion-label>\n      <ion-input name=\"no\" type=\"text\" [(ngModel)]=\"bank.credit\"></ion-input>\n    </ion-item>\n\n    <ion-button expand=\"block\" color=\"light\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n  </form>\n\n  <table>\n    <thead>\n    <tr>\n      <th style=\"background: #333; \">Date</th>\n      <th style=\"background: #333; \">Invoice ID</th>\n      <th style=\"background: #333; \">name</th>\n      <th style=\"background: rgb(4, 151, 70); \">Bank</th>\n<!--      <th style=\"background: rgb(204, 13, 13); \">ACC Title</th>-->\n<!--      <th style=\"background: rgb(204, 13, 13); \">ACC NO</th>-->\n      <th style=\"background: rgb(204, 13, 13); \">Debit</th>\n      <th style=\"background: rgb(204, 13, 13); \">Credit</th>\n      <th style=\"background: rgb(204, 13, 13); \">Net Balance</th>\n    </tr>\n    </thead>\n    <tbody>\n\n    <tr *ngFor=\"let a of bankdetail\">\n      <td>{{a.date}}</td>\n      <td (click)=\"getdetail(a.invoice_id)\">{{a.invoice_id}}</td>\n      <td>{{a.name}}</td>\n      <td>{{a.bank_name}}</td>\n<!--      <td>{{a.account_title}}</td>-->\n<!--      <td>{{a.account_no}}</td>-->\n      <td>{{a.receive_ammount}}</td>\n          <td>{{a.credit}}</td>\n      <td> {{a.net_balance}}</td>\n    </tr>\n    </tbody>\n  </table>\n</ion-content>\n";
      /***/
    },

    /***/
    "Qo+j":
    /*!*********************************************************!*\
      !*** ./src/app/bankdetail/bankdetail-routing.module.ts ***!
      \*********************************************************/

    /*! exports provided: BankdetailPageRoutingModule */

    /***/
    function QoJ(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "BankdetailPageRoutingModule", function () {
        return BankdetailPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _bankdetail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./bankdetail.page */
      "4FKN");

      var routes = [{
        path: '',
        component: _bankdetail_page__WEBPACK_IMPORTED_MODULE_3__["BankdetailPage"]
      }];

      var BankdetailPageRoutingModule = function BankdetailPageRoutingModule() {
        _classCallCheck(this, BankdetailPageRoutingModule);
      };

      BankdetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], BankdetailPageRoutingModule);
      /***/
    },

    /***/
    "g8K4":
    /*!*************************************************!*\
      !*** ./src/app/bankdetail/bankdetail.page.scss ***!
      \*************************************************/

    /*! exports provided: default */

    /***/
    function g8K4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #5f8ff8, #ffffff);\n  /* Zebra striping */\n}\n\n@media screen and (max-width: 550px) {\n  ion-content td, ion-content th {\n    font-size: 14px;\n  }\n}\n\n@media screen and (max-width: 500px) {\n  ion-content td, ion-content th {\n    font-size: 12px;\n  }\n}\n\n@media screen and (max-width: 450px) {\n  ion-content td, ion-content th {\n    font-size: 11px;\n  }\n}\n\n@media screen and (max-width: 400px) {\n  ion-content td, ion-content th {\n    font-size: 10px;\n  }\n}\n\n@media screen and (max-width: 370px) {\n  ion-content td, ion-content th {\n    font-size: 9px;\n  }\n}\n\nion-content table {\n  width: 100%;\n  border-collapse: collapse;\n}\n\nion-content tr:nth-of-type(odd) {\n  background: #eee;\n}\n\nion-content th {\n  background: #333;\n  color: white;\n}\n\nion-content td, ion-content th {\n  padding: 3px;\n  border: 1px solid #ccc;\n  text-align: left;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2JhbmtkZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usc0NBQUE7QUFDRjs7QUFDQTtFQUNFLDBEQUFBO0VBK0JBLG1CQUFBO0FBNUJGOztBQUZFO0VBQ0U7SUFDRSxlQUFBO0VBSUo7QUFDRjs7QUFGRTtFQUNFO0lBQ0UsZUFBQTtFQUlKO0FBQ0Y7O0FBRkU7RUFDRTtJQUNFLGVBQUE7RUFJSjtBQUNGOztBQUZFO0VBQ0U7SUFDRSxlQUFBO0VBSUo7QUFDRjs7QUFGRTtFQUNFO0lBQ0UsY0FBQTtFQUlKO0FBQ0Y7O0FBREU7RUFDRSxXQUFBO0VBQ0EseUJBQUE7QUFHSjs7QUFBRTtFQUNFLGdCQUFBO0FBRUo7O0FBQUU7RUFDRSxnQkFBQTtFQUNBLFlBQUE7QUFFSjs7QUFBRTtFQUNFLFlBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0FBRUoiLCJmaWxlIjoiYmFua2RldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc3VjY2Vzcyk7XHJcbn1cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgIzVmOGZmOCwgI2ZmZmZmZik7XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTUwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIH1cclxuICB9XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIH1cclxuICB9XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDUwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgIH1cclxuICB9XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDAwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgIH1cclxuICB9XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMzcwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogOXB4O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgdGFibGUge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG4gIH1cclxuICAvKiBaZWJyYSBzdHJpcGluZyAqL1xyXG4gIHRyOm50aC1vZi10eXBlKG9kZCkge1xyXG4gICAgYmFja2dyb3VuZDogI2VlZTtcclxuICB9XHJcbiAgdGgge1xyXG4gICAgYmFja2dyb3VuZDogIzMzMztcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICB9XHJcbiAgdGQsIHRoIHtcclxuICAgIHBhZGRpbmc6IDNweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gIH1cclxuXHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "oadO":
    /*!*************************************************!*\
      !*** ./src/app/bankdetail/bankdetail.module.ts ***!
      \*************************************************/

    /*! exports provided: BankdetailPageModule */

    /***/
    function oadO(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "BankdetailPageModule", function () {
        return BankdetailPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _bankdetail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./bankdetail-routing.module */
      "Qo+j");
      /* harmony import */


      var _bankdetail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./bankdetail.page */
      "4FKN");
      /* harmony import */


      var ionic_selectable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ionic-selectable */
      "8xsl");

      var BankdetailPageModule = function BankdetailPageModule() {
        _classCallCheck(this, BankdetailPageModule);
      };

      BankdetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _bankdetail_routing_module__WEBPACK_IMPORTED_MODULE_5__["BankdetailPageRoutingModule"], ionic_selectable__WEBPACK_IMPORTED_MODULE_7__["IonicSelectableModule"]],
        declarations: [_bankdetail_page__WEBPACK_IMPORTED_MODULE_6__["BankdetailPage"]]
      })], BankdetailPageModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=bankdetail-bankdetail-module-es5.js.map