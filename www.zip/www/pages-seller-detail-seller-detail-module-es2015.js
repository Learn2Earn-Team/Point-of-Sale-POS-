(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-seller-detail-seller-detail-module"],{

/***/ "7l5i":
/*!*************************************************************!*\
  !*** ./src/app/pages/seller-detail/seller-detail.module.ts ***!
  \*************************************************************/
/*! exports provided: SellerDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SellerDetailPageModule", function() { return SellerDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _seller_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./seller-detail-routing.module */ "kyrl");
/* harmony import */ var _seller_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./seller-detail.page */ "FQ/o");







let SellerDetailPageModule = class SellerDetailPageModule {
};
SellerDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _seller_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["SellerDetailPageRoutingModule"]
        ],
        declarations: [_seller_detail_page__WEBPACK_IMPORTED_MODULE_6__["SellerDetailPage"]]
    })
], SellerDetailPageModule);



/***/ }),

/***/ "FQ/o":
/*!***********************************************************!*\
  !*** ./src/app/pages/seller-detail/seller-detail.page.ts ***!
  \***********************************************************/
/*! exports provided: SellerDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SellerDetailPage", function() { return SellerDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_seller_detail_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./seller-detail.page.html */ "L+gN");
/* harmony import */ var _seller_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./seller-detail.page.scss */ "yGfm");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/provider/apicall.service */ "G1p3");
/* harmony import */ var src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/provider/global.service */ "Lb7+");







let SellerDetailPage = class SellerDetailPage {
    constructor(alert, actionSheetCtrl, menu, apicall, global) {
        this.alert = alert;
        this.actionSheetCtrl = actionSheetCtrl;
        this.menu = menu;
        this.apicall = apicall;
        this.global = global;
        this.last = { net_balance: 0 };
        this.history = { invoice_id: null, name: 'Distributer', type: null, quantity: null, action: null, user: null };
        this.updatedetail = { s_id: '', net_balance: '', received: '' };
    }
    ngOnInit() {
        this.global.Sellerdetails.subscribe(res => {
            this.data = res;
            console.log(this.data);
            this.last = this.data[this.data.length - 1];
            //  console.log(this.last.net_balance);
        });
    }
    updatesellerbalance() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.updatedetail.s_id = this.data[0].s_id;
            this.updatedetail.net_balance = this.last.net_balance;
            this.updatedetail.received = this.rece;
            console.log(this.updatedetail);
            this.apicall.api_updatesellerbalance(this.updatedetail);
            this.history.type = this.data[0].seller_name;
            this.history.action = 'give balance';
            this.history.quantity = this.rece;
            this.global.User.subscribe(res => {
                this.history.user = res.username;
            });
            this.apicall.api_inserthistory(this.history);
        });
    }
};
SellerDetailPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"] },
    { type: src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__["ApicallService"] },
    { type: src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__["GlobalService"] }
];
SellerDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-seller-detail',
        template: _raw_loader_seller_detail_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_seller_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SellerDetailPage);



/***/ }),

/***/ "L+gN":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/seller-detail/seller-detail.page.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\" *ngIf=\"data!=''\">{{data[0].seller_name}}</ion-title>\n    <ion-title color=\"light\" *ngIf=\"data ==''\">no data found</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <table>\n    <thead>\n    <tr>\n      <th style=\"background: #333; \">Date</th>\n      <th style=\"background: #333; \">Invoice ID</th>\n      <th style=\"background: rgb(204, 13, 13); \">Credit</th>\n      <th style=\"background: rgb(4, 151, 70); \">Debit</th>\n      <th style=\"background: rgb(204, 13, 13); \">Net Balance</th>\n    </tr>\n    </thead>\n    <tbody>\n\n    <tr *ngFor=\"let a of data\">\n      <td>{{a.date}}</td>\n      <td>{{a.pi_id}}</td>\n      <td>{{a.credit}}</td>\n      <td>{{a.debit}}</td>\n      <td>{{a.net_balance}}</td>\n      <!--       <ion-button style=\"margin: 1px\" (click)=\"updatecustomerbalance(a)\"></ion-button>-->\n    </tr>\n    </tbody>\n  </table>\n  <ion-item  style=\"--background: transparent;\">\n    <ion-label >\n      Net Balance\n    </ion-label>\n    <ion-label text-right *ngIf=\"last === ''\">\n      {{this.last.net_balance}}\n    </ion-label>\n  </ion-item>\n  <ion-item style=\"--background: transparent;\">\n    <ion-label style=\"width: 80%;\">\n      Recevied\n    </ion-label>\n    <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"rece\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n  </ion-item>\n\n  <ion-button  expand=\"block\" color=\"success\" style=\"margin:10px;height:2.5rem\" (click) = updatesellerbalance()>Total</ion-button>\n\n</ion-content>\n");

/***/ }),

/***/ "kyrl":
/*!*********************************************************************!*\
  !*** ./src/app/pages/seller-detail/seller-detail-routing.module.ts ***!
  \*********************************************************************/
/*! exports provided: SellerDetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SellerDetailPageRoutingModule", function() { return SellerDetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _seller_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./seller-detail.page */ "FQ/o");




const routes = [
    {
        path: '',
        component: _seller_detail_page__WEBPACK_IMPORTED_MODULE_3__["SellerDetailPage"]
    }
];
let SellerDetailPageRoutingModule = class SellerDetailPageRoutingModule {
};
SellerDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SellerDetailPageRoutingModule);



/***/ }),

/***/ "yGfm":
/*!*************************************************************!*\
  !*** ./src/app/pages/seller-detail/seller-detail.page.scss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #5f8ff8, #ffffff);\n  /* Zebra striping */\n}\n\n@media screen and (max-width: 550px) {\n  ion-content td, ion-content th {\n    font-size: 14px;\n  }\n}\n\n@media screen and (max-width: 500px) {\n  ion-content td, ion-content th {\n    font-size: 12px;\n  }\n}\n\n@media screen and (max-width: 450px) {\n  ion-content td, ion-content th {\n    font-size: 11px;\n  }\n}\n\n@media screen and (max-width: 400px) {\n  ion-content td, ion-content th {\n    font-size: 10px;\n  }\n}\n\n@media screen and (max-width: 370px) {\n  ion-content td, ion-content th {\n    font-size: 9px;\n  }\n}\n\nion-content table {\n  width: 100%;\n  border-collapse: collapse;\n}\n\nion-content tr:nth-of-type(odd) {\n  background: #eee;\n}\n\nion-content th {\n  background: #333;\n  color: white;\n}\n\nion-content td, ion-content th {\n  padding: 3px;\n  border: 1px solid #ccc;\n  text-align: left;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NlbGxlci1kZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usc0NBQUE7QUFDRjs7QUFDQTtFQUNFLDBEQUFBO0VBK0JBLG1CQUFBO0FBNUJGOztBQUZFO0VBQ0U7SUFDRSxlQUFBO0VBSUo7QUFDRjs7QUFGRTtFQUNFO0lBQ0UsZUFBQTtFQUlKO0FBQ0Y7O0FBRkU7RUFDRTtJQUNFLGVBQUE7RUFJSjtBQUNGOztBQUZFO0VBQ0U7SUFDRSxlQUFBO0VBSUo7QUFDRjs7QUFGRTtFQUNFO0lBQ0UsY0FBQTtFQUlKO0FBQ0Y7O0FBREU7RUFDRSxXQUFBO0VBQ0EseUJBQUE7QUFHSjs7QUFBRTtFQUNFLGdCQUFBO0FBRUo7O0FBQUU7RUFDRSxnQkFBQTtFQUNBLFlBQUE7QUFFSjs7QUFBRTtFQUNFLFlBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0FBRUoiLCJmaWxlIjoic2VsbGVyLWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XHJcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc3VjY2Vzcyk7XHJcbn1cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgIzVmOGZmOCwgI2ZmZmZmZik7XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTUwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIH1cclxuICB9XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIH1cclxuICB9XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDUwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgIH1cclxuICB9XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDAwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgIH1cclxuICB9XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMzcwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogOXB4O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgdGFibGUge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG4gIH1cclxuICAvKiBaZWJyYSBzdHJpcGluZyAqL1xyXG4gIHRyOm50aC1vZi10eXBlKG9kZCkge1xyXG4gICAgYmFja2dyb3VuZDogI2VlZTtcclxuICB9XHJcbiAgdGgge1xyXG4gICAgYmFja2dyb3VuZDogIzMzMztcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICB9XHJcbiAgdGQsIHRoIHtcclxuICAgIHBhZGRpbmc6IDNweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gIH1cclxuXHJcbn1cclxuIl19 */");

/***/ })

}]);
//# sourceMappingURL=pages-seller-detail-seller-detail-module-es2015.js.map