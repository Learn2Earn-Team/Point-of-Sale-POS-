(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-medicine-medicine-module"],{

/***/ "FzX5":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/medicine/medicine.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Dairy Links</ion-title>\n    <ion-icon slot=\"end\" name=\"cart\" routerLink=\"/type\" style=\"zoom: 2;margin-right: 7px;\" color=\"light\"></ion-icon>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-segment color=\"dark\" [(ngModel)]=\"sign\">\n    <ion-segment-button value=\"in\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Add New Product</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"up\" (click)=\"fresh()\">\n      <ion-icon name=\"eye-outline\"></ion-icon>\n      <ion-label> See Stock</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n\n  <div color=\"success\" class=\"main\" [ngSwitch]=\"sign\">\n\n    <ion-list class=\"f\" *ngSwitchCase=\"'in'\">\n      <form #form=\"ngForm\" (ngSubmit)=\"add()\">\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\"  >Product Name:</ion-label>\n          <ion-input type=\"text\" name=\"name\" [(ngModel)]=\"medicine.name\" ></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\" class=\"option\">\n          <ion-label>Manufactured BY</ion-label>\n          <ion-select name=\"id\" [(ngModel)]=\"medicine.c_id\" interface=\"action-sheet\">\n            <ion-select-option value={{a.c_id}} *ngFor=\"let a of company\">{{a.c_name}}</ion-select-option>\n          </ion-select>\n        </ion-item>\n        <ion-item lines=\"none\" class=\"option\">\n          <ion-label>Markted BY</ion-label>\n          <ion-select name=\"c_id\" [(ngModel)]=\"medicine.marketed\" interface=\"action-sheet\">\n            <ion-select-option value={{a.c_name}} *ngFor=\"let a of company\">{{a.c_name}}</ion-select-option>\n          </ion-select>\n        </ion-item>\n        <ion-item lines=\"none\" class=\"option\">\n          <ion-label>Type Name</ion-label>\n          <ion-select name=\"t_id\" [(ngModel)]=\"medicine.t_id\" interface=\"action-sheet\">\n            <ion-select-option value={{a.t_id}} *ngFor=\"let a of type\">{{a.name}}</ion-select-option>\n          </ion-select>\n        </ion-item>\n        <ion-item lines=\"none\" style=\"--background: transparent;\" *ngIf=\"updat==null\">\n          <ion-label >Select Gradients</ion-label>\n          <ion-select interface=\"action-sheet\" name=\"array\" [(ngModel)]=\"selectedArray\"\n            (ionChange)=\"onChange()\">\n            <ion-select-option [value]=\"1\">1</ion-select-option>\n            <ion-select-option [value]=\"2\">2</ion-select-option>\n            <ion-select-option [value]=\"3\">3</ion-select-option>\n            <ion-select-option [value]=\"4\">4</ion-select-option>\n          </ion-select>\n        </ion-item>\n        <ion-item class=\"fields\" *ngFor=\"let a of packing\">\n          <ion-input type=\"text\" placeholder=\"Enter Packing\" name=\"packing\" [(ngModel)]=\"a.packing\"></ion-input>\n        </ion-item>\n        <ion-button expand=\"block\" type=\"submit\" color=\"light\">Add</ion-button>\n      </form>\n    </ion-list>\n    <ion-list class=\"f\" *ngSwitchCase=\"'up'\">\n      <ion-searchbar  (ionInput)=\"filter($event)\"></ion-searchbar>\n      <ion-grid>\n    \n        <ion-row color=\"success\" >\n          <ion-col *ngFor=\"let a of medi; let i = index\" >\n            <ion-item text-center lines=\"none\"><ion-label>Product Name:{{a.name}}</ion-label></ion-item>\n            <ion-item text-center lines=\"none\"><ion-label>Packing size:{{a.packing_name}}</ion-label></ion-item>\n            <ion-item text-center lines=\"none\"><ion-label>Avaiable Stock:{{a.total_quantity}}</ion-label></ion-item>\n            <ion-item text-center lines=\"none\"><ion-label>Company Name:{{a.company_name}}</ion-label></ion-item>\n            <ion-item  text-center lines=\"none\"><ion-label>Product Type:{{a.medicine_type}}</ion-label></ion-item>\n            <ion-button color=\"light\" expand=\"block\" (click)=\"addcart(a.p_id)\" >Add to Cart</ion-button>\n            <ion-row><ion-button color=\"light\" expand=\"block\" style=\" float:left; width: 7rem;\" (click)=\"detail(a.m_id,a.p_id)\">See Details</ion-button><ion-button color=\"light\" style=\"float:right; width: 5rem;\" expand=\"block\" (click)=\"update(a)\">Update</ion-button></ion-row>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-list>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ "Lsh7":
/*!***************************************************!*\
  !*** ./src/app/pages/medicine/medicine.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #5f8ff8, #ffffff);\n}\n\nion-content .main {\n  background: transparent;\n}\n\nion-content .main ion-list {\n  background-color: transparent;\n  padding-bottom: 5rem;\n}\n\nion-content .main ion-list ion-grid {\n  margin: 10px;\n  justify-content: center;\n  align-content: center;\n}\n\nion-content .main ion-list ion-grid ion-row {\n  justify-content: center;\n}\n\nion-content .main ion-list ion-grid ion-row ion-col {\n  background: var(--ion-color-success);\n  box-shadow: 4px 10px 30px -3px #050505;\n  min-width: 15rem;\n  max-width: 15rem;\n  height: 19.5rem;\n  margin: 10px;\n  text-align: center;\n  justify-content: center;\n  border-radius: 20px;\n}\n\nion-content .main ion-list ion-grid ion-row ion-col ion-item {\n  margin: -8px;\n  text-align: center;\n  justify-content: center;\n  --background: transparent;\n}\n\nion-content .main ion-list ion-grid ion-row ion-col ion-item ion-label {\n  font-size: 0.8rem;\n  color: var(--ion-color-light);\n}\n\nion-content .main ion-list ion-grid ion-row ion-col ion-button {\n  margin: 0.5rem;\n  --border-radius: 20px;\n  height: 2rem;\n}\n\nion-content .main ion-list ion-item {\n  --background: transparent;\n  width: 100%;\n}\n\nion-content .main ion-list ion-item ion-input {\n  margin-top: -10px;\n  border-bottom: 1px solid black;\n}\n\nion-content .main ion-list .option {\n  margin-left: 15px;\n  margin-right: 15px;\n  width: 96%;\n  border-bottom: 1px solid black;\n}\n\nion-content .main ion-list .start {\n  float: left;\n}\n\nion-content .main ion-list .end {\n  float: right;\n}\n\nion-content .main ion-list ion-button {\n  margin: 15px 20px 15px 20px;\n  border-radius: 30px;\n  box-shadow: 4px 9px 29px -9px #050505;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL21lZGljaW5lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHNDQUFBO0FBQ0o7O0FBQ0E7RUFDRSwwREFBQTtBQUVGOztBQURJO0VBQ0ksdUJBQUE7QUFHUjs7QUFGUTtFQUNJLDZCQUFBO0VBQ0Esb0JBQUE7QUFJWjs7QUFIWTtFQUNJLFlBQUE7RUFDQSx1QkFBQTtFQUNBLHFCQUFBO0FBS2hCOztBQUpnQjtFQUNJLHVCQUFBO0FBTXBCOztBQUxvQjtFQUNJLG9DQUFBO0VBQ0Esc0NBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBRUEsbUJBQUE7QUFNeEI7O0FBTHdCO0VBQ0ksWUFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSx5QkFBQTtBQU81Qjs7QUFONEI7RUFDSSxpQkFBQTtFQUNBLDZCQUFBO0FBUWhDOztBQUx3QjtFQUNJLGNBQUE7RUFDQSxxQkFBQTtFQUNBLFlBQUE7QUFPNUI7O0FBRlk7RUFDSSx5QkFBQTtFQUNBLFdBQUE7QUFJaEI7O0FBSGdCO0VBQ0ksaUJBQUE7RUFDQSw4QkFBQTtBQUtwQjs7QUFGWTtFQUNJLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsOEJBQUE7QUFJaEI7O0FBRlk7RUFDSSxXQUFBO0FBSWhCOztBQUZZO0VBQ0ksWUFBQTtBQUloQjs7QUFGWTtFQUNJLDJCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQ0FBQTtBQUloQiIsImZpbGUiOiJtZWRpY2luZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjNWY4ZmY4LCAjZmZmZmZmKTtcclxuICAgIC5tYWlue1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIGlvbi1saXN0e1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICAgICAgcGFkZGluZy1ib3R0b206IDVyZW07XHJcbiAgICAgICAgICAgIGlvbi1ncmlkIHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbjogMTBweDtcclxuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgYWxpZ24tY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgaW9uLXJvdyB7XHJcbiAgICAgICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgaW9uLWNvbCB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm94LXNoYWRvdzogNHB4IDEwcHggMzBweCAtM3B4ICMwNTA1MDU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1pbi13aWR0aDogMTVyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heC13aWR0aDogMTVyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogMTkuNXJlbTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAxMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBtYXgtaGVpZ2h0OiAxMnJlbTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaW9uLWl0ZW0ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAtOHB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMC44cmVtO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwLjVyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAtLWJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDJyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW9uLWl0ZW17XHJcbiAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICBpb24taW5wdXR7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogLTEwcHg7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGJsYWNrO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5vcHRpb257XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTVweDtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogMTVweDtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiA5NiU7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgYmxhY2s7ICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAuc3RhcnQge1xyXG4gICAgICAgICAgICAgICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLmVuZCB7XHJcbiAgICAgICAgICAgICAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW9uLWJ1dHRvbntcclxuICAgICAgICAgICAgICAgIG1hcmdpbjoxNXB4IDIwcHggMTVweCAyMHB4O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgICAgICAgICAgICAgIGJveC1zaGFkb3c6IDRweCA5cHggMjlweCAtOXB4ICMwNTA1MDU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "bwnB":
/*!***************************************************!*\
  !*** ./src/app/pages/medicine/medicine.module.ts ***!
  \***************************************************/
/*! exports provided: MedicinePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MedicinePageModule", function() { return MedicinePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _medicine_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./medicine-routing.module */ "gVXH");
/* harmony import */ var _medicine_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./medicine.page */ "qUyQ");







let MedicinePageModule = class MedicinePageModule {
};
MedicinePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _medicine_routing_module__WEBPACK_IMPORTED_MODULE_5__["MedicinePageRoutingModule"]
        ],
        declarations: [_medicine_page__WEBPACK_IMPORTED_MODULE_6__["MedicinePage"]]
    })
], MedicinePageModule);



/***/ }),

/***/ "gVXH":
/*!***********************************************************!*\
  !*** ./src/app/pages/medicine/medicine-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: MedicinePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MedicinePageRoutingModule", function() { return MedicinePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _medicine_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./medicine.page */ "qUyQ");




const routes = [
    {
        path: '',
        component: _medicine_page__WEBPACK_IMPORTED_MODULE_3__["MedicinePage"]
    }
];
let MedicinePageRoutingModule = class MedicinePageRoutingModule {
};
MedicinePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MedicinePageRoutingModule);



/***/ }),

/***/ "qUyQ":
/*!*************************************************!*\
  !*** ./src/app/pages/medicine/medicine.page.ts ***!
  \*************************************************/
/*! exports provided: MedicinePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MedicinePage", function() { return MedicinePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_medicine_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./medicine.page.html */ "FzX5");
/* harmony import */ var _medicine_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./medicine.page.scss */ "Lsh7");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/provider/apicall.service */ "G1p3");
/* harmony import */ var src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/provider/global.service */ "Lb7+");








let MedicinePage = class MedicinePage {
    constructor(toastController, router, menu, apicall, global) {
        this.toastController = toastController;
        this.router = router;
        this.menu = menu;
        this.apicall = apicall;
        this.global = global;
        this.cartmed = [];
        this.purchase = [];
        this.medicine = { m_id: null, c_id: null, t_id: null, name: null, marketed: null };
        this.data = { medicine: {}, packing: {} };
        this.id1 = { m_id: '', p_id: '' };
        this.updat = null;
    }
    onChange() {
        this.packing = [];
        for (let index = 0; index < this.selectedArray; index++) {
            this.packing.push({ packing: '' });
        }
        console.log(this.packing);
    }
    // tslint:disable-next-line:variable-name
    detail(id, p_id) {
        console.log(id, p_id);
        this.id1.m_id = id;
        this.id1.p_id = p_id;
        console.log(this.id1);
        this.global.set_Ids(this.id1);
        this.apicall.api_showmedidetail(this.id1);
        // this.apicall.api_getdetail(id);
    }
    ngOnInit() {
        this.apicall.api_getmedicine();
        this.global.Medicine.subscribe(res => {
            this.med = res;
            this.medi = res;
        });
        this.sign = 'in';
        this.apicall.api_gettype();
        this.global.Type.subscribe(res => {
            this.type = res;
        });
        this.apicall.api_getcompany();
        this.global.Company.subscribe(res => {
            this.company = res;
            this.company2 = res;
        });
        this.apicall.api_getseller();
        this.global.Seller.subscribe(res => {
            this.seller = res;
        });
    }
    add() {
        if (this.updat == null) {
            this.data.medicine = this.medicine;
            this.data.packing = this.packing;
            console.log(this.medicine);
            this.apicall.api_insertmedicine(this.data);
            this.medicine = { c_id: null, s_id: null, t_id: null, name: null, marketed: null };
            this.selectedArray = null;
        }
        else {
            console.log(this.medicine, 'update');
            console.log(this.updat);
            this.apicall.api_updatemedicine(this.medicine);
            this.presentToast();
            this.medicine = { c_id: null, s_id: null, t_id: null, name: null, marketed: null };
            this.updat = null;
        }
    }
    fresh() {
        this.apicall.api_getmedicine();
        this.global.Medicine.subscribe(res => {
            this.med = res;
        });
    }
    filter(evt) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.medi = this.med;
            const val = evt.target.value;
            if (val && val.trim() != '') {
                this.medi = this.medi.filter((item) => {
                    return ((item.name.toLowerCase()).startsWith(val.toLowerCase()));
                });
            }
        });
    }
    addcart(a) {
        this.cart = this.medi.filter(medi => medi.p_id === a);
        console.log(a);
        console.log(this.cart, 'ass');
        this.purchase.push({
            med_name: this.cart[0].name,
            packing_name: this.cart[0].packing_name,
            m_id: this.cart[0].m_id,
            p_id: this.cart[0].p_id,
            man_date: '',
            ex_date: ''
        });
        // this.dat = this.dat.filter(data => data.p_id != a.p_id);
        // console.log(this.cartmed);
        console.log(this.purchase);
        this.global.set_Cartmed(this.purchase);
        this.presentToast();
    }
    presentToast() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: 'Added to Cart',
                duration: 2000
            });
            toast.present();
        });
    }
    update(updat) {
        this.updat = updat;
        this.medicine.m_id = updat.m_id;
        this.medicine.name = updat.name;
        this.medicine.c_id = updat.c_id;
        this.medicine.marketed = updat.company_name;
        this.medicine.t_id = updat.t_id;
        this.sign = 'in';
    }
};
MedicinePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["MenuController"] },
    { type: src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_6__["ApicallService"] },
    { type: src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_7__["GlobalService"] }
];
MedicinePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-medicine',
        template: _raw_loader_medicine_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_medicine_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MedicinePage);



/***/ })

}]);
//# sourceMappingURL=pages-medicine-medicine-module-es2015.js.map