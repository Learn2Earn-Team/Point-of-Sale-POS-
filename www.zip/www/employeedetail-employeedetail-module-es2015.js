(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["employeedetail-employeedetail-module"],{

/***/ "3uQQ":
/*!*********************************************************!*\
  !*** ./src/app/employeedetail/employeedetail.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #5f8ff8, #ffffff);\n}\n\nion-content ion-item {\n  --background: transparent;\n}\n\nion-content ion-item ion-input {\n  border-bottom: 1px solid black;\n}\n\nion-content ion-button {\n  margin: 15px 20px 15px 20px;\n  border-radius: 30px;\n  box-shadow: 4px 9px 29px -9px #050505;\n}\n\nion-content ion-list {\n  background: transparent;\n}\n\nion-row {\n  width: 90%;\n}\n\nion-row ion-item {\n  width: 100%;\n  margin-top: 0;\n  margin-bottom: -1rem;\n}\n\nion-row ion-item ion-row {\n  justify-content: center;\n}\n\nion-row ion-item ion-row ion-label {\n  font-size: small;\n  margin-top: 0;\n  margin-bottom: 0;\n  margin-left: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uL2VtcGxveWVlZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHNDQUFBO0FBQ0Y7O0FBQ0E7RUFDRSwwREFBQTtBQUVGOztBQURFO0VBQ0UseUJBQUE7QUFHSjs7QUFGSTtFQUNFLDhCQUFBO0FBSU47O0FBREU7RUFDRSwyQkFBQTtFQUNBLG1CQUFBO0VBQ0EscUNBQUE7QUFHSjs7QUFERTtFQUNFLHVCQUFBO0FBR0o7O0FBQUE7RUFDRSxVQUFBO0FBR0Y7O0FBRkU7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0FBSUo7O0FBSEk7RUFDRSx1QkFBQTtBQUtOOztBQUpNO0VBQ0UsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQU1SIiwiZmlsZSI6ImVtcGxveWVlZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFyIHtcclxuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjNWY4ZmY4LCAjZmZmZmZmKTtcclxuICBpb24taXRlbXtcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBpb24taW5wdXR7XHJcbiAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBibGFjaztcclxuICAgIH1cclxuICB9XHJcbiAgaW9uLWJ1dHRvbntcclxuICAgIG1hcmdpbjoxNXB4IDIwcHggMTVweCAyMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIGJveC1zaGFkb3c6IDRweCA5cHggMjlweCAtOXB4ICMwNTA1MDU7XHJcbiAgfVxyXG4gIGlvbi1saXN0e1xyXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgfVxyXG59XHJcbmlvbi1yb3d7XHJcbiAgd2lkdGg6OTAlO1xyXG4gIGlvbi1pdGVte1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW4tdG9wOiAwO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogLTFyZW07XHJcbiAgICBpb24tcm93e1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgIGZvbnQtc2l6ZTogc21hbGw7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMDtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAwO1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "BzX5":
/*!*********************************************************!*\
  !*** ./src/app/employeedetail/employeedetail.module.ts ***!
  \*********************************************************/
/*! exports provided: EmployeedetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmployeedetailPageModule", function() { return EmployeedetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _employeedetail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./employeedetail-routing.module */ "fk2w");
/* harmony import */ var _employeedetail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./employeedetail.page */ "PyUk");







let EmployeedetailPageModule = class EmployeedetailPageModule {
};
EmployeedetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _employeedetail_routing_module__WEBPACK_IMPORTED_MODULE_5__["EmployeedetailPageRoutingModule"]
        ],
        declarations: [_employeedetail_page__WEBPACK_IMPORTED_MODULE_6__["EmployeedetailPage"]]
    })
], EmployeedetailPageModule);



/***/ }),

/***/ "ChFK":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/employeedetail/employeedetail.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Bank Statments</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-list>\n  <form #form=\"ngForm\" (ngSubmit)=\"addcu()\">\n    <ion-item lines=\"none\">\n      <ion-label position=\"floating\">Bank Name</ion-label>\n      <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"bank.name\"></ion-input>\n    </ion-item>\n    <ion-item lines=\"none\">\n      <ion-label position=\"floating\">Account Title</ion-label>\n      <ion-input name=\"title\" type=\"text\" [(ngModel)]=\"bank.title\"></ion-input>\n    </ion-item>\n    <ion-item lines=\"none\">\n      <ion-label position=\"floating\">Account No</ion-label>\n      <ion-input name=\"no\" type=\"text\" [(ngModel)]=\"bank.no\"></ion-input>\n    </ion-item>\n    <ion-button expand=\"block\" color=\"light\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n  </form>\n  <ion-searchbar (ionInput)=\"filtercu($event)\"></ion-searchbar>\n  <ion-item-sliding *ngFor=\"let a of banks\">\n    <ion-item>\n      {{a.name}}\n      {{a.net_balance}}\n    </ion-item>\n    <ion-item-options side=\"end\">\n      <ion-item-option color=\"success\" (click)=\"detailbank(a.b_id)\">See Detail</ion-item-option>\n    </ion-item-options>\n  </ion-item-sliding>\n  </ion-list>\n</ion-content>\n");

/***/ }),

/***/ "PyUk":
/*!*******************************************************!*\
  !*** ./src/app/employeedetail/employeedetail.page.ts ***!
  \*******************************************************/
/*! exports provided: EmployeedetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmployeedetailPage", function() { return EmployeedetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_employeedetail_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./employeedetail.page.html */ "ChFK");
/* harmony import */ var _employeedetail_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./employeedetail.page.scss */ "3uQQ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../provider/apicall.service */ "G1p3");
/* harmony import */ var _provider_global_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../provider/global.service */ "Lb7+");








let EmployeedetailPage = class EmployeedetailPage {
    constructor(loadingController, router, alert, actionSheetCtrl, menu, apicall, global) {
        this.loadingController = loadingController;
        this.router = router;
        this.alert = alert;
        this.actionSheetCtrl = actionSheetCtrl;
        this.menu = menu;
        this.apicall = apicall;
        this.global = global;
        this.bank = { name: null, title: null, no: null, total: null, remaining: null };
    }
    ngOnInit() {
        this.apicall.api_getbanks();
        this.global.Bank.subscribe(res => {
            this.bankk = res;
            this.banks = res;
        });
    }
    filtercu(evt) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.customer = this.custome;
            var val = evt.target.value;
            if (val && val.trim() != '') {
                this.customer = this.customer.filter((item) => {
                    return ((item.name.toLowerCase()).startsWith(val.toLowerCase()));
                });
            }
        });
    }
    addcu() {
        console.log(this.bank);
        this.apicall.api_addbank(this.bank);
        this.bank.name = null;
        this.bank.title = null;
        this.bank.no = null;
        this.bank.total = null;
        this.bank.remaining = null;
    }
    detailbank(id) {
        console.log(id);
        this.presentLoadingWithOptions();
        this.apicall.api_getbankdetail(id);
        this.presentLoadingWithOptions();
        this.router.navigate(['bankdetail'], { state: { data: id } });
    }
    presentLoadingWithOptions() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                spinner: "circular",
                duration: 200,
                message: 'Order Is Being Placed',
                translucent: true,
                cssClass: 'custom-class custom-loading',
                backdropDismiss: true
            });
            yield loading.present();
            const {} = yield loading.onDidDismiss();
        });
    }
};
EmployeedetailPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"] },
    { type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_6__["ApicallService"] },
    { type: _provider_global_service__WEBPACK_IMPORTED_MODULE_7__["GlobalService"] }
];
EmployeedetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-employeedetail',
        template: _raw_loader_employeedetail_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_employeedetail_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], EmployeedetailPage);



/***/ }),

/***/ "fk2w":
/*!*****************************************************************!*\
  !*** ./src/app/employeedetail/employeedetail-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: EmployeedetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmployeedetailPageRoutingModule", function() { return EmployeedetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _employeedetail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./employeedetail.page */ "PyUk");




const routes = [
    {
        path: '',
        component: _employeedetail_page__WEBPACK_IMPORTED_MODULE_3__["EmployeedetailPage"]
    }
];
let EmployeedetailPageRoutingModule = class EmployeedetailPageRoutingModule {
};
EmployeedetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EmployeedetailPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=employeedetail-employeedetail-module-es2015.js.map