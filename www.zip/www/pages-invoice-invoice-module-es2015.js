(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-invoice-invoice-module"],{

/***/ "7P6R":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/invoice/invoice.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Dairy Links</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-segment color=\"dark\" [(ngModel)]=\"sign\">\n    <ion-segment-button value=\"sale\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Sale Invoice</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"emp\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Emp Invoice</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"pur\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Purchasing Invoice</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n\n\n  <div color=\"success\" class=\"main\" [ngSwitch]=\"sign\">\n    <ion-list class=\"f\" *ngSwitchCase=\"'sale'\"  >\n  <ion-searchbar [(ngModel)]=\"term\"></ion-searchbar>\n    <table>\n      <thead>\n      <tr>\n        <th>Invoice_id</th>\n        <th>Date</th>\n        <th>Customer Name</th>\n        <th>Grand Total</th>\n        <th>See Detail</th>\n      </tr>\n      </thead>\n      <tbody>\n\n      <tr *ngFor=\"let a of invo |filter:term\">\n        <td>{{a.invoice_id}}</td>\n        <td>{{a.date}}</td>\n        <td>{{a.customer_name}}</td>\n        <td>{{a.total_sale}}</td>\n        <td>\n          <ion-button style=\"margin: 1px\" (click)=\"showdetail(a.invoice_id)\">See Detail</ion-button>\n        </td>\n      </tr>\n      </tbody>\n    </table>\n    </ion-list>\n    <ion-list class=\"f\" *ngSwitchCase=\"'emp'\"  >\n      <ion-searchbar [(ngModel)]=\"term1\"></ion-searchbar>\n      <table>\n        <thead>\n        <tr>\n          <th>Invoice_id</th>\n          <th>Date</th>\n          <th>Employee Name</th>\n          <th>Grand Total</th>\n          <th>See Detail</th>\n        </tr>\n        </thead>\n        <tbody>\n\n        <tr *ngFor=\"let a of invoemp |filter:term1\">\n          <td>{{a.invoice_id}}</td>\n          <td>{{a.date}}</td>\n          <td>{{a.name}}</td>\n          <td>{{a.total_sale}}</td>\n          <td>\n            <ion-button style=\"margin: 1px\" (click)=\"showdetailemp(a.invoice_id)\">See Detail</ion-button>\n          </td>\n        </tr>\n        </tbody>\n      </table>\n    </ion-list>\n    <ion-list class=\"f\" *ngSwitchCase=\"'pur'\"  >\n      <ion-searchbar [(ngModel)]=\"term2\"></ion-searchbar>\n      <table>\n        <thead>\n        <tr>\n          <th>Invoice_id</th>\n          <th>Distributor Name</th>\n          <th>Grand Total</th>\n          <th>Date</th>\n          <th>See Detail</th>\n        </tr>\n        </thead>\n        <tbody>\n\n        <tr *ngFor=\"let a of invopur |filter:term2\">\n          <td>{{a.pi_id}}</td>\n          <td>{{a.name}}</td>\n          <td>{{a.purchased }}</td>\n          <td>{{a.date}}</td>\n          <td>\n            <ion-button style=\"margin: 1px\" (click)=\"showdetailpur(a.pi_id)\">See Detail</ion-button>\n          </td>\n        </tr>\n        </tbody>\n      </table>\n    </ion-list>\n  </div>\n</ion-content>\n");

/***/ }),

/***/ "ODCs":
/*!*********************************************************!*\
  !*** ./src/app/pages/invoice/invoice-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: InvoicePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InvoicePageRoutingModule", function() { return InvoicePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _invoice_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./invoice.page */ "Tcr8");




const routes = [
    {
        path: '',
        component: _invoice_page__WEBPACK_IMPORTED_MODULE_3__["InvoicePage"]
    },
    {
        path: 'detail',
        loadChildren: () => __webpack_require__.e(/*! import() | detail-detail-module */ "common").then(__webpack_require__.bind(null, /*! ./detail/detail.module */ "5nHn")).then(m => m.DetailPageModule)
    }
];
let InvoicePageRoutingModule = class InvoicePageRoutingModule {
};
InvoicePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], InvoicePageRoutingModule);



/***/ }),

/***/ "Tcr8":
/*!***********************************************!*\
  !*** ./src/app/pages/invoice/invoice.page.ts ***!
  \***********************************************/
/*! exports provided: InvoicePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InvoicePage", function() { return InvoicePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_invoice_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./invoice.page.html */ "7P6R");
/* harmony import */ var _invoice_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./invoice.page.scss */ "XwH5");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/provider/apicall.service */ "G1p3");
/* harmony import */ var src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/provider/global.service */ "Lb7+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "tyNb");








let InvoicePage = class InvoicePage {
    constructor(router, menu, apicall, global) {
        this.router = router;
        this.menu = menu;
        this.apicall = apicall;
        this.global = global;
    }
    ngOnInit() {
        this.sign = 'sale';
        this.apicall.api_getinvoices();
        this.global.Invoice.subscribe(res => {
            this.invo = res;
            this.inv = res;
            console.log(this.invo);
        });
        this.apicall.api_getinvoicespur();
        this.global.Invoicepur.subscribe(res => {
            this.invopur = res;
            this.invpur = res;
            console.log(this.invo);
        });
        this.apicall.api_getinvoicesemp();
        this.global.Invoiceemp.subscribe(res => {
            this.invoemp = res;
            this.invemp = res;
            console.log(this.invoemp);
        });
    }
    showdetail(invoice_id) {
        this.apicall.api_getinvoicedetail(invoice_id);
        console.log(invoice_id);
        this.global.set_Purchasedetail('');
        this.router.navigate(['detail']);
    }
    showdetailemp(id) {
        this.apicall.api_getinvoicedetailemp(id);
        console.log(id);
        this.global.set_Purchasedetail('');
        this.router.navigate(['detail']);
    }
    showdetailpur(id) {
        this.apicall.api_getpurchase(id);
        console.log(id);
        this.global.set_Invoicedetail('');
        this.router.navigate(['detail']);
    }
    filterinvoice(evt) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.invo = this.inv;
            // tslint:disable-next-line:prefer-const
            var val = evt.target.value;
            if (val && val.trim() != '') {
                this.invo = this.invo.filter((item) => {
                    return ((item.customer_name.toLowerCase()).startsWith(val.toLowerCase()));
                });
            }
        });
    }
    filterinvoiceemp(evt) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.invoemp = this.invemp;
            // tslint:disable-next-line:prefer-const
            var val = evt.target.value;
            if (val && val.trim() != '') {
                this.invoemp = this.invoemp.filter((item) => {
                    return ((item.invoice_id.toLowerCase()).startsWith(val.toLowerCase()));
                });
            }
        });
    }
};
InvoicePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"] },
    { type: src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__["ApicallService"] },
    { type: src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__["GlobalService"] }
];
InvoicePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-invoice',
        template: _raw_loader_invoice_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_invoice_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], InvoicePage);



/***/ }),

/***/ "XwH5":
/*!*************************************************!*\
  !*** ./src/app/pages/invoice/invoice.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #5f8ff8, #ffffff);\n}\n\nion-content ion-grid {\n  margin: 10px;\n  justify-content: center;\n  align-content: center;\n}\n\nion-content ion-grid ion-row {\n  justify-content: center;\n}\n\nion-content ion-grid ion-row ion-col {\n  background: var(--ion-color-success);\n  box-shadow: 4px 10px 30px -3px #050505;\n  min-width: 18rem;\n  max-width: 18rem;\n  height: 14.5rem;\n  margin: 10px;\n  text-align: center;\n  justify-content: center;\n  border-radius: 20px;\n}\n\nion-content ion-grid ion-row ion-col ion-item {\n  margin: -8px;\n  margin-top: -15px;\n  text-align: center;\n  justify-content: center;\n  --background: transparent;\n}\n\nion-content ion-grid ion-row ion-col ion-item ion-label {\n  font-size: 0.8rem;\n  color: var(--ion-color-light);\n}\n\nion-content ion-grid ion-row ion-col ion-button {\n  margin: 0.5rem;\n  --border-radius: 20px;\n  height: 2rem;\n}\n\n@media screen and (max-width: 550px) {\n  td, th {\n    font-size: 14px;\n  }\n}\n\n@media screen and (max-width: 500px) {\n  td, th {\n    font-size: 12px;\n  }\n}\n\n@media screen and (max-width: 450px) {\n  td, th {\n    font-size: 11px;\n  }\n}\n\n@media screen and (max-width: 400px) {\n  td, th {\n    font-size: 10px;\n  }\n}\n\n@media screen and (max-width: 370px) {\n  td, th {\n    font-size: 9px;\n  }\n}\n\ntable {\n  width: 100%;\n  border-collapse: collapse;\n}\n\n/* Zebra striping */\n\ntr:nth-of-type(odd) {\n  background: #eee;\n}\n\nth {\n  background: #333;\n  color: white;\n}\n\ntd, th {\n  padding: 3px;\n  border: 1px solid #ccc;\n  text-align: left;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL2ludm9pY2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0NBQUE7QUFDSjs7QUFDQTtFQUNFLDBEQUFBO0FBRUY7O0FBREk7RUFDSSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxxQkFBQTtBQUdSOztBQUZRO0VBQ0ksdUJBQUE7QUFJWjs7QUFGWTtFQUNJLG9DQUFBO0VBQ0Esc0NBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBRUEsbUJBQUE7QUFHaEI7O0FBRGdCO0VBQ0ksWUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtFQUNBLHlCQUFBO0FBR3BCOztBQUZvQjtFQUNJLGlCQUFBO0VBQ0EsNkJBQUE7QUFJeEI7O0FBRGdCO0VBQ0ksY0FBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtBQUdwQjs7QUFJQTtFQUNJO0lBQ0ksZUFBQTtFQUROO0FBQ0Y7O0FBR0E7RUFDSTtJQUNJLGVBQUE7RUFETjtBQUNGOztBQUdBO0VBQ0k7SUFDSSxlQUFBO0VBRE47QUFDRjs7QUFHQTtFQUNJO0lBQ0ksZUFBQTtFQUROO0FBQ0Y7O0FBR0E7RUFDSTtJQUNJLGNBQUE7RUFETjtBQUNGOztBQUlBO0VBQ0ksV0FBQTtFQUNBLHlCQUFBO0FBRko7O0FBSUEsbUJBQUE7O0FBQ0E7RUFDSSxnQkFBQTtBQURKOztBQUdBO0VBQ0ksZ0JBQUE7RUFDQSxZQUFBO0FBQUo7O0FBRUE7RUFDSSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxnQkFBQTtBQUNKIiwiZmlsZSI6Imludm9pY2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc3VjY2Vzcyk7XHJcbn1cclxuaW9uLWNvbnRlbnQge1xyXG4gIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgIzVmOGZmOCwgI2ZmZmZmZik7XHJcbiAgICBpb24tZ3JpZCB7XHJcbiAgICAgICAgbWFyZ2luOiAxMHB4O1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICBpb24tcm93IHtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG4gICAgICAgICAgICBpb24tY29sIHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcclxuICAgICAgICAgICAgICAgIGJveC1zaGFkb3c6IDRweCAxMHB4IDMwcHggLTNweCAjMDUwNTA1O1xyXG4gICAgICAgICAgICAgICAgbWluLXdpZHRoOiAxOHJlbTtcclxuICAgICAgICAgICAgICAgIG1heC13aWR0aDogMThyZW07XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDE0LjVyZW07XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDEwcHg7XHJcbiAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgIC8vIG1heC1oZWlnaHQ6IDEycmVtO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuXHJcbiAgICAgICAgICAgICAgICBpb24taXRlbSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAtOHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IC0xNXB4O1xyXG4gICAgICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICAgICAgICAgIGlvbi1sYWJlbHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAwLjhyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMC41cmVtO1xyXG4gICAgICAgICAgICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDJyZW07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDU1MHB4KSB7XHJcbiAgICB0ZCx0aCAge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIH1cclxufVxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgdGQsdGggIHtcclxuICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICB9XHJcbn1cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDUwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgfVxyXG59XHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDQwMHB4KSB7XHJcbiAgICB0ZCx0aCAge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgIH1cclxufVxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAzNzBweCkge1xyXG4gICAgdGQsdGggIHtcclxuICAgICAgICBmb250LXNpemU6IDlweDtcclxuICAgIH1cclxufVxyXG5cclxudGFibGUge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG59XHJcbi8qIFplYnJhIHN0cmlwaW5nICovXHJcbnRyOm50aC1vZi10eXBlKG9kZCkge1xyXG4gICAgYmFja2dyb3VuZDogI2VlZTtcclxufVxyXG50aCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjMzMzO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcbnRkLCB0aCB7XHJcbiAgICBwYWRkaW5nOiAzcHg7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "c/hZ":
/*!*************************************************!*\
  !*** ./src/app/pages/invoice/invoice.module.ts ***!
  \*************************************************/
/*! exports provided: InvoicePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InvoicePageModule", function() { return InvoicePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _invoice_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./invoice-routing.module */ "ODCs");
/* harmony import */ var _invoice_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./invoice.page */ "Tcr8");
/* harmony import */ var ng2_search_filter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ng2-search-filter */ "cZdB");








let InvoicePageModule = class InvoicePageModule {
};
InvoicePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _invoice_routing_module__WEBPACK_IMPORTED_MODULE_5__["InvoicePageRoutingModule"],
            ng2_search_filter__WEBPACK_IMPORTED_MODULE_7__["Ng2SearchPipeModule"]
        ],
        declarations: [_invoice_page__WEBPACK_IMPORTED_MODULE_6__["InvoicePage"]]
    })
], InvoicePageModule);



/***/ })

}]);
//# sourceMappingURL=pages-invoice-invoice-module-es2015.js.map