(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-screen-screen-module"], {
    /***/
    "8vYc":
    /*!*************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/screen/screen.page.html ***!
      \*************************************************************************************/

    /*! exports provided: default */

    /***/
    function vYc(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">main screen</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n";
      /***/
    },

    /***/
    "A/D4":
    /*!***********************************************!*\
      !*** ./src/app/pages/screen/screen.page.scss ***!
      \***********************************************/

    /*! exports provided: default */

    /***/
    function AD4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #8fdca6, #ffffff);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NjcmVlbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxzQ0FBQTtBQUNGOztBQUNBO0VBQ0UsMERBQUE7QUFFRiIsImZpbGUiOiJzY3JlZW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xyXG4gIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXN1Y2Nlc3MpO1xyXG59XHJcbmlvbi1jb250ZW50IHtcclxuICAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICM4ZmRjYTYsICNmZmZmZmYpO1xyXG5cclxufVxyXG4iXX0= */";
      /***/
    },

    /***/
    "QIfi":
    /*!*******************************************************!*\
      !*** ./src/app/pages/screen/screen-routing.module.ts ***!
      \*******************************************************/

    /*! exports provided: ScreenPageRoutingModule */

    /***/
    function QIfi(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ScreenPageRoutingModule", function () {
        return ScreenPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _screen_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./screen.page */
      "WT0E");

      var routes = [{
        path: '',
        component: _screen_page__WEBPACK_IMPORTED_MODULE_3__["ScreenPage"]
      }];

      var ScreenPageRoutingModule = function ScreenPageRoutingModule() {
        _classCallCheck(this, ScreenPageRoutingModule);
      };

      ScreenPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ScreenPageRoutingModule);
      /***/
    },

    /***/
    "WT0E":
    /*!*********************************************!*\
      !*** ./src/app/pages/screen/screen.page.ts ***!
      \*********************************************/

    /*! exports provided: ScreenPage */

    /***/
    function WT0E(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ScreenPage", function () {
        return ScreenPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_screen_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./screen.page.html */
      "8vYc");
      /* harmony import */


      var _screen_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./screen.page.scss */
      "A/D4");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var ScreenPage = /*#__PURE__*/function () {
        function ScreenPage() {
          _classCallCheck(this, ScreenPage);
        }

        _createClass(ScreenPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return ScreenPage;
      }();

      ScreenPage.ctorParameters = function () {
        return [];
      };

      ScreenPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-screen',
        template: _raw_loader_screen_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_screen_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ScreenPage);
      /***/
    },

    /***/
    "hAFB":
    /*!***********************************************!*\
      !*** ./src/app/pages/screen/screen.module.ts ***!
      \***********************************************/

    /*! exports provided: ScreenPageModule */

    /***/
    function hAFB(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ScreenPageModule", function () {
        return ScreenPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _screen_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./screen-routing.module */
      "QIfi");
      /* harmony import */


      var _screen_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./screen.page */
      "WT0E");

      var ScreenPageModule = function ScreenPageModule() {
        _classCallCheck(this, ScreenPageModule);
      };

      ScreenPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _screen_routing_module__WEBPACK_IMPORTED_MODULE_5__["ScreenPageRoutingModule"]],
        declarations: [_screen_page__WEBPACK_IMPORTED_MODULE_6__["ScreenPage"]]
      })], ScreenPageModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-screen-screen-module-es5.js.map