(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/shazaibmalikl2e/Desktop/working/dairlink/src/main.ts */"zUnb");


/***/ }),

/***/ "AytR":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "Lb7+":
/*!********************************************!*\
  !*** ./src/app/provider/global.service.ts ***!
  \********************************************/
/*! exports provided: GlobalService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GlobalService", function() { return GlobalService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");



let GlobalService = class GlobalService {
    constructor() {
        this.medicinedetail = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Medicinedetail = this.medicinedetail.asObservable();
        this.cart = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Cart = this.cart.asObservable();
        this.cartmed = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Cartmed = this.cartmed.asObservable();
        this.ids = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Ids = this.ids.asObservable();
        this.expense = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Expense = this.expense.asObservable();
        this.expensedetail = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Expensedetail = this.expensedetail.asObservable();
        this.detail = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Detail = this.detail.asObservable();
        this.medicine = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Medicine = this.medicine.asObservable();
        this.packing = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Packing = this.packing.asObservable();
        this.user = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.User = this.user.asObservable();
        this.company = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Company = this.company.asObservable();
        this.bank = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Bank = this.bank.asObservable();
        this.bankdetail = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Bankdetail = this.bankdetail.asObservable();
        this.customer = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Customer = this.customer.asObservable();
        this.employee = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Employee = this.employee.asObservable();
        this.employeedetails = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Employeedetails = this.employeedetails.asObservable();
        this.customerdetails = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Customerdetails = this.customerdetails.asObservable();
        this.sellerdetails = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Sellerdetails = this.sellerdetails.asObservable();
        this.type = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Type = this.type.asObservable();
        this.seller = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Seller = this.seller.asObservable();
        this.invoice = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Invoice = this.invoice.asObservable();
        this.invoicepur = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Invoicepur = this.invoicepur.asObservable();
        this.invoiceemp = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Invoiceemp = this.invoiceemp.asObservable();
        this.invoicedetail = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Invoicedetail = this.invoicedetail.asObservable();
        this.invoicedetailemp = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Invoicedetailemp = this.invoicedetailemp.asObservable();
        this.transactiondetail = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Transactiondetail = this.transactiondetail.asObservable();
        this.purchasedetail = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Purchasedetail = this.purchasedetail.asObservable();
        this.net = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Net = this.net.asObservable();
        this.totalsale = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Totalsale = this.totalsale.asObservable();
        this.totalex = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Totalex = this.totalex.asObservable();
        this.totalpur = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"]('');
        this.Totalpur = this.totalpur.asObservable();
    }
    set_Medicinedetail(medicinedetail) {
        this.medicinedetail.next(medicinedetail);
    }
    set_Cart(cart) {
        this.cart.next(cart);
    }
    set_Cartmed(cartmed) {
        this.cartmed.next(cartmed);
    }
    set_Ids(ids) {
        this.ids.next(ids);
    }
    set_Expense(expense) {
        this.expense.next(expense);
    }
    set_Expensedetail(expensedetail) {
        this.expensedetail.next(expensedetail);
    }
    set_Detail(detail) {
        this.detail.next(detail);
    }
    set_Medicine(medicine) {
        this.medicine.next(medicine);
    }
    set_Packing(packing) {
        this.packing.next(packing);
    }
    set_User(user) {
        this.user.next(user);
    }
    set_Company(company) {
        this.company.next(company);
    }
    set_Bank(bank) {
        this.bank.next(bank);
    }
    set_Bankdetail(bankdetail) {
        this.bankdetail.next(bankdetail);
    }
    set_Customer(customer) {
        this.customer.next(customer);
    }
    set_Employee(employee) {
        this.employee.next(employee);
    }
    set_Employeedetails(employeedetails) {
        this.employeedetails.next(employeedetails);
    }
    set_Customerdetails(customerdetails) {
        this.customerdetails.next(customerdetails);
    }
    set_Sellerdetails(sellerdetails) {
        this.sellerdetails.next(sellerdetails);
    }
    set_Type(type) {
        this.type.next(type);
    }
    set_Seller(seller) {
        this.seller.next(seller);
    }
    set_Invoice(invoice) {
        this.invoice.next(invoice);
    }
    set_Invoicepur(invoicepur) {
        this.invoicepur.next(invoicepur);
    }
    set_Invoiceemp(invoiceemp) {
        this.invoiceemp.next(invoiceemp);
    }
    set_Invoicedetail(invoicedetail) {
        this.invoicedetail.next(invoicedetail);
    }
    set_Invoicedetailemp(invoicedetailemp) {
        this.invoicedetailemp.next(invoicedetailemp);
    }
    set_Transactiondetail(transactiondetail) {
        this.transactiondetail.next(transactiondetail);
    }
    set_Purchasedetail(purchasedetail) {
        this.purchasedetail.next(purchasedetail);
    }
    set_Net(net) {
        this.net.next(net);
    }
    set_Totalsale(totalsale) {
        this.totalsale.next(totalsale);
    }
    set_Totalex(totalex) {
        this.totalex.next(totalex);
    }
    set_Totalpur(totalpur) {
        this.totalpur.next(totalpur);
    }
};
GlobalService.ctorParameters = () => [];
GlobalService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], GlobalService);



/***/ }),

/***/ "Sy1n":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./app.component.html */ "VzVu");
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component.scss */ "ynWL");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "54vc");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "VYYF");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _provider_global_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./provider/global.service */ "Lb7+");









let AppComponent = class AppComponent {
    constructor(platform, splashScreen, statusBar, global, rout, loadingController) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.global = global;
        this.rout = rout;
        this.loadingController = loadingController;
        this.selectedIndex = 0;
        this.appPages = [
            {
                id: 1,
                title: 'Shop',
                url: '/main',
                icon: 'storefront-outline'
            },
            {
                id: 2,
                title: 'Add Components',
                url: '/company',
                icon: 'add-circle-outline'
            },
            {
                id: 3,
                title: 'Add Product',
                url: '/medicine',
                icon: 'medkit-outline'
            },
            {
                id: 4,
                title: 'Invoices',
                url: '/invoice',
                icon: 'beaker-outline'
            },
            {
                id: 5,
                title: 'Transaction',
                url: '/transaction',
                icon: 'clipboard-outline'
            },
            {
                id: 6,
                title: 'Return',
                url: '/return',
                icon: 'return-up-back-outline'
            },
            {
                id: 7,
                title: 'LogOut',
                url: '/home',
                icon: 'log-out'
            }
        ];
        this.user = { other: null };
        this.initializeApp();
    }
    initializeApp() {
        this.platform.ready().then(() => {
            this.statusBar.styleDefault();
            this.splashScreen.hide();
        });
    }
    router(route, id) {
        if (this.user.other === 'manager') {
            this.rout.navigate([route]);
        }
        else if (this.user.other == "saleman" && id == 1) {
            this.rout.navigate([route]);
        }
        else if (this.user.other == "admin") {
            this.rout.navigate([route]);
        }
        else {
            this.presentLoadingWithOptions();
        }
    }
    presentLoadingWithOptions() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                spinner: null,
                duration: 500,
                message: "Sorry You Don't have access to this Feature",
                translucent: true,
                cssClass: 'custom-class custom-loading',
                backdropDismiss: true
            });
            yield loading.present();
            const { role, data } = yield loading.onDidDismiss();
        });
    }
    ngOnInit() {
        this.global.User.subscribe(res => {
            this.user = res;
        });
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] },
    { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"] },
    { type: _provider_global_service__WEBPACK_IMPORTED_MODULE_8__["GlobalService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] }
];
AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AppComponent);



/***/ }),

/***/ "VzVu":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n<!--  <ion-split-pane contentId=\"main-content\" color=\"success\" >-->\n    <ion-menu contentId=\"main-content\" type=\"overlay\" color=\"success\" >\n      <ion-content color=\"success\" >\n        <ion-list id=\"inbox-list\" style=\"background: transparent;\" >\n          <ion-list-header color=\"success\" >Dairy Links</ion-list-header>\n\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages; let i = index\" color=\"success\" >\n            <ion-item (click)=\"selectedIndex = i\" routerDirection=\"root\" (click)=\"router(p.url,p.id)\" lines=\"none\" detail=\"false\" [class.selected]=\"selectedIndex == i\" color=\"success\" >\n              <ion-icon slot=\"start\" [ios]=\"p.icon\" [md]=\"p.icon\"></ion-icon>\n              <ion-label>{{ p.title }}</ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n      </ion-content>\n    </ion-menu>\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n<!--  </ion-split-pane>-->\n</ion-app>\n");

/***/ }),

/***/ "ZAI4":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "jhN1");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "54vc");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "VYYF");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "Sy1n");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "vY5A");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/service-worker */ "Jho9");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../environments/environment */ "AytR");
/* harmony import */ var ngx_print__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ngx-print */ "m1XX");
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ionic-selectable */ "8xsl");














let AppModule = class AppModule {
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClientModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"],
            ngx_print__WEBPACK_IMPORTED_MODULE_12__["NgxPrintModule"],
            ionic_selectable__WEBPACK_IMPORTED_MODULE_13__["IonicSelectableModule"],
            _angular_service_worker__WEBPACK_IMPORTED_MODULE_10__["ServiceWorkerModule"].register('ngsw-worker.js', { enabled: _environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].production })
        ],
        providers: [
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] }
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "kLfG":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet.entry.js": [
		"dUtr",
		"common",
		0
	],
	"./ion-alert.entry.js": [
		"Q8AI",
		"common",
		1
	],
	"./ion-app_8.entry.js": [
		"hgI1",
		"common",
		2
	],
	"./ion-avatar_3.entry.js": [
		"CfoV",
		"common",
		3
	],
	"./ion-back-button.entry.js": [
		"Nt02",
		"common",
		4
	],
	"./ion-backdrop.entry.js": [
		"Q2Bp",
		5
	],
	"./ion-button_2.entry.js": [
		"0Pbj",
		"common",
		6
	],
	"./ion-card_5.entry.js": [
		"ydQj",
		"common",
		7
	],
	"./ion-checkbox.entry.js": [
		"4fMi",
		"common",
		8
	],
	"./ion-chip.entry.js": [
		"czK9",
		"common",
		9
	],
	"./ion-col_3.entry.js": [
		"/CAe",
		10
	],
	"./ion-datetime_3.entry.js": [
		"WgF3",
		"common",
		11
	],
	"./ion-fab_3.entry.js": [
		"uQcF",
		"common",
		12
	],
	"./ion-img.entry.js": [
		"wHD8",
		13
	],
	"./ion-infinite-scroll_2.entry.js": [
		"2lz6",
		14
	],
	"./ion-input.entry.js": [
		"ercB",
		"common",
		15
	],
	"./ion-item-option_3.entry.js": [
		"MGMP",
		"common",
		16
	],
	"./ion-item_8.entry.js": [
		"9bur",
		"common",
		17
	],
	"./ion-loading.entry.js": [
		"cABk",
		"common",
		18
	],
	"./ion-menu_3.entry.js": [
		"kyFE",
		"common",
		19
	],
	"./ion-modal.entry.js": [
		"TvZU",
		"common",
		20
	],
	"./ion-nav_2.entry.js": [
		"vnES",
		"common",
		21
	],
	"./ion-popover.entry.js": [
		"qCuA",
		"common",
		22
	],
	"./ion-progress-bar.entry.js": [
		"0tOe",
		"common",
		23
	],
	"./ion-radio_2.entry.js": [
		"h11V",
		"common",
		24
	],
	"./ion-range.entry.js": [
		"XGij",
		"common",
		25
	],
	"./ion-refresher_2.entry.js": [
		"nYbb",
		"common",
		26
	],
	"./ion-reorder_2.entry.js": [
		"smMY",
		"common",
		27
	],
	"./ion-ripple-effect.entry.js": [
		"STjf",
		28
	],
	"./ion-route_4.entry.js": [
		"k5eQ",
		"common",
		29
	],
	"./ion-searchbar.entry.js": [
		"OR5t",
		"common",
		30
	],
	"./ion-segment_2.entry.js": [
		"fSgp",
		"common",
		31
	],
	"./ion-select_3.entry.js": [
		"lfGF",
		"common",
		32
	],
	"./ion-slide_2.entry.js": [
		"5xYT",
		33
	],
	"./ion-spinner.entry.js": [
		"nI0H",
		"common",
		34
	],
	"./ion-split-pane.entry.js": [
		"NAQR",
		35
	],
	"./ion-tab-bar_2.entry.js": [
		"knkW",
		"common",
		36
	],
	"./ion-tab_2.entry.js": [
		"TpdJ",
		"common",
		37
	],
	"./ion-text.entry.js": [
		"ISmu",
		"common",
		38
	],
	"./ion-textarea.entry.js": [
		"U7LX",
		"common",
		39
	],
	"./ion-toast.entry.js": [
		"L3sA",
		"common",
		40
	],
	"./ion-toggle.entry.js": [
		"IUOf",
		"common",
		41
	],
	"./ion-virtual-scroll.entry.js": [
		"8Mb5",
		42
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "kLfG";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "vY5A":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");



const routes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    {
        path: 'folder',
        loadChildren: () => __webpack_require__.e(/*! import() | folder-folder-module */ "folder-folder-module").then(__webpack_require__.bind(null, /*! ./folder/folder.module */ "yIOV")).then(m => m.FolderPageModule)
    },
    {
        path: 'home',
        loadChildren: () => Promise.all(/*! import() | pages-home-home-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("pages-home-home-module")]).then(__webpack_require__.bind(null, /*! ./pages/home/home.module */ "99Un")).then(m => m.HomePageModule)
    },
    {
        path: 'main',
        loadChildren: () => Promise.all(/*! import() | pages-main-main-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("common"), __webpack_require__.e("pages-main-main-module")]).then(__webpack_require__.bind(null, /*! ./pages/main/main.module */ "82nU")).then(m => m.MainPageModule)
    },
    {
        path: 'company',
        loadChildren: () => Promise.all(/*! import() | pages-company-company-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("common"), __webpack_require__.e("pages-company-company-module")]).then(__webpack_require__.bind(null, /*! ./pages/company/company.module */ "rXpt")).then(m => m.CompanyPageModule)
    },
    {
        path: 'type',
        loadChildren: () => Promise.all(/*! import() | pages-type-type-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("pages-type-type-module")]).then(__webpack_require__.bind(null, /*! ./pages/type/type.module */ "zsiT")).then(m => m.TypePageModule)
    },
    {
        path: 'medicine',
        loadChildren: () => Promise.all(/*! import() | pages-medicine-medicine-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("pages-medicine-medicine-module")]).then(__webpack_require__.bind(null, /*! ./pages/medicine/medicine.module */ "bwnB")).then(m => m.MedicinePageModule)
    },
    {
        path: 'invoice',
        loadChildren: () => Promise.all(/*! import() | pages-invoice-invoice-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("common"), __webpack_require__.e("pages-invoice-invoice-module")]).then(__webpack_require__.bind(null, /*! ./pages/invoice/invoice.module */ "c/hZ")).then(m => m.InvoicePageModule)
    },
    {
        path: 'detail',
        loadChildren: () => Promise.all(/*! import() | pages-invoice-detail-detail-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("common")]).then(__webpack_require__.bind(null, /*! ./pages/invoice/detail/detail.module */ "5nHn")).then(m => m.DetailPageModule)
    },
    {
        path: 'transaction',
        loadChildren: () => Promise.all(/*! import() | pages-transaction-transaction-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("pages-transaction-transaction-module")]).then(__webpack_require__.bind(null, /*! ./pages/transaction/transaction.module */ "vk3t")).then(m => m.TransactionPageModule)
    },
    {
        path: 'seller',
        loadChildren: () => Promise.all(/*! import() | pages-seller-seller-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("pages-seller-seller-module")]).then(__webpack_require__.bind(null, /*! ./pages/seller/seller.module */ "cUCh")).then(m => m.SellerPageModule)
    },
    {
        path: 'cart',
        loadChildren: () => Promise.all(/*! import() | pages-cart-cart-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("pages-cart-cart-module")]).then(__webpack_require__.bind(null, /*! ./pages/cart/cart.module */ "sFz8")).then(m => m.CartPageModule)
    },
    {
        path: 'expense',
        loadChildren: () => Promise.all(/*! import() | pages-expense-expense-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("pages-expense-expense-module")]).then(__webpack_require__.bind(null, /*! ./pages/expense/expense.module */ "OFS+")).then(m => m.ExpensePageModule)
    },
    {
        path: 'customerdetail',
        loadChildren: () => Promise.all(/*! import() | pages-customerdetail-customerdetail-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("pages-customerdetail-customerdetail-module")]).then(__webpack_require__.bind(null, /*! ./pages/customerdetail/customerdetail.module */ "Pg/l")).then(m => m.CustomerdetailPageModule)
    },
    {
        path: 'return',
        loadChildren: () => Promise.all(/*! import() | pages-return-return-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("pages-return-return-module")]).then(__webpack_require__.bind(null, /*! ./pages/return/return.module */ "fRlq")).then(m => m.ReturnPageModule)
    },
    {
        path: 'screen',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-screen-screen-module */ "pages-screen-screen-module").then(__webpack_require__.bind(null, /*! ./pages/screen/screen.module */ "hAFB")).then(m => m.ScreenPageModule)
    },
    {
        path: 'start',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-start-start-module */ "pages-start-start-module").then(__webpack_require__.bind(null, /*! ./pages/start/start.module */ "ulMc")).then(m => m.StartPageModule)
    },
    {
        path: 'seller-detail',
        loadChildren: () => Promise.all(/*! import() | pages-seller-detail-seller-detail-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("pages-seller-detail-seller-detail-module")]).then(__webpack_require__.bind(null, /*! ./pages/seller-detail/seller-detail.module */ "7l5i")).then(m => m.SellerDetailPageModule)
    },
    {
        path: 'employeedetail1',
        loadChildren: () => Promise.all(/*! import() | employeedetail-employeedetail-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("employeedetail-employeedetail-module")]).then(__webpack_require__.bind(null, /*! ./employeedetail/employeedetail.module */ "BzX5")).then(m => m.EmployeedetailPageModule)
    },
    {
        path: 'employeedetail',
        loadChildren: () => Promise.all(/*! import() | pages-employeedetail-employeedetail-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("pages-employeedetail-employeedetail-module")]).then(__webpack_require__.bind(null, /*! ./pages/employeedetail/employeedetail.module */ "dr1m")).then(m => m.EmployeedetailPageModule)
    },
    {
        path: 'bankdetail',
        loadChildren: () => Promise.all(/*! import() | bankdetail-bankdetail-module */[__webpack_require__.e("default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"), __webpack_require__.e("bankdetail-bankdetail-module")]).then(__webpack_require__.bind(null, /*! ./bankdetail/bankdetail.module */ "oadO")).then(m => m.BankdetailPageModule)
    }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "ynWL":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-menu ion-content {\n  --background: var(--ion-item-background, var(--ion-background-color, #fff));\n}\n\nion-menu.md ion-content {\n  --padding-start: 8px;\n  --padding-end: 8px;\n  --padding-top: 20px;\n  --padding-bottom: 20px;\n}\n\nion-menu.md ion-list {\n  padding: 20px 0;\n}\n\nion-menu.md ion-note {\n  margin-bottom: 30px;\n}\n\nion-menu.md ion-list-header,\nion-menu.md ion-note {\n  padding-left: 10px;\n}\n\nion-menu.md ion-list#inbox-list {\n  border-bottom: 1px solid var(--ion-color-step-150, #d7d8da);\n}\n\nion-menu.md ion-list#inbox-list ion-list-header {\n  font-size: 22px;\n  font-weight: 600;\n  min-height: 20px;\n}\n\nion-menu.md ion-list#labels-list ion-list-header {\n  font-size: 16px;\n  margin-bottom: 18px;\n  color: #757575;\n  min-height: 26px;\n}\n\nion-menu.md ion-item {\n  --padding-start: 10px;\n  --padding-end: 10px;\n  border-radius: 4px;\n}\n\nion-menu.md ion-item.selected {\n  --background: rgba(var(--ion-color-primary-rgb), 0.14);\n}\n\nion-menu.md ion-item.selected ion-icon {\n  color: var(--ion-color-light);\n}\n\nion-menu.md ion-item ion-icon {\n  color: #f3f3f3;\n}\n\nion-menu.md ion-item ion-label {\n  font-weight: 500;\n}\n\nion-menu.ios ion-content {\n  --padding-bottom: 20px;\n}\n\nion-menu.ios ion-list {\n  padding: 20px 0 0 0;\n}\n\nion-menu.ios ion-note {\n  line-height: 24px;\n  margin-bottom: 20px;\n}\n\nion-menu.ios ion-item {\n  --padding-start: 16px;\n  --padding-end: 16px;\n  --min-height: 50px;\n}\n\nion-menu.ios ion-item.selected ion-icon {\n  color: var(--ion-color-light);\n}\n\nion-menu.ios ion-item ion-icon {\n  font-size: 24px;\n  color: #ffffff;\n}\n\nion-menu.ios ion-list#labels-list ion-list-header {\n  margin-bottom: 8px;\n}\n\nion-menu.ios ion-list-header,\nion-menu.ios ion-note {\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\nion-menu.ios ion-note {\n  margin-bottom: 8px;\n}\n\nion-note {\n  display: inline-block;\n  font-size: 16px;\n  color: var(--ion-color-medium-shade);\n}\n\nion-item.selected {\n  --color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL2FwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDJFQUFBO0FBQ0Y7O0FBRUE7RUFDRSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtBQUNGOztBQUVBO0VBQ0UsZUFBQTtBQUNGOztBQUVBO0VBQ0UsbUJBQUE7QUFDRjs7QUFFQTs7RUFFRSxrQkFBQTtBQUNGOztBQUVBO0VBQ0UsMkRBQUE7QUFDRjs7QUFFQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUVBLGdCQUFBO0FBQUY7O0FBR0E7RUFDRSxlQUFBO0VBRUEsbUJBQUE7RUFFQSxjQUFBO0VBRUEsZ0JBQUE7QUFIRjs7QUFNQTtFQUNFLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQUhGOztBQU1BO0VBQ0Usc0RBQUE7QUFIRjs7QUFNQTtFQUNFLDZCQUFBO0FBSEY7O0FBTUE7RUFDRSxjQUFBO0FBSEY7O0FBTUE7RUFDRSxnQkFBQTtBQUhGOztBQU1BO0VBQ0Usc0JBQUE7QUFIRjs7QUFNQTtFQUNFLG1CQUFBO0FBSEY7O0FBTUE7RUFDRSxpQkFBQTtFQUNBLG1CQUFBO0FBSEY7O0FBTUE7RUFDRSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFIRjs7QUFNQTtFQUNFLDZCQUFBO0FBSEY7O0FBTUE7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQUhGOztBQU1BO0VBQ0Usa0JBQUE7QUFIRjs7QUFNQTs7RUFFRSxrQkFBQTtFQUNBLG1CQUFBO0FBSEY7O0FBTUE7RUFDRSxrQkFBQTtBQUhGOztBQU1BO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0VBRUEsb0NBQUE7QUFKRjs7QUFPQTtFQUNFLGlDQUFBO0FBSkYiLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLW1lbnUgaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1pdGVtLWJhY2tncm91bmQsIHZhcigtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yLCAjZmZmKSk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1jb250ZW50IHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiA4cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDhweDtcbiAgLS1wYWRkaW5nLXRvcDogMjBweDtcbiAgLS1wYWRkaW5nLWJvdHRvbTogMjBweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3Qge1xuICBwYWRkaW5nOiAyMHB4IDA7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1ub3RlIHtcbiAgbWFyZ2luLWJvdHRvbTogMzBweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3QtaGVhZGVyLFxuaW9uLW1lbnUubWQgaW9uLW5vdGUge1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1saXN0I2luYm94LWxpc3Qge1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXN0ZXAtMTUwLCAjZDdkOGRhKTtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3QjaW5ib3gtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICBmb250LXNpemU6IDIycHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG5cbiAgbWluLWhlaWdodDogMjBweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWxpc3QjbGFiZWxzLWxpc3QgaW9uLWxpc3QtaGVhZGVyIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuXG4gIG1hcmdpbi1ib3R0b206IDE4cHg7XG5cbiAgY29sb3I6ICM3NTc1NzU7XG5cbiAgbWluLWhlaWdodDogMjZweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWl0ZW0ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDEwcHg7XG4gIC0tcGFkZGluZy1lbmQ6IDEwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbn1cblxuaW9uLW1lbnUubWQgaW9uLWl0ZW0uc2VsZWN0ZWQge1xuICAtLWJhY2tncm91bmQ6IHJnYmEodmFyKC0taW9uLWNvbG9yLXByaW1hcnktcmdiKSwgMC4xNCk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1pY29uIHtcbiAgY29sb3I6ICNmM2YzZjM7XG59XG5cbmlvbi1tZW51Lm1kIGlvbi1pdGVtIGlvbi1sYWJlbCB7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tY29udGVudCB7XG4gIC0tcGFkZGluZy1ib3R0b206IDIwcHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdCB7XG4gIHBhZGRpbmc6IDIwcHggMCAwIDA7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xufVxuXG5pb24tbWVudS5pb3MgaW9uLWl0ZW0ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDE2cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDE2cHg7XG4gIC0tbWluLWhlaWdodDogNTBweDtcbn1cblxuaW9uLW1lbnUuaW9zIGlvbi1pdGVtLnNlbGVjdGVkIGlvbi1pY29uIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG59XG5cbmlvbi1tZW51LmlvcyBpb24taXRlbSBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjRweDtcbiAgY29sb3I6ICNmZmZmZmY7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdCNsYWJlbHMtbGlzdCBpb24tbGlzdC1oZWFkZXIge1xuICBtYXJnaW4tYm90dG9tOiA4cHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbGlzdC1oZWFkZXIsXG5pb24tbWVudS5pb3MgaW9uLW5vdGUge1xuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDE2cHg7XG59XG5cbmlvbi1tZW51LmlvcyBpb24tbm90ZSB7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuaW9uLW5vdGUge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGZvbnQtc2l6ZTogMTZweDtcblxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XG59XG5cbmlvbi1pdGVtLnNlbGVjdGVkIHtcbiAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufSJdfQ== */");

/***/ }),

/***/ "zUnb":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "a3Wg");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "ZAI4");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "AytR");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));


/***/ }),

/***/ "zn8P":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "zn8P";

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map