(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-type-type-module"],{

/***/ "L78G":
/*!*******************************************!*\
  !*** ./src/app/pages/type/type.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #5f8ff8, #ffffff);\n}\n\nion-col {\n  background-color: #f7f7f7;\n  border: solid 1px #ddd;\n}\n\n@media screen and (max-width: 550px) {\n  td, th {\n    font-size: 14px;\n  }\n}\n\n@media screen and (max-width: 500px) {\n  td, th {\n    font-size: 12px;\n  }\n}\n\n@media screen and (max-width: 450px) {\n  td, th {\n    font-size: 11px;\n  }\n}\n\n@media screen and (max-width: 400px) {\n  td, th {\n    font-size: 10px;\n  }\n}\n\n@media screen and (max-width: 370px) {\n  td, th {\n    font-size: 9px;\n  }\n}\n\ntable {\n  width: 100%;\n  border-collapse: collapse;\n}\n\n/* Zebra striping */\n\ntr:nth-of-type(odd) {\n  background: #eee;\n}\n\nth {\n  background: #333;\n  color: white;\n}\n\ntd, th {\n  padding: 3px;\n  border: 1px solid #ccc;\n  text-align: left;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3R5cGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usc0NBQUE7QUFDRjs7QUFDQTtFQUNFLDBEQUFBO0FBRUY7O0FBQUE7RUFDRSx5QkFBQTtFQUNBLHNCQUFBO0FBR0Y7O0FBREE7RUFDRTtJQUNFLGVBQUE7RUFJRjtBQUNGOztBQUZBO0VBQ0U7SUFDRSxlQUFBO0VBSUY7QUFDRjs7QUFGQTtFQUNFO0lBQ0UsZUFBQTtFQUlGO0FBQ0Y7O0FBRkE7RUFDRTtJQUNFLGVBQUE7RUFJRjtBQUNGOztBQUZBO0VBQ0U7SUFDRSxjQUFBO0VBSUY7QUFDRjs7QUFEQTtFQUNFLFdBQUE7RUFDQSx5QkFBQTtBQUdGOztBQURBLG1CQUFBOztBQUNBO0VBQ0UsZ0JBQUE7QUFJRjs7QUFGQTtFQUNFLGdCQUFBO0VBQ0EsWUFBQTtBQUtGOztBQUhBO0VBQ0UsWUFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QUFNRiIsImZpbGUiOiJ0eXBlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi10b29sYmFyIHtcclxuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjNWY4ZmY4LCAjZmZmZmZmKTtcclxufVxyXG5pb24tY29sICB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y3ZjdmNztcclxuICBib3JkZXI6IHNvbGlkIDFweCAjZGRkO1xyXG59XHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDU1MHB4KSB7XHJcbiAgdGQsdGggIHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICB9XHJcbn1cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICB0ZCx0aCAge1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gIH1cclxufVxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA0NTBweCkge1xyXG4gIHRkLHRoICB7XHJcbiAgICBmb250LXNpemU6IDExcHg7XHJcbiAgfVxyXG59XHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDQwMHB4KSB7XHJcbiAgdGQsdGggIHtcclxuICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICB9XHJcbn1cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMzcwcHgpIHtcclxuICB0ZCx0aCAge1xyXG4gICAgZm9udC1zaXplOiA5cHg7XHJcbiAgfVxyXG59XHJcblxyXG50YWJsZSB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcclxufVxyXG4vKiBaZWJyYSBzdHJpcGluZyAqL1xyXG50cjpudGgtb2YtdHlwZShvZGQpIHtcclxuICBiYWNrZ3JvdW5kOiAjZWVlO1xyXG59XHJcbnRoIHtcclxuICBiYWNrZ3JvdW5kOiAjMzMzO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxufVxyXG50ZCwgdGgge1xyXG4gIHBhZGRpbmc6IDNweDtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbn1cclxuXHJcblxyXG5cclxuXHJcbiJdfQ== */");

/***/ }),

/***/ "Z03X":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/type/type.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<script src=\"../seller-detail/seller-detail.page.ts\"></script>\n<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Product Cart</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-item lines=\"none\" class=\"option\">\n    <ion-label>Seller Name</ion-label>\n    <ion-select name=\"seller_id\" [(ngModel)]=\"seller_id\" interface=\"action-sheet\">\n      <ion-select-option value={{a.s_id}} *ngFor=\"let a of seller ; let i = index\">{{a.s_name}}</ion-select-option>\n    </ion-select>\n  </ion-item>\n\n  <table>\n    <thead>\n    <tr>\n      <th>Med Name</th>\n      <th>Packing</th>\n      <th>Quantity</th>\n      <th>Batch NO</th>\n      <th>Purchasing</th>\n      <th>Selling Price</th>\n      <th>Min selling</th>\n      <th>Date</th>\n      <th>Remove</th>\n    </tr>\n    </thead>\n    <tbody>\n\n    <tr *ngFor=\"let a of cartmed ; let i =index\">\n      <td>{{a.med_name}}</td>\n      <td>{{a.packing_name}}</td>\n      <td>\n        <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.quantity\"></ion-input>\n      </td>\n      <td><ion-input name=\"name\" type=\"text\" [(ngModel)]=\"a.batch_no\"></ion-input></td>\n      <td><ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.purchasing\"></ion-input></td>\n      <td><ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.selling\"></ion-input></td>\n      <td>\n        <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"a.min_selling\"></ion-input>\n      </td>\n      <td> <ion-datetime display-format=\"YYYY-MM-DD\" min=\"2000-01-01\" max=\"2100-10-31\" picker-format=\"YYYY-MM-DD\" name=\"a.man_date\"    [(ngModel)]=\"a.man_date\"></ion-datetime></td>\n      <td><ion-button (click)=\"remove(i)\" color=\"success\" style=\"margin:2px;\">Remove</ion-button></td>\n    </tr>\n    </tbody>\n  </table>\n  <ion-button (click)=\"total()\" expand=\"block\" color=\"success\" style=\"margin:10px;height:2.5rem\">Total</ion-button>\n  <ion-item *ngIf=\"to!=0\"  style=\"--background: transparent;\">\n    <ion-label >\n      Total\n    </ion-label>\n    <ion-label text-right >\n      {{this.to}}\n    </ion-label>\n  </ion-item>\n\n  <ion-item>\n    <ion-label>Bank Receive</ion-label>\n    <ion-toggle name=\"blueberry\" (ionChange)=\"togle()\" checked [(ngModel)]=\"banks\" ></ion-toggle>\n  </ion-item>\n  <ion-list style=\"--background: transparent;\" *ngIf=\"banks == 'true'\">\n    <ion-item lines=\"none\" class=\"option\">\n      <ion-label>Select Bank</ion-label>\n      <ion-select name=\"b_id\" [(ngModel)]=\"this.bank.b_id\" interface=\"action-sheet\" (ionChange)=\"change()\">\n        <ion-select-option value={{a.b_id}} *ngFor=\"let a of bankname\">{{a.name}}</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item style=\"--background: transparent;\">\n      <ion-label style=\"width: 30%;\">\n        Bank Name / Title\n      </ion-label>\n      <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"bank.name\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n    </ion-item>\n    <!--    <ion-item style=\"&#45;&#45;background: transparent;\">-->\n    <!--      <ion-label style=\"width: 30%;\">-->\n    <!--        Acc Title-->\n    <!--      </ion-label>-->\n    <!--      <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"bank.title\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>-->\n    <!--    </ion-item>-->\n    <!--    <ion-item style=\"&#45;&#45;background: transparent;\">-->\n    <!--      <ion-label style=\"width: 30%;\">-->\n    <!--        Acc no-->\n    <!--      </ion-label>-->\n    <!--      <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"bank.no\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>-->\n    <!--    </ion-item>-->\n    <ion-item style=\"--background: transparent;\">\n      <ion-label style=\"width: 30%;\">\n        Received Ammount\n      </ion-label>\n      <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"bank.credit\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n    </ion-item>\n  </ion-list>\n\n\n  <ion-item style=\"--background: transparent;\" *ngIf=\"banks == 'false'\">\n    <ion-label style=\"width: 80%;\">\n      Recevied\n    </ion-label>\n   \n    <ion-input name=\"name\" type=\"number\" [(ngModel)]=\"bank.credit\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n  </ion-item>\n  <ion-button (click)=\"placeorder()\" expand=\"block\" color=\"success\"  [disabled]=\"seller_id==null || cartmed==[]\"  style=\"margin:10px;height:3rem\"> Order </ion-button>\n</ion-content>\n");

/***/ }),

/***/ "gIm/":
/*!***************************************************!*\
  !*** ./src/app/pages/type/type-routing.module.ts ***!
  \***************************************************/
/*! exports provided: TypePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TypePageRoutingModule", function() { return TypePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _type_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./type.page */ "w4vH");




const routes = [
    {
        path: '',
        component: _type_page__WEBPACK_IMPORTED_MODULE_3__["TypePage"]
    }
];
let TypePageRoutingModule = class TypePageRoutingModule {
};
TypePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TypePageRoutingModule);



/***/ }),

/***/ "w4vH":
/*!*****************************************!*\
  !*** ./src/app/pages/type/type.page.ts ***!
  \*****************************************/
/*! exports provided: TypePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TypePage", function() { return TypePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_type_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./type.page.html */ "Z03X");
/* harmony import */ var _type_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./type.page.scss */ "L78G");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/provider/apicall.service */ "G1p3");
/* harmony import */ var src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/provider/global.service */ "Lb7+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "tyNb");








let TypePage = class TypePage {
    constructor(router, loadingController, menu, apicall, global) {
        this.router = router;
        this.loadingController = loadingController;
        this.menu = menu;
        this.apicall = apicall;
        this.global = global;
        this.banks = 'false';
        this.bank = { b_id: null, invoice_id: '', customer_id: '', name: '', title: '', no: '', ammount: 0, credit: '0', net_balance: '' };
        this.cartmed = [];
        this.order = { seller: { s_id: null, received: null, net_balance: null }, cart: {}, bank: {} };
        this.last1 = { net_balance: 0 };
        this.add = { m_id: null, p_id: null, p_invoice_id: null, quantity: null, purchasing: null, selling: null, practioner: null, expiry: null };
    }
    ngOnInit() {
        this.apicall.api_getbanks();
        this.global.Bank.subscribe(res => {
            this.bankname = res;
            console.log(this.bankname);
        });
        this.global.Cartmed.subscribe(res => {
            this.cartmed = res;
            console.log(this.cartmed);
        });
        this.apicall.api_getseller();
        this.global.Seller.subscribe(res => {
            this.seller = res;
        });
        console.log(this.seller);
    }
    togle() {
        if (this.banks === true) {
            this.banks = 'true';
            console.log(this.banks);
        }
        else {
            this.banks = 'false';
            console.log(this.banks);
        }
    }
    total() {
        for (let index = 0; index < this.cartmed.length; index++) {
            this.cartmed[index].man_date = this.cartmed[index].man_date.slice(0, 10);
            this.cartmed[index].ex_date = this.cartmed[index].ex_date.slice(0, 10);
        }
        console.log(this.cartmed);
        this.apicall.api_getsellerdetails(this.seller_id);
        this.presentLoadingWithOptions();
        this.global.Sellerdetails.subscribe(res => {
            this.last = res;
            console.log(this.last);
        });
        this.to = 0;
        // tslint:disable-next-line:prefer-for-of
        for (let index = 0; index < this.cartmed.length; index++) {
            this.to = (this.cartmed[index].purchasing * this.cartmed[index].quantity) + this.to;
        }
        console.log(this.to);
    }
    change() {
        console.log(this.bank.b_id);
        this.apicall.api_getbankdetail(this.bank.b_id);
        this.global.Bankdetail.subscribe(res => {
            this.last2 = res;
            console.log(this.last2);
        });
    }
    adddata() {
        this.add.m_id = this.data.m_id;
        this.add.p_id = this.data.p_id;
        console.log(this.add);
        this.apicall.api_adddetail(this.add);
    }
    placeorder() {
        this.total();
        if (this.last2.length !== 0) {
            this.last3 = this.last2[this.last2.length - 1];
            this.bank.net_balance = this.last3.net_balance;
            console.log(this.bank);
        }
        else {
            this.bank.net_balance = 0;
            console.log(this.bank);
        }
        if (this.last.length !== 0) {
            this.presentLoadingWithOptions();
            this.last1 = this.last[this.last.length - 1];
            this.order.seller.net_balance = this.last1.net_balance;
        }
        else {
            this.order.seller.net_balance = 0;
        }
        console.log(this.last1);
        console.log(this.cartmed);
        this.order.seller.s_id = this.seller_id;
        this.order.seller.received = this.bank.credit;
        this.order.cart = this.cartmed;
        this.order.bank = this.bank;
        console.log(this.order);
        this.apicall.api_purchasemedicine(this.order);
        this.cartmed = null;
        this.global.set_Cartmed(this.cartmed);
        this.router.navigate(['medicine']);
    }
    presentLoadingWithOptions() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                spinner: 'circular',
                duration: 400,
                message: 'Order Is Being Placed',
                translucent: true,
                cssClass: 'custom-class custom-loading',
                backdropDismiss: true
            });
            yield loading.present();
            const { role, data } = yield loading.onDidDismiss();
            //  this.apicall.api_getmedicinedetail();
        });
    }
    remove(i) {
        this.cartmed.splice(i, 1);
    }
};
TypePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"] },
    { type: src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__["ApicallService"] },
    { type: src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__["GlobalService"] }
];
TypePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-type',
        template: _raw_loader_type_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_type_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TypePage);



/***/ }),

/***/ "zsiT":
/*!*******************************************!*\
  !*** ./src/app/pages/type/type.module.ts ***!
  \*******************************************/
/*! exports provided: TypePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TypePageModule", function() { return TypePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _type_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./type-routing.module */ "gIm/");
/* harmony import */ var _type_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./type.page */ "w4vH");







let TypePageModule = class TypePageModule {
};
TypePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _type_routing_module__WEBPACK_IMPORTED_MODULE_5__["TypePageRoutingModule"]
        ],
        declarations: [_type_page__WEBPACK_IMPORTED_MODULE_6__["TypePage"]]
    })
], TypePageModule);



/***/ })

}]);
//# sourceMappingURL=pages-type-type-module-es2015.js.map