(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-company-company-module"],{

/***/ "0EGn":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/company/company.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Dairy Links</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-segment color=\"dark\" [(ngModel)]=\"sign\">\n    <ion-segment-button value=\"co\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Company</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"ty\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Type</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"emp\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Employee</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"cu\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Customer</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"se\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Distributer</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"ex\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Expense</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n  <div color=\"success\" class=\"main\" [ngSwitch]=\"sign\">\n    <ion-list class=\"f\" *ngSwitchCase=\"'co'\">\n      <div *ngIf=\"this.idc == 0\">\n\n        <form #form=\"ngForm\" (ngSubmit)=\"addco()\">\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Add Company</ion-label>\n            <ion-input name=\"name\" [(ngModel)]=\"term\" type=\"text\" [(ngModel)]=\"co.name\"></ion-input>\n          </ion-item>\n          <ion-button expand=\"block\" color=\"success\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n        </form>\n\n      </div>\n      <div *ngIf=\"this.idc == 1\">\n\n        <form #form=\"ngForm\" >\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Add Company</ion-label>\n            <ion-input name=\"n ame\"  type=\"text\" [(ngModel)]=\"co1.c_name\"></ion-input>\n          </ion-item>\n          <ion-button expand=\"block\" color=\"success\" type=\"submit\" (click)=\"updatecompany(co1)\">Update</ion-button>\n        </form>\n      </div>\n      <ion-searchbar (ionInput)=\"filterco($event)\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of company |filter:term \">\n        <ion-item>\n          {{a.c_name}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"danger\" (click)=\"deleteco(a.c_id)\">Delete</ion-item-option>\n        </ion-item-options>\n        <ion-item-options side=\"start\">\n          <ion-item-option color=\"success\" (click)=\"updateco(a)\">Update Data</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n\n    </ion-list>\n    <ion-list class=\"f\" *ngSwitchCase=\"'ty'\">\n      <div *ngIf=\"this.idt == 0\">\n        <form #form=\"ngForm\" (ngSubmit)=\"addty()\">\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Add Dosage form</ion-label>\n            <ion-input name=\"name\" [(ngModel)]=\"term1\" type=\"text\" [(ngModel)]=\"ty.name\"></ion-input>\n          </ion-item>\n          <ion-button expand=\"block\" color=\"success\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n        </form>\n      </div>\n      <div *ngIf=\"this.idt == 1\">\n        <form #form=\"ngForm\">\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Add Dosage form</ion-label>\n            <ion-input name=\"name\"  type=\"text\" [(ngModel)]=\"ty2.name\"></ion-input>\n          </ion-item>\n          <ion-button expand=\"block\" color=\"success\" type=\"submit\" (click)=\"updatetype(ty2)\" >Update</ion-button>\n        </form>\n      </div>\n      <ion-searchbar [(ngModel)]=\"term1\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of type |filter:term1\">\n        <ion-item>\n          {{a.name}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"danger\" (click)=\"deletety(a.t_id)\">Delete</ion-item-option>\n        </ion-item-options>\n        <ion-item-options side=\"start\">\n          <ion-item-option color=\"success\" (click)=\"updatety(a)\">Update Data</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n    </ion-list>\n    <ion-list class=\"f\" *ngSwitchCase=\"'emp'\">\n      <form #form=\"ngForm\" (ngSubmit)=\"addemp()\">\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Employee Name</ion-label>\n          <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"emp.name\"></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Employee Address</ion-label>\n          <ion-input name=\"address\" type=\"text\" [(ngModel)]=\"emp.address\"></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Mobile no</ion-label>\n          <ion-input name=\"phone\" type=\"text\" [(ngModel)]=\"emp.phone\"></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Enter ENIC</ion-label>\n          <ion-input name=\"cnic\" type=\"text\" [(ngModel)]=\"emp.cnic\"></ion-input>\n        </ion-item>\n        <ion-button expand=\"block\" color=\"light\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n      </form>\n      <ion-searchbar [(ngModel)]=\"term2\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of employee |filter:term2\">\n        <ion-item>\n          {{a.name}}  {{a.address}} {{a.phone}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"success\" (click)=\"detailemployee(a.e_id)\">See Detail</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n    </ion-list>\n\n    <ion-list class=\"f\" *ngSwitchCase=\"'cu'\">\n      <form #form=\"ngForm\" (ngSubmit)=\"addcu()\">\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Customer Name</ion-label>\n          <ion-input name=\"name\" (ionInput)=\"filtercu($event)\" type=\"text\" [(ngModel)]=\"cu.name\"></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Customer Address</ion-label>\n          <ion-input name=\"address\" type=\"text\" [(ngModel)]=\"cu.address\"></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Mobile No</ion-label>\n          <ion-input name=\"address\" type=\"text\" [(ngModel)]=\"cu.mobile_no\"></ion-input>\n        </ion-item>\n        <ion-button expand=\"block\" color=\"success\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n      </form>\n      <ion-searchbar [(ngModel)]=\"term3\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of customer |filter:term3\">\n        <ion-item>\n          {{a.name}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"success\" (click)=\"detailcustomer(a.customer_id)\">See Detail</ion-item-option>\n        </ion-item-options>\n        <ion-item-options side=\"start\">\n          <ion-item-option color=\"success\" (click)=\"detailcustomer(a.customer_id)\">Update Data</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n    </ion-list>\n\n    <ion-list class=\"f\" *ngSwitchCase=\"'se'\">\n      <div *ngIf=\"this.ids == 0\">\n        <form #form=\"ngForm\" (ngSubmit)=\"addse()\">\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Distributer Name</ion-label>\n            <ion-input name=\"name\" (ionInput)=\"filterse($event)\" type=\"text\" [(ngModel)]=\"se.name\"></ion-input>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Distributer Address</ion-label>\n            <ion-input name=\"address\" type=\"text\" [(ngModel)]=\"se.address\"></ion-input>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Phone No</ion-label>\n            <ion-input name=\"address\" type=\"text\" [(ngModel)]=\"se.phone\"></ion-input>\n          </ion-item>\n          <ion-button expand=\"block\" color=\"success\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n        </form>\n      </div>\n      <div *ngIf=\"this.ids == 1\">\n        <form #form=\"ngForm\">\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Distributer Name</ion-label>\n            <ion-input name=\"name\" (ionInput)=\"filterse($event)\" type=\"text\" [(ngModel)]=\"se2.s_name\"></ion-input>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Distributer Address</ion-label>\n            <ion-input name=\"address\" type=\"text\" [(ngModel)]=\"se2.s_address\"></ion-input>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Phone No</ion-label>\n            <ion-input name=\"address\" type=\"text\" [(ngModel)]=\"se2.phone\"></ion-input>\n          </ion-item>\n          <ion-button expand=\"block\" color=\"success\" type=\"submit\" (click)=\"updateseller(se2)\" >Update</ion-button>\n        </form>\n      </div>\n      <ion-searchbar [(ngModel)]=\"term4\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of seller |filter:term4\">\n        <ion-item>\n          {{a.s_name}}&nbsp;{{a.s_address}} {{a.phone}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"success\" (click)=\"deletese(a.s_id)\">See Detail</ion-item-option>\n        </ion-item-options>\n        <ion-item-options side=\"start\">\n          <ion-item-option color=\"success\" (click)=\"updatese(a)\">Update Data</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n    </ion-list>\n    <ion-list class=\"f\" *ngSwitchCase=\"'ex'\">\n      <form #form=\"ngForm\" (ngSubmit)=\"addex()\">\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Add Expense</ion-label>\n          <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"ex.name\"></ion-input>\n        </ion-item>\n        <ion-button expand=\"block\" color=\"light\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n      </form>\n      <ion-searchbar (ionInput)=\"filterex($event)\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of expense\">\n        <ion-item>\n          {{a.name}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"success\" (click)=\"detailex(a.e_id)\">See Detail</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n    </ion-list>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ "4hzC":
/*!*********************************************************!*\
  !*** ./src/app/pages/company/company-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: CompanyPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompanyPageRoutingModule", function() { return CompanyPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _company_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./company.page */ "lDms");




const routes = [
    {
        path: '',
        component: _company_page__WEBPACK_IMPORTED_MODULE_3__["CompanyPage"]
    }
];
let CompanyPageRoutingModule = class CompanyPageRoutingModule {
};
CompanyPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CompanyPageRoutingModule);



/***/ }),

/***/ "R/T6":
/*!*************************************************!*\
  !*** ./src/app/pages/company/company.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #5f8ff8, #ffffff);\n}\n\nion-content ion-item {\n  --background: transparent;\n}\n\nion-content ion-item ion-input {\n  border-bottom: 1px solid black;\n}\n\nion-content ion-button {\n  margin: 15px 20px 15px 20px;\n  border-radius: 30px;\n  box-shadow: 4px 9px 29px -9px #050505;\n}\n\nion-content ion-list {\n  background: transparent;\n}\n\nion-row {\n  width: 90%;\n}\n\nion-row ion-item {\n  width: 100%;\n  margin-top: 0;\n  margin-bottom: -1rem;\n}\n\nion-row ion-item ion-row {\n  justify-content: center;\n}\n\nion-row ion-item ion-row ion-label {\n  font-size: small;\n  margin-top: 0;\n  margin-bottom: 0;\n  margin-left: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL2NvbXBhbnkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0NBQUE7QUFDSjs7QUFDQTtFQUNJLDBEQUFBO0FBRUo7O0FBREc7RUFDSyx5QkFBQTtBQUdSOztBQUZRO0VBQ0ksOEJBQUE7QUFJWjs7QUFESTtFQUNJLDJCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQ0FBQTtBQUdSOztBQURJO0VBQ0ksdUJBQUE7QUFHUjs7QUFBQTtFQUNJLFVBQUE7QUFHSjs7QUFGSTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0Esb0JBQUE7QUFJUjs7QUFIUTtFQUNJLHVCQUFBO0FBS1o7O0FBSlk7RUFDSSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBTWhCIiwiZmlsZSI6ImNvbXBhbnkucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc3VjY2Vzcyk7XHJcbn1cclxuaW9uLWNvbnRlbnQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjNWY4ZmY4LCAjZmZmZmZmKTtcclxuICAgaW9uLWl0ZW17XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgICBpb24taW5wdXR7XHJcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBibGFjaztcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgIG1hcmdpbjoxNXB4IDIwcHggMTVweCAyMHB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICAgICAgYm94LXNoYWRvdzogNHB4IDlweCAyOXB4IC05cHggIzA1MDUwNTtcclxuICAgIH1cclxuICAgIGlvbi1saXN0e1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgfVxyXG59XHJcbmlvbi1yb3d7XHJcbiAgICB3aWR0aDo5MCU7XHJcbiAgICBpb24taXRlbXtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICBtYXJnaW4tdG9wOiAwO1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IC0xcmVtO1xyXG4gICAgICAgIGlvbi1yb3d7XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgICBpb24tbGFiZWx7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IHNtYWxsO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMDtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMjBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ== */");

/***/ }),

/***/ "lDms":
/*!***********************************************!*\
  !*** ./src/app/pages/company/company.page.ts ***!
  \***********************************************/
/*! exports provided: CompanyPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompanyPage", function() { return CompanyPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_company_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./company.page.html */ "0EGn");
/* harmony import */ var _company_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./company.page.scss */ "R/T6");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/provider/apicall.service */ "G1p3");
/* harmony import */ var src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/provider/global.service */ "Lb7+");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "tyNb");








let CompanyPage = class CompanyPage {
    constructor(loadingController, router, alert, actionSheetCtrl, menu, apicall, global) {
        this.loadingController = loadingController;
        this.router = router;
        this.alert = alert;
        this.actionSheetCtrl = actionSheetCtrl;
        this.menu = menu;
        this.apicall = apicall;
        this.global = global;
        this.idc = 0;
        this.idg = 0;
        this.idt = 0;
        this.ids = 0;
        this.co = { name: null, other: "" };
        this.se = { name: null, address: null, other: "" };
        this.ty = { name: null, address: null, other: "" };
        this.cu = { name: '', address: '', farm_address: '', mobile_no: '', total: '', remaining: '' };
        this.emp = { name: null, address: null, phone: null, cnic: null, total: null, remaining: null };
        this.ex = { name: null };
        this.updatedetail = { customer_id: null, received: null };
        this.del = { s_id: null };
    }
    ngOnInit() {
        this.sign = "co";
        this.apicall.api_getcompany();
        this.global.Company.subscribe(res => {
            this.compan = res;
            this.company = res;
            console.log(res);
        });
        this.apicall.api_getseller();
        this.global.Seller.subscribe(res => {
            this.selle = res;
            this.seller = res;
        });
        this.apicall.api_gettype();
        this.global.Type.subscribe(res => {
            this.typ = res;
            this.type = res;
        });
        this.apicall.api_getcustomer();
        this.global.Customer.subscribe(res => {
            this.custome = res;
            this.customer = res;
        });
        this.apicall.api_getemployee();
        this.global.Employee.subscribe(res => {
            this.employe = res;
            this.employee = res;
            console.log(this.employee);
        });
        this.apicall.api_getexpense();
        this.global.Expense.subscribe(res => {
            this.expens = res;
            this.expense = res;
        });
    }
    filterco(evt) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.company = this.compan;
            var val = evt.target.value;
            if (val && val.trim() != '') {
                this.company = this.company.filter((item) => {
                    return ((item.c_name.toLowerCase()).startsWith(val.toLowerCase()));
                });
            }
        });
    }
    addco() {
        this.apicall.api_addcompany(this.co);
        this.co.name = null;
    }
    deleteco(id) {
        this.del.id = id;
        this.apicall.api_deletecompany(this.del);
    }
    filterex(evt) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.expense = this.expens;
            var val = evt.target.value;
            if (val && val.trim() != '') {
                this.expense = this.expense.filter((item) => {
                    return ((item.name.toLowerCase()).startsWith(val.toLowerCase()));
                });
            }
        });
    }
    addex() {
        this.apicall.api_addexpense(this.ex);
        this.ex.name = null;
    }
    detailex(id) {
        console.log(id);
        this.apicall.api_getexpensesdetail(id);
    }
    filterse(evt) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.seller = this.selle;
            var val = evt.target.value;
            if (val && val.trim() != '') {
                this.seller = this.seller.filter((item) => {
                    return ((item.s_name.toLowerCase()).startsWith(val.toLowerCase()));
                });
            }
        });
    }
    addse() {
        this.apicall.api_addseller(this.se);
        this.se.name = null;
        this.se.address = null;
    }
    deletese(id) {
        this.s_id = id;
        console.log(this.del);
        this.apicall.api_getsellerdetails(this.s_id);
        this.router.navigate(['seller-detail']);
    }
    filterty(evt) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.type = this.typ;
            var val = evt.target.value;
            if (val && val.trim() != '') {
                this.type = this.type.filter((item) => {
                    return ((item.name.toLowerCase()).startsWith(val.toLowerCase()));
                });
            }
        });
    }
    addty() {
        this.apicall.api_addtype(this.ty);
        this.ty.name = null;
        this.ty.address = null;
    }
    deletety(id) {
        this.del.id = id;
        this.apicall.api_deletetype(this.del);
    }
    filtercu(evt) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.customer = this.custome;
            var val = evt.target.value;
            if (val && val.trim() != '') {
                this.customer = this.customer.filter((item) => {
                    return ((item.name.toLowerCase()).startsWith(val.toLowerCase()));
                });
            }
        });
    }
    addcu() {
        console.log(this.cu);
        this.apicall.api_addcustomer(this.cu);
        this.cu.name = '';
        this.cu.address = '';
        this.cu.farm_address = '';
        this.cu.total = '';
        this.cu.remaining = '';
    }
    addemp() {
        console.log(this.emp);
        this.apicall.api_addemployer(this.emp);
        this.emp.name = null;
        this.emp.address = null;
        this.emp.phone = null;
        this.emp.total = null;
        this.emp.remaining = null;
    }
    details(id) {
        this.apicall.api_getcustomerdetails(id);
    }
    customerdetail(id) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const buttons = [
                {
                    text: 'See Detail',
                    icon: 'eye',
                    handler: () => {
                        // this.apicall.api_getcustomerdetails(id);
                    }
                },
                {
                    text: ' Add Credit',
                    icon: 'add',
                    handler: () => {
                        this.credit(id);
                    }
                },
                {
                    text: 'Cancel',
                    icon: 'close',
                    role: 'cancel',
                }
            ];
            const actionSheet = yield this.actionSheetCtrl.create({
                header: 'Select One',
                buttons
            });
            yield actionSheet.present();
        });
    }
    credit(id) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alert.create({
                cssClass: 'my-custom-class',
                header: 'Al-Nafay',
                mode: 'ios',
                subHeader: 'Add Credit',
                inputs: [
                    {
                        name: 'name',
                        type: 'number',
                        placeholder: 'Amount'
                    }
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                    }, {
                        text: 'Credit',
                        handler: (alertData) => {
                            this.updatedetail.customer_id = id;
                            this.updatedetail.received = alertData.name;
                            console.log(this.updatedetail);
                            this.apicall.api_updatecustomerbalance(this.updatedetail);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    detailcustomer(id) {
        this.presentLoadingWithOptions();
        this.apicall.api_getcustomerdetails(id);
        for (let i = 0; i < this.customer.length; i++) {
            if (this.customer[i].customer_id === id) {
                this.namec = this.customer[i].name;
            }
        }
        this.presentLoadingWithOptions();
        console.log(this.namec);
        this.router.navigate(['customerdetail'], { state: { data: this.namec } });
    }
    detailemployee(id) {
        this.presentLoadingWithOptions();
        this.apicall.api_getemployeedetail(id);
        this.presentLoadingWithOptions();
        this.router.navigate(['employeedetail']);
    }
    presentLoadingWithOptions() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                spinner: "circular",
                duration: 200,
                message: 'Order Is Being Placed',
                translucent: true,
                cssClass: 'custom-class custom-loading',
                backdropDismiss: true
            });
            yield loading.present();
            const {} = yield loading.onDidDismiss();
        });
    }
    updatecompany(value) {
        console.log(value);
        this.company2 = value;
        this.apicall.api_updatecompany(this.company2);
        this.idc = 0;
    }
    updateco(value) {
        this.idc = 1;
        console.log(value);
        this.co1 = value;
    }
    updatety(value) {
        this.idt = 1;
        console.log(value);
        this.ty2 = value;
    }
    updatetype(value) {
        console.log(value);
        this.type2 = value;
        this.apicall.api_updatetype(this.type2);
        this.idt = 0;
    }
    updatese(value) {
        this.ids = 1;
        console.log(value);
        this.se2 = value;
    }
    updateseller(value) {
        console.log(value);
        this.seller2 = value;
        this.apicall.api_updateseller(this.seller2);
        this.seller2 = '';
        this.ids = 0;
    }
};
CompanyPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"] },
    { type: src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__["ApicallService"] },
    { type: src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__["GlobalService"] }
];
CompanyPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-company',
        template: _raw_loader_company_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_company_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CompanyPage);



/***/ }),

/***/ "rXpt":
/*!*************************************************!*\
  !*** ./src/app/pages/company/company.module.ts ***!
  \*************************************************/
/*! exports provided: CompanyPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CompanyPageModule", function() { return CompanyPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _company_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./company-routing.module */ "4hzC");
/* harmony import */ var _company_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./company.page */ "lDms");
/* harmony import */ var ng2_search_filter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ng2-search-filter */ "cZdB");








let CompanyPageModule = class CompanyPageModule {
};
CompanyPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _company_routing_module__WEBPACK_IMPORTED_MODULE_5__["CompanyPageRoutingModule"],
            ng2_search_filter__WEBPACK_IMPORTED_MODULE_7__["Ng2SearchPipeModule"]
        ],
        declarations: [_company_page__WEBPACK_IMPORTED_MODULE_6__["CompanyPage"]]
    })
], CompanyPageModule);



/***/ })

}]);
//# sourceMappingURL=pages-company-company-module-es2015.js.map