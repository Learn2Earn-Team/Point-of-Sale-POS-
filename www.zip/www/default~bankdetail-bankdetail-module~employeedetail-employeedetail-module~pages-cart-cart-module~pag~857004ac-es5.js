(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac"], {
    /***/
    "Aluc":
    /*!*******************************************!*\
      !*** ./src/app/provider/alert.service.ts ***!
      \*******************************************/

    /*! exports provided: AlertService */

    /***/
    function Aluc(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AlertService", function () {
        return AlertService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");

      var AlertService = /*#__PURE__*/function () {
        function AlertService(Alert, nav) {
          _classCallCheck(this, AlertService);

          this.Alert = Alert;
          this.nav = nav;
        }

        _createClass(AlertService, [{
          key: "loginAlert",
          value: function loginAlert() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var alert;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.Alert.create({
                        header: 'Welcome',
                        message: 'Your Are Successfully Login',
                        buttons: [{
                          text: 'Okay'
                        }]
                      });

                    case 2:
                      alert = _context.sent;
                      _context.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "signup",
          value: function signup() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var alert;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.Alert.create({
                        header: 'Congrats',
                        subHeader: 'Your Are Successfully Registered',
                        message: 'Now please Login',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context2.sent;
                      _context2.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "password",
          value: function password() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var alert;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this.Alert.create({
                        header: 'Sorry',
                        message: 'Password not Matched',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context3.sent;
                      _context3.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "email",
          value: function email() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var alert;
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      _context4.next = 2;
                      return this.Alert.create({
                        header: 'Wooow',
                        subHeader: 'Oops!',
                        message: 'Invalid Email',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context4.sent;
                      _context4.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }, {
          key: "invalidlogin",
          value: function invalidlogin() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
              var alert;
              return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      _context5.next = 2;
                      return this.Alert.create({
                        header: 'Wooow',
                        subHeader: 'Oops!',
                        message: 'Invalid User name or Password',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context5.sent;
                      _context5.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee5, this);
            }));
          }
        }, {
          key: "connection",
          value: function connection() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
              var alert;
              return regeneratorRuntime.wrap(function _callee6$(_context6) {
                while (1) {
                  switch (_context6.prev = _context6.next) {
                    case 0:
                      _context6.next = 2;
                      return this.Alert.create({
                        header: 'Ooops',
                        subHeader: 'Check your Internet connection',
                        message: 'Connection failed!',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context6.sent;
                      _context6.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context6.stop();
                  }
                }
              }, _callee6, this);
            }));
          }
        }, {
          key: "invalidpass",
          value: function invalidpass() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
              var alert;
              return regeneratorRuntime.wrap(function _callee7$(_context7) {
                while (1) {
                  switch (_context7.prev = _context7.next) {
                    case 0:
                      _context7.next = 2;
                      return this.Alert.create({
                        header: 'Ooops',
                        subHeader: 'please inter Valid password',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context7.sent;
                      _context7.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context7.stop();
                  }
                }
              }, _callee7, this);
            }));
          }
        }, {
          key: "call",
          value: function call(message) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
              var alert;
              return regeneratorRuntime.wrap(function _callee8$(_context8) {
                while (1) {
                  switch (_context8.prev = _context8.next) {
                    case 0:
                      _context8.next = 2;
                      return this.Alert.create({
                        header: 'Al Nafay',
                        subHeader: message,
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context8.sent;
                      _context8.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context8.stop();
                  }
                }
              }, _callee8, this);
            }));
          }
        }, {
          key: "country",
          value: function country() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
              var _this = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee9$(_context9) {
                while (1) {
                  switch (_context9.prev = _context9.next) {
                    case 0:
                      _context9.next = 2;
                      return this.Alert.create({
                        header: 'Sorry',
                        message: 'Sorry We Dont Deliver to Any Country Except Orange',
                        buttons: [{
                          text: 'Okay',
                          handler: function handler() {
                            _this.nav.navigateForward('/Home');
                          }
                        }]
                      });

                    case 2:
                      alert = _context9.sent;
                      _context9.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context9.stop();
                  }
                }
              }, _callee9, this);
            }));
          }
        }, {
          key: "allready",
          value: function allready() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
              var alert;
              return regeneratorRuntime.wrap(function _callee10$(_context10) {
                while (1) {
                  switch (_context10.prev = _context10.next) {
                    case 0:
                      _context10.next = 2;
                      return this.Alert.create({
                        header: 'Ooops',
                        subHeader: 'This Email is Already Exist',
                        message: 'Please login',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context10.sent;
                      _context10.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context10.stop();
                  }
                }
              }, _callee10, this);
            }));
          }
        }, {
          key: "oldincorrect",
          value: function oldincorrect() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee11() {
              var alert;
              return regeneratorRuntime.wrap(function _callee11$(_context11) {
                while (1) {
                  switch (_context11.prev = _context11.next) {
                    case 0:
                      _context11.next = 2;
                      return this.Alert.create({
                        header: 'Ooops',
                        subHeader: 'Old Password Incorrect',
                        message: 'Please Try Again',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context11.sent;
                      _context11.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context11.stop();
                  }
                }
              }, _callee11, this);
            }));
          }
        }, {
          key: "newmatch",
          value: function newmatch() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee12() {
              var alert;
              return regeneratorRuntime.wrap(function _callee12$(_context12) {
                while (1) {
                  switch (_context12.prev = _context12.next) {
                    case 0:
                      _context12.next = 2;
                      return this.Alert.create({
                        header: 'Ooops',
                        subHeader: 'New Passwords Dont Match',
                        message: 'Try Again',
                        buttons: ['Ok']
                      });

                    case 2:
                      alert = _context12.sent;
                      _context12.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context12.stop();
                  }
                }
              }, _callee12, this);
            }));
          }
        }, {
          key: "updateprofile",
          value: function updateprofile() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee13() {
              var _this2 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee13$(_context13) {
                while (1) {
                  switch (_context13.prev = _context13.next) {
                    case 0:
                      _context13.next = 2;
                      return this.Alert.create({
                        header: 'Succesfull',
                        subHeader: 'Profile updated',
                        buttons: [{
                          text: 'Okay',
                          handler: function handler() {
                            _this2.nav.navigateForward('/tabs/tab3');
                          }
                        }]
                      });

                    case 2:
                      alert = _context13.sent;
                      _context13.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context13.stop();
                  }
                }
              }, _callee13, this);
            }));
          }
        }, {
          key: "passupdate",
          value: function passupdate() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee14() {
              var _this3 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee14$(_context14) {
                while (1) {
                  switch (_context14.prev = _context14.next) {
                    case 0:
                      _context14.next = 2;
                      return this.Alert.create({
                        header: 'Succesfull',
                        subHeader: 'Password updated',
                        buttons: [{
                          text: 'Okay',
                          handler: function handler() {
                            _this3.nav.navigateForward('/editprofile');
                          }
                        }]
                      });

                    case 2:
                      alert = _context14.sent;
                      _context14.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context14.stop();
                  }
                }
              }, _callee14, this);
            }));
          }
        }, {
          key: "addpost",
          value: function addpost() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee15() {
              var _this4 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee15$(_context15) {
                while (1) {
                  switch (_context15.prev = _context15.next) {
                    case 0:
                      _context15.next = 2;
                      return this.Alert.create({
                        header: 'Succesfull',
                        subHeader: 'Your Add has Been Posted',
                        buttons: [{
                          text: 'Okay',
                          handler: function handler() {
                            _this4.nav.navigateForward('/tabs/tab3');
                          }
                        }]
                      });

                    case 2:
                      alert = _context15.sent;
                      _context15.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context15.stop();
                  }
                }
              }, _callee15, this);
            }));
          }
        }, {
          key: "services",
          value: function services() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee16() {
              var alert;
              return regeneratorRuntime.wrap(function _callee16$(_context16) {
                while (1) {
                  switch (_context16.prev = _context16.next) {
                    case 0:
                      _context16.next = 2;
                      return this.Alert.create({
                        header: 'Ooops',
                        subHeader: 'please select appropriate services related  sub service',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context16.sent;
                      _context16.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context16.stop();
                  }
                }
              }, _callee16, this);
            }));
          }
        }]);

        return AlertService;
      }();

      AlertService.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
        }];
      };

      AlertService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], AlertService);
      /***/
    },

    /***/
    "G1p3":
    /*!*********************************************!*\
      !*** ./src/app/provider/apicall.service.ts ***!
      \*********************************************/

    /*! exports provided: ApicallService */

    /***/
    function G1p3(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ApicallService", function () {
        return ApicallService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./auth.service */
      "nCAS");
      /* harmony import */


      var _global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./global.service */
      "Lb7+");
      /* harmony import */


      var _alert_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./alert.service */
      "Aluc");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");

      var ApicallService = /*#__PURE__*/function () {
        function ApicallService(router, menuCtrl, authservice, global, Alert, navigate) {
          _classCallCheck(this, ApicallService);

          this.router = router;
          this.menuCtrl = menuCtrl;
          this.authservice = authservice;
          this.global = global;
          this.Alert = Alert;
          this.navigate = navigate;
        }

        _createClass(ApicallService, [{
          key: "api_login",
          value: function api_login(signin) {
            var _this5 = this;

            this.authservice.con(signin, 'login').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this5, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee17() {
                return regeneratorRuntime.wrap(function _callee17$(_context17) {
                  while (1) {
                    switch (_context17.prev = _context17.next) {
                      case 0:
                        this.response = JSON.parse(String(res));

                        if (!(this.response.error === false)) {
                          _context17.next = 7;
                          break;
                        }

                        console.log(this.response);
                        this.global.set_User(this.response.user);
                        this.Alert.loginAlert();
                        this.navigate.navigateForward("/start");
                        return _context17.abrupt("return");

                      case 7:
                        this.Alert.invalidlogin();
                        console.log(this.response.error); // tslint:disable-next-line: whitespace

                      case 9:
                      case "end":
                        return _context17.stop();
                    }
                  }
                }, _callee17, this);
              }));
            }, function (err) {
              _this5.Alert.connection();
            });
          }
        }, {
          key: "api_getmedicinedetail",
          value: function api_getmedicinedetail() {
            var _this6 = this;

            this.authservice.getdata('getmedicine').then(function (result) {
              _this6.data = JSON.parse(String(result));
              _this6.data = _this6.data.filter(function (data) {
                return data.total_quantity > 0;
              });

              _this6.global.set_Medicinedetail(_this6.data);

              console.log(_this6.data, "data Updated");
            }, function (err) {
              _this6.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getmedicine",
          value: function api_getmedicine() {
            var _this7 = this;

            this.authservice.getdata('getmedicine').then(function (result) {
              _this7.data = JSON.parse(String(result));

              _this7.global.set_Medicine(_this7.data);
            }, function (err) {
              _this7.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getcustomerdetails",
          value: function api_getcustomerdetails(id) {
            var _this8 = this;

            this.authservice.getdata('getcustomerdetail/' + id).then(function (result) {
              _this8.data = JSON.parse(String(result));

              _this8.global.set_Customerdetails(_this8.data); // this.router.navigate(['customerdetail']);

            }, function (err) {
              _this8.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getbankdetail",
          value: function api_getbankdetail(id) {
            var _this9 = this;

            this.authservice.getdata('getbankdetail/' + id).then(function (result) {
              _this9.data = JSON.parse(String(result));

              _this9.global.set_Bankdetail(_this9.data); // this.router.navigate(['customerdetail']);

            }, function (err) {
              _this9.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getemployeedetail",
          value: function api_getemployeedetail(id) {
            var _this10 = this;

            this.authservice.getdata('getemployeedetail/' + id).then(function (result) {
              _this10.data = JSON.parse(String(result));

              _this10.global.set_Employeedetails(_this10.data); // this.router.navigate(['customerdetail']);

            }, function (err) {
              _this10.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getsellerdetails",
          value: function api_getsellerdetails(id) {
            var _this11 = this;

            this.authservice.getdata('getsellerdetail/' + id).then(function (result) {
              _this11.data = JSON.parse(String(result));

              _this11.global.set_Sellerdetails(_this11.data);
            }, function (err) {
              _this11.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getdetail",
          value: function api_getdetail(id) {
            var _this12 = this;

            this.authservice.getdata('getmedicinedetail/' + id).then(function (result) {
              _this12.data = JSON.parse(String(result));

              _this12.global.set_Detail(_this12.data);

              console.log(_this12.data);

              _this12.router.navigate(['seller']);
            }, function (err) {
              _this12.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getexpensesdetail",
          value: function api_getexpensesdetail(id) {
            var _this13 = this;

            this.authservice.getdata('getexpensesdetail/' + id).then(function (result) {
              _this13.data = JSON.parse(String(result));

              _this13.global.set_Expensedetail(_this13.data);

              _this13.global.set_Ids(id);

              console.log(_this13.data);

              _this13.router.navigate(['expense']);
            }, function (err) {
              _this13.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_gettype",
          value: function api_gettype() {
            var _this14 = this;

            this.authservice.getdata('gettype').then(function (result) {
              _this14.global.set_Type(JSON.parse(String(result)));
            }, function (err) {
              _this14.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_addtype",
          value: function api_addtype(data) {
            var _this15 = this;

            this.authservice.con(data, 'inserttype').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this15, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee18() {
                return regeneratorRuntime.wrap(function _callee18$(_context18) {
                  while (1) {
                    switch (_context18.prev = _context18.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context18.next = 5;
                          break;
                        }

                        this.Alert.call("New Type Added");
                        this.api_gettype();
                        return _context18.abrupt("return");

                      case 5:
                      case "end":
                        return _context18.stop();
                    }
                  }
                }, _callee18, this);
              }));
            }, function (err) {
              console.log(err);

              _this15.Alert.connection();
            });
          }
        }, {
          key: "api_insertexpensedetail",
          value: function api_insertexpensedetail(data) {
            var _this16 = this;

            this.authservice.con(data, 'insertexpensedetail').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this16, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee19() {
                return regeneratorRuntime.wrap(function _callee19$(_context19) {
                  while (1) {
                    switch (_context19.prev = _context19.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context19.next = 5;
                          break;
                        }

                        this.Alert.call("New Data Added");
                        this.api_getexpensesdetail(data.id);
                        return _context19.abrupt("return");

                      case 5:
                      case "end":
                        return _context19.stop();
                    }
                  }
                }, _callee19, this);
              }));
            }, function (err) {
              console.log(err);

              _this16.Alert.connection();
            });
          }
        }, {
          key: "api_adddetail",
          value: function api_adddetail(data) {
            var _this17 = this;

            this.authservice.con(data, 'insertmedicinedetail').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this17, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee20() {
                return regeneratorRuntime.wrap(function _callee20$(_context20) {
                  while (1) {
                    switch (_context20.prev = _context20.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context20.next = 5;
                          break;
                        }

                        this.Alert.call("New Data Added");
                        this.router.navigate(['medicine']);
                        return _context20.abrupt("return");

                      case 5:
                      case "end":
                        return _context20.stop();
                    }
                  }
                }, _callee20, this);
              }));
            }, function (err) {
              console.log(err);

              _this17.Alert.connection();
            });
          }
        }, {
          key: "api_addorder",
          value: function api_addorder(data) {
            var _this18 = this;

            this.authservice.con(data, 'addorder').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this18, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee21() {
                return regeneratorRuntime.wrap(function _callee21$(_context21) {
                  while (1) {
                    switch (_context21.prev = _context21.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context21.next = 6;
                          break;
                        }

                        this.Alert.call("New order Added");
                        this.global.set_Cart(null);
                        this.router.navigate(['main']);
                        return _context21.abrupt("return");

                      case 6:
                      case "end":
                        return _context21.stop();
                    }
                  }
                }, _callee21, this);
              }));
            }, function (err) {
              console.log(err);

              _this18.Alert.connection();
            });
          }
        }, {
          key: "api_addorderemp",
          value: function api_addorderemp(data) {
            var _this19 = this;

            this.authservice.con(data, 'addorderemp').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this19, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee22() {
                return regeneratorRuntime.wrap(function _callee22$(_context22) {
                  while (1) {
                    switch (_context22.prev = _context22.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context22.next = 6;
                          break;
                        }

                        this.Alert.call("New order Added");
                        this.global.set_Cart(null);
                        this.router.navigate(['main']);
                        return _context22.abrupt("return");

                      case 6:
                      case "end":
                        return _context22.stop();
                    }
                  }
                }, _callee22, this);
              }));
            }, function (err) {
              console.log(err);

              _this19.Alert.connection();
            });
          }
        }, {
          key: "api_getcustomer",
          value: function api_getcustomer() {
            var _this20 = this;

            this.authservice.getdata('getcustomer').then(function (result) {
              _this20.global.set_Customer(JSON.parse(String(result)));
            }, function (err) {
              _this20.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getbanks",
          value: function api_getbanks() {
            var _this21 = this;

            this.authservice.getdata('getbank').then(function (result) {
              _this21.global.set_Bank(JSON.parse(String(result)));
            }, function (err) {
              _this21.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getemployee",
          value: function api_getemployee() {
            var _this22 = this;

            this.authservice.getdata('getemployee').then(function (result) {
              _this22.global.set_Employee(JSON.parse(String(result)));
            }, function (err) {
              _this22.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getexpense",
          value: function api_getexpense() {
            var _this23 = this;

            this.authservice.getdata('getexpenses').then(function (result) {
              _this23.global.set_Expense(JSON.parse(String(result)));
            }, function (err) {
              _this23.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_addexpense",
          value: function api_addexpense(data) {
            var _this24 = this;

            this.authservice.con(data, 'insertexpense').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this24, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee23() {
                return regeneratorRuntime.wrap(function _callee23$(_context23) {
                  while (1) {
                    switch (_context23.prev = _context23.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context23.next = 5;
                          break;
                        }

                        this.Alert.call("New Expense Added");
                        this.api_getexpense();
                        return _context23.abrupt("return");

                      case 5:
                      case "end":
                        return _context23.stop();
                    }
                  }
                }, _callee23, this);
              }));
            }, function (err) {
              console.log(err);

              _this24.Alert.connection();
            });
          }
        }, {
          key: "api_addcustomer",
          value: function api_addcustomer(data) {
            var _this25 = this;

            this.authservice.con(data, 'insertcustomer').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this25, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee24() {
                return regeneratorRuntime.wrap(function _callee24$(_context24) {
                  while (1) {
                    switch (_context24.prev = _context24.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context24.next = 5;
                          break;
                        }

                        this.Alert.call("New Customer Added");
                        this.api_getcustomer();
                        return _context24.abrupt("return");

                      case 5:
                      case "end":
                        return _context24.stop();
                    }
                  }
                }, _callee24, this);
              }));
            }, function (err) {
              console.log(err);

              _this25.Alert.connection();
            });
          }
        }, {
          key: "api_addbank",
          value: function api_addbank(data) {
            var _this26 = this;

            this.authservice.con(data, 'insertbank').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this26, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee25() {
                return regeneratorRuntime.wrap(function _callee25$(_context25) {
                  while (1) {
                    switch (_context25.prev = _context25.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context25.next = 5;
                          break;
                        }

                        this.Alert.call("New Bank Added");
                        this.api_getbanks();
                        return _context25.abrupt("return");

                      case 5:
                      case "end":
                        return _context25.stop();
                    }
                  }
                }, _callee25, this);
              }));
            }, function (err) {
              console.log(err);

              _this26.Alert.connection();
            });
          }
        }, {
          key: "api_addbankdetail",
          value: function api_addbankdetail(data) {
            var _this27 = this;

            this.authservice.con(data, 'insertbankdetail').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this27, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee26() {
                return regeneratorRuntime.wrap(function _callee26$(_context26) {
                  while (1) {
                    switch (_context26.prev = _context26.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context26.next = 4;
                          break;
                        }

                        this.Alert.call("New Bank Detail Added");
                        return _context26.abrupt("return");

                      case 4:
                      case "end":
                        return _context26.stop();
                    }
                  }
                }, _callee26, this);
              }));
            }, function (err) {
              console.log(err);

              _this27.Alert.connection();
            });
          }
        }, {
          key: "detail",
          value: function detail(data) {
            var _this28 = this;

            this.authservice.con(data, 'insertbankdetail').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this28, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee27() {
                return regeneratorRuntime.wrap(function _callee27$(_context27) {
                  while (1) {
                    switch (_context27.prev = _context27.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context27.next = 4;
                          break;
                        }

                        this.Alert.call("New Bank Detail Added"); // this.api_getbanks();

                        return _context27.abrupt("return");

                      case 4:
                      case "end":
                        return _context27.stop();
                    }
                  }
                }, _callee27, this);
              }));
            }, function (err) {
              console.log(err);

              _this28.Alert.connection();
            });
          }
        }, {
          key: "api_addemployer",
          value: function api_addemployer(data) {
            var _this29 = this;

            this.authservice.con(data, 'insertemployee').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this29, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee28() {
                return regeneratorRuntime.wrap(function _callee28$(_context28) {
                  while (1) {
                    switch (_context28.prev = _context28.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context28.next = 5;
                          break;
                        }

                        this.Alert.call("New Employee Added");
                        this.api_getemployee();
                        return _context28.abrupt("return");

                      case 5:
                      case "end":
                        return _context28.stop();
                    }
                  }
                }, _callee28, this);
              }));
            }, function (err) {
              console.log(err);

              _this29.Alert.connection();
            });
          }
        }, {
          key: "api_insertmedicine",
          value: function api_insertmedicine(data) {
            var _this30 = this;

            this.authservice.con(data, 'insertmedicine').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this30, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee29() {
                return regeneratorRuntime.wrap(function _callee29$(_context29) {
                  while (1) {
                    switch (_context29.prev = _context29.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context29.next = 5;
                          break;
                        }

                        this.Alert.call("New Medicine Added");
                        this.api_gettype();
                        return _context29.abrupt("return");

                      case 5:
                      case "end":
                        return _context29.stop();
                    }
                  }
                }, _callee29, this);
              }));
            }, function (err) {
              console.log(err);

              _this30.Alert.connection();
            });
          }
        }, {
          key: "api_deletetype",
          value: function api_deletetype(data) {
            var _this31 = this;

            this.authservice.con(data, 'deletetype').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this31, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee30() {
                return regeneratorRuntime.wrap(function _callee30$(_context30) {
                  while (1) {
                    switch (_context30.prev = _context30.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context30.next = 5;
                          break;
                        }

                        this.Alert.call("Type Deleted");
                        this.api_gettype();
                        return _context30.abrupt("return");

                      case 5:
                      case "end":
                        return _context30.stop();
                    }
                  }
                }, _callee30, this);
              }));
            }, function (err) {
              console.log(err);

              _this31.Alert.connection();
            });
          }
        }, {
          key: "api_deleteexpense",
          value: function api_deleteexpense(data) {
            var _this32 = this;

            this.authservice.con(data, 'deleteexpense').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this32, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee31() {
                return regeneratorRuntime.wrap(function _callee31$(_context31) {
                  while (1) {
                    switch (_context31.prev = _context31.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context31.next = 5;
                          break;
                        }

                        this.Alert.call("Expense Deleted");
                        this.api_getexpense();
                        return _context31.abrupt("return");

                      case 5:
                      case "end":
                        return _context31.stop();
                    }
                  }
                }, _callee31, this);
              }));
            }, function (err) {
              console.log(err);

              _this32.Alert.connection();
            });
          }
        }, {
          key: "api_getcompany",
          value: function api_getcompany() {
            var _this33 = this;

            this.authservice.getdata('getcompany').then(function (result) {
              _this33.global.set_Company(JSON.parse(String(result)));
            }, function (err) {
              _this33.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_addcompany",
          value: function api_addcompany(data) {
            var _this34 = this;

            this.authservice.con(data, 'insertcompany').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this34, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee32() {
                return regeneratorRuntime.wrap(function _callee32$(_context32) {
                  while (1) {
                    switch (_context32.prev = _context32.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context32.next = 5;
                          break;
                        }

                        this.Alert.call("New Company Added");
                        this.api_getcompany();
                        return _context32.abrupt("return");

                      case 5:
                      case "end":
                        return _context32.stop();
                    }
                  }
                }, _callee32, this);
              }));
            }, function (err) {
              console.log(err);

              _this34.Alert.connection();
            });
          }
        }, {
          key: "api_deletecompany",
          value: function api_deletecompany(data) {
            var _this35 = this;

            this.authservice.con(data, 'deletecompany').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this35, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee33() {
                return regeneratorRuntime.wrap(function _callee33$(_context33) {
                  while (1) {
                    switch (_context33.prev = _context33.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context33.next = 5;
                          break;
                        }

                        this.Alert.call("Company Deleted");
                        this.api_getcompany();
                        return _context33.abrupt("return");

                      case 5:
                      case "end":
                        return _context33.stop();
                    }
                  }
                }, _callee33, this);
              }));
            }, function (err) {
              console.log(err);

              _this35.Alert.connection();
            });
          }
        }, {
          key: "api_getseller",
          value: function api_getseller() {
            var _this36 = this;

            this.authservice.getdata('getseller').then(function (result) {
              _this36.global.set_Seller(JSON.parse(String(result)));
            }, function (err) {
              _this36.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_addseller",
          value: function api_addseller(data) {
            var _this37 = this;

            this.authservice.con(data, 'insertseller').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this37, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee34() {
                return regeneratorRuntime.wrap(function _callee34$(_context34) {
                  while (1) {
                    switch (_context34.prev = _context34.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context34.next = 5;
                          break;
                        }

                        this.Alert.call("New Seller Added");
                        this.api_getseller();
                        return _context34.abrupt("return");

                      case 5:
                      case "end":
                        return _context34.stop();
                    }
                  }
                }, _callee34, this);
              }));
            }, function (err) {
              console.log(err);

              _this37.Alert.connection();
            });
          }
        }, {
          key: "api_deleteseller",
          value: function api_deleteseller(data) {
            var _this38 = this;

            this.authservice.con(data, 'deleteseller').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this38, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee35() {
                return regeneratorRuntime.wrap(function _callee35$(_context35) {
                  while (1) {
                    switch (_context35.prev = _context35.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context35.next = 5;
                          break;
                        }

                        this.Alert.call("Seller Deleted");
                        this.api_getseller();
                        return _context35.abrupt("return");

                      case 5:
                      case "end":
                        return _context35.stop();
                    }
                  }
                }, _callee35, this);
              }));
            }, function (err) {
              console.log(err);

              _this38.Alert.connection();
            });
          }
        }, {
          key: "api_getinvoices",
          value: function api_getinvoices() {
            var _this39 = this;

            this.authservice.getdata('getinvoices').then(function (result) {
              _this39.data = JSON.parse(String(result));

              _this39.global.set_Invoice(_this39.data);

              console.log(_this39.data);
            }, function (err) {
              _this39.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getinvoicespur",
          value: function api_getinvoicespur() {
            var _this40 = this;

            this.authservice.getdata('getinvoicespur').then(function (result) {
              _this40.data = JSON.parse(String(result));

              _this40.global.set_Invoicepur(_this40.data);

              console.log(_this40.data);
            }, function (err) {
              _this40.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getinvoicesemp",
          value: function api_getinvoicesemp() {
            var _this41 = this;

            this.authservice.getdata('getinvoicesemp').then(function (result) {
              _this41.data = JSON.parse(String(result));

              _this41.global.set_Invoiceemp(_this41.data);

              console.log(_this41.data);
            }, function (err) {
              _this41.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getinvoicedetail",
          value: function api_getinvoicedetail(id) {
            var _this42 = this;

            this.authservice.getdata('getinvoicedetail/' + id).then(function (result) {
              _this42.data = JSON.parse(String(result));

              _this42.global.set_Invoicedetail(_this42.data);

              console.log(_this42.data); //this.router.navigate(['detail']);
            }, function (err) {
              _this42.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getinvoicedetailpur",
          value: function api_getinvoicedetailpur(id) {
            var _this43 = this;

            this.authservice.getdata('getinvoicedetailpur/' + id).then(function (result) {
              _this43.data = JSON.parse(String(result));

              _this43.global.set_Invoicedetail(_this43.data);

              console.log(_this43.data); //this.router.navigate(['detail']);
            }, function (err) {
              _this43.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getinvoicedetailemp",
          value: function api_getinvoicedetailemp(id) {
            var _this44 = this;

            this.authservice.getdata('getinvoicedetailemp/' + id).then(function (result) {
              _this44.data = JSON.parse(String(result));

              _this44.global.set_Invoicedetail(_this44.data);

              console.log(_this44.data); //this.router.navigate(['detail']);
            }, function (err) {
              _this44.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_showtransaction",
          value: function api_showtransaction(data) {
            var _this45 = this;

            this.authservice.con(data, 'gettransaction').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this45, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee36() {
                return regeneratorRuntime.wrap(function _callee36$(_context36) {
                  while (1) {
                    switch (_context36.prev = _context36.next) {
                      case 0:
                        this.data = JSON.parse(String(res));
                        this.global.set_Transactiondetail(this.data); // this.router.navigate(['detail']);

                      case 2:
                      case "end":
                        return _context36.stop();
                    }
                  }
                }, _callee36, this);
              }));
            }, function (err) {
              _this45.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_showmedidetail",
          value: function api_showmedidetail(data) {
            var _this46 = this;

            this.authservice.con(data, 'showdetail11').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this46, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee37() {
                return regeneratorRuntime.wrap(function _callee37$(_context37) {
                  while (1) {
                    switch (_context37.prev = _context37.next) {
                      case 0:
                        this.data = JSON.parse(String(res));
                        this.global.set_Detail(this.data);
                        console.log(this.data);
                        this.router.navigate(['seller']);

                      case 4:
                      case "end":
                        return _context37.stop();
                    }
                  }
                }, _callee37, this);
              }));
            }, function (err) {
              _this46.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getcustomerbalance",
          value: function api_getcustomerbalance(id) {
            var _this47 = this;

            this.authservice.getdata('getcustomerbalance/' + id).then(function (result) {
              _this47.data = JSON.parse(String(result)); // this.global.set_Customerdetails(this.data);
              //this.router.navigate(['customerdetail']);
            }, function (err) {
              _this47.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_updatecustomerbalance",
          value: function api_updatecustomerbalance(data) {
            var _this48 = this;

            this.authservice.con(data, 'updatecustomerbalance').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this48, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee38() {
                return regeneratorRuntime.wrap(function _callee38$(_context38) {
                  while (1) {
                    switch (_context38.prev = _context38.next) {
                      case 0:
                        this.data = JSON.parse(String(res));
                        this.router.navigate(['company']);

                      case 2:
                      case "end":
                        return _context38.stop();
                    }
                  }
                }, _callee38, this);
              }));
            }, function (err) {
              _this48.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_updateemployeebalance",
          value: function api_updateemployeebalance(data) {
            var _this49 = this;

            this.authservice.con(data, 'updateemployeebalance').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this49, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee39() {
                return regeneratorRuntime.wrap(function _callee39$(_context39) {
                  while (1) {
                    switch (_context39.prev = _context39.next) {
                      case 0:
                        this.data = JSON.parse(String(res));
                        this.router.navigate(['company']);

                      case 2:
                      case "end":
                        return _context39.stop();
                    }
                  }
                }, _callee39, this);
              }));
            }, function (err) {
              _this49.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_updatesellerbalance",
          value: function api_updatesellerbalance(data) {
            var _this50 = this;

            this.authservice.con(data, 'updatesellerrbalance').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this50, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee40() {
                return regeneratorRuntime.wrap(function _callee40$(_context40) {
                  while (1) {
                    switch (_context40.prev = _context40.next) {
                      case 0:
                        this.data = JSON.parse(String(res));
                        this.router.navigate(['company']);

                      case 2:
                      case "end":
                        return _context40.stop();
                    }
                  }
                }, _callee40, this);
              }));
            }, function (err) {
              _this50.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_salereturn",
          value: function api_salereturn(data) {
            var _this51 = this;

            this.authservice.con(data, 'salereturn').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this51, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee41() {
                return regeneratorRuntime.wrap(function _callee41$(_context41) {
                  while (1) {
                    switch (_context41.prev = _context41.next) {
                      case 0:
                        this.data = JSON.parse(String(res));

                      case 1:
                      case "end":
                        return _context41.stop();
                    }
                  }
                }, _callee41, this);
              }));
            }, function (err) {
              _this51.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_salereturnemp",
          value: function api_salereturnemp(data) {
            var _this52 = this;

            this.authservice.con(data, 'salereturnemp').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this52, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee42() {
                return regeneratorRuntime.wrap(function _callee42$(_context42) {
                  while (1) {
                    switch (_context42.prev = _context42.next) {
                      case 0:
                        this.data = JSON.parse(String(res));

                      case 1:
                      case "end":
                        return _context42.stop();
                    }
                  }
                }, _callee42, this);
              }));
            }, function (err) {
              _this52.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getpurchase",
          value: function api_getpurchase(id) {
            var _this53 = this;

            this.authservice.getdata('getpurchasedetail/' + id).then(function (result) {
              _this53.data = JSON.parse(String(result));

              _this53.global.set_Purchasedetail(_this53.data);

              console.log(_this53.data); //this.router.navigate(['detail']);
            }, function (err) {
              _this53.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_purchasereturn",
          value: function api_purchasereturn(data) {
            var _this54 = this;

            this.authservice.con(data, 'purchasereturn').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this54, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee43() {
                return regeneratorRuntime.wrap(function _callee43$(_context43) {
                  while (1) {
                    switch (_context43.prev = _context43.next) {
                      case 0:
                        this.data = JSON.parse(String(res));

                      case 1:
                      case "end":
                        return _context43.stop();
                    }
                  }
                }, _callee43, this);
              }));
            }, function (err) {
              _this54.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_inserthistory",
          value: function api_inserthistory(data) {
            var _this55 = this;

            this.authservice.con(data, 'inserthistory').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this55, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee44() {
                return regeneratorRuntime.wrap(function _callee44$(_context44) {
                  while (1) {
                    switch (_context44.prev = _context44.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context44.next = 3;
                          break;
                        }

                        return _context44.abrupt("return");

                      case 3:
                      case "end":
                        return _context44.stop();
                    }
                  }
                }, _callee44, this);
              }));
            }, function (err) {
              console.log(err);
            });
          }
        }, {
          key: "api_purchasemedicine",
          value: function api_purchasemedicine(data) {
            var _this56 = this;

            this.authservice.con(data, 'addpurchase').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this56, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee45() {
                return regeneratorRuntime.wrap(function _callee45$(_context45) {
                  while (1) {
                    switch (_context45.prev = _context45.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context45.next = 3;
                          break;
                        }

                        return _context45.abrupt("return");

                      case 3:
                      case "end":
                        return _context45.stop();
                    }
                  }
                }, _callee45, this);
              }));
            }, function (err) {
              console.log(err);
            });
          }
        }, {
          key: "api_totalpurchase",
          value: function api_totalpurchase(data) {
            var _this57 = this;

            this.authservice.con(data, 'gettotalsale').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this57, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee46() {
                return regeneratorRuntime.wrap(function _callee46$(_context46) {
                  while (1) {
                    switch (_context46.prev = _context46.next) {
                      case 0:
                        this.data = JSON.parse(String(res));
                        this.global.set_Totalsale(this.data);

                      case 2:
                      case "end":
                        return _context46.stop();
                    }
                  }
                }, _callee46, this);
              }));
            }, function (err) {
              _this57.Alert.connection();

              console.log(err);
            });
            this.authservice.con(data, 'gettotalexpense').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this57, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee47() {
                return regeneratorRuntime.wrap(function _callee47$(_context47) {
                  while (1) {
                    switch (_context47.prev = _context47.next) {
                      case 0:
                        this.data = JSON.parse(String(res));
                        this.global.set_Totalex(this.data);

                      case 2:
                      case "end":
                        return _context47.stop();
                    }
                  }
                }, _callee47, this);
              }));
            }, function (err) {
              _this57.Alert.connection();

              console.log(err);
            });
            this.authservice.con(data, 'gettotalpurchase').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this57, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee48() {
                return regeneratorRuntime.wrap(function _callee48$(_context48) {
                  while (1) {
                    switch (_context48.prev = _context48.next) {
                      case 0:
                        this.data = JSON.parse(String(res));
                        this.global.set_Totalpur(this.data);

                      case 2:
                      case "end":
                        return _context48.stop();
                    }
                  }
                }, _callee48, this);
              }));
            }, function (err) {
              _this57.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_updatemedicine",
          value: function api_updatemedicine(data) {
            var _this58 = this;

            this.authservice.con(data, 'updatemedicine').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this58, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee49() {
                return regeneratorRuntime.wrap(function _callee49$(_context49) {
                  while (1) {
                    switch (_context49.prev = _context49.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context49.next = 3;
                          break;
                        }

                        return _context49.abrupt("return");

                      case 3:
                      case "end":
                        return _context49.stop();
                    }
                  }
                }, _callee49, this);
              }));
            }, function (err) {
              console.log(err);
            });
          } // update apis data

        }, {
          key: "api_updatecompany",
          value: function api_updatecompany(data) {
            var _this59 = this;

            this.authservice.con(data, 'updatecompany').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this59, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee50() {
                return regeneratorRuntime.wrap(function _callee50$(_context50) {
                  while (1) {
                    switch (_context50.prev = _context50.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context50.next = 5;
                          break;
                        }

                        this.Alert.call('Data Updated Succfully');
                        this.api_getcompany();
                        return _context50.abrupt("return");

                      case 5:
                      case "end":
                        return _context50.stop();
                    }
                  }
                }, _callee50, this);
              }));
            }, function (err) {
              console.log(err);

              _this59.Alert.connection();
            });
          }
        }, {
          key: "api_updatetype",
          value: function api_updatetype(data) {
            var _this60 = this;

            this.authservice.con(data, 'updatetype').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this60, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee51() {
                return regeneratorRuntime.wrap(function _callee51$(_context51) {
                  while (1) {
                    switch (_context51.prev = _context51.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context51.next = 5;
                          break;
                        }

                        this.Alert.call('Data Updated Succfully');
                        this.api_gettype();
                        return _context51.abrupt("return");

                      case 5:
                      case "end":
                        return _context51.stop();
                    }
                  }
                }, _callee51, this);
              }));
            }, function (err) {
              console.log(err);

              _this60.Alert.connection();
            });
          }
        }, {
          key: "api_updateseller",
          value: function api_updateseller(data) {
            var _this61 = this;

            this.authservice.con(data, 'updateseller').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this61, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee52() {
                return regeneratorRuntime.wrap(function _callee52$(_context52) {
                  while (1) {
                    switch (_context52.prev = _context52.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context52.next = 5;
                          break;
                        }

                        this.Alert.call('Data Updated Succfully');
                        this.api_getcompany();
                        return _context52.abrupt("return");

                      case 5:
                      case "end":
                        return _context52.stop();
                    }
                  }
                }, _callee52, this);
              }));
            }, function (err) {
              console.log(err);

              _this61.Alert.connection();
            });
          }
        }]);

        return ApicallService;
      }();

      ApicallService.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["MenuController"]
        }, {
          type: _auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]
        }, {
          type: _global_service__WEBPACK_IMPORTED_MODULE_3__["GlobalService"]
        }, {
          type: _alert_service__WEBPACK_IMPORTED_MODULE_4__["AlertService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"]
        }];
      };

      ApicallService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], ApicallService);
      /***/
    },

    /***/
    "nCAS":
    /*!******************************************!*\
      !*** ./src/app/provider/auth.service.ts ***!
      \******************************************/

    /*! exports provided: AuthService */

    /***/
    function nCAS(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AuthService", function () {
        return AuthService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common/http */
      "tk/3"); //const apiUrl = 'http://localhost/dairylinks/public/';


      var apiUrl = 'https://Learn2earnn.com/dairylinks/public/';

      var AuthService = /*#__PURE__*/function () {
        function AuthService(http) {
          _classCallCheck(this, AuthService);

          this.http = http;
        }

        _createClass(AuthService, [{
          key: "con",
          value: function con(data, type) {
            var _this62 = this;

            return new Promise(function (resolve, reject) {
              _this62.http.post(apiUrl + type, JSON.stringify(data)).subscribe(function (res) {
                resolve(JSON.stringify(res));
              }, function (err) {
                reject(err);
                console.log(err);
              });
            });
          } // geting posts

        }, {
          key: "getdata",
          value: function getdata(type) {
            var _this63 = this;

            return new Promise(function (resolve, reject) {
              _this63.http.get(apiUrl + type).subscribe(function (res) {
                resolve(JSON.stringify(res));
              }, function (err) {
                reject(err);
                console.log(err);
              });
            });
          }
        }]);

        return AuthService;
      }();

      AuthService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
        }];
      };

      AuthService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], AuthService);
      /***/
    }
  }]);
})();
//# sourceMappingURL=default~bankdetail-bankdetail-module~employeedetail-employeedetail-module~pages-cart-cart-module~pag~857004ac-es5.js.map