(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-main-main-module"], {
    /***/
    "82nU":
    /*!*******************************************!*\
      !*** ./src/app/pages/main/main.module.ts ***!
      \*******************************************/

    /*! exports provided: MainPageModule */

    /***/
    function nU(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MainPageModule", function () {
        return MainPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _main_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./main-routing.module */
      "TIEH");
      /* harmony import */


      var _main_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./main.page */
      "TQIn");
      /* harmony import */


      var ng2_search_filter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ng2-search-filter */
      "cZdB");

      var MainPageModule = function MainPageModule() {
        _classCallCheck(this, MainPageModule);
      };

      MainPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _main_routing_module__WEBPACK_IMPORTED_MODULE_5__["MainPageRoutingModule"], ng2_search_filter__WEBPACK_IMPORTED_MODULE_7__["Ng2SearchPipeModule"]],
        declarations: [_main_page__WEBPACK_IMPORTED_MODULE_6__["MainPage"]]
      })], MainPageModule);
      /***/
    },

    /***/
    "8rh1":
    /*!*******************************************!*\
      !*** ./src/app/pages/main/main.page.scss ***!
      \*******************************************/

    /*! exports provided: default */

    /***/
    function rh1(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #5f8ff8, #ffffff);\n}\n\nion-content ion-grid {\n  margin: 10px;\n  justify-content: center;\n  align-content: center;\n}\n\nion-content ion-grid ion-row {\n  justify-content: center;\n}\n\nion-content ion-grid ion-row ion-col {\n  background: var(--ion-color-success);\n  box-shadow: 4px 10px 30px -3px #050505;\n  min-width: 15rem;\n  max-width: 15rem;\n  height: 17.5rem;\n  margin: 1rem;\n  text-align: center;\n  justify-content: center;\n  border-radius: 20px;\n}\n\nion-content ion-grid ion-row ion-col .quantity {\n  justify-content: center;\n}\n\nion-content ion-grid ion-row ion-col .quantity .minus {\n  float: left;\n  background-color: var(--ion-color-dark);\n  height: 1.8rem;\n  width: 1.8rem;\n  border-top-left-radius: 5px;\n  border-bottom-left-radius: 5px;\n}\n\nion-content ion-grid ion-row ion-col .quantity .minus ion-icon {\n  color: var(--ion-color-light);\n  padding: 0.45rem;\n}\n\nion-content ion-grid ion-row ion-col .quantity .input {\n  border: 1px solid var(--ion-color-dark);\n  float: left;\n  width: 30%;\n  text-align: center;\n  justify-content: center;\n}\n\nion-content ion-grid ion-row ion-col .quantity .input p {\n  margin: 6px 0 0 0;\n  color: white;\n}\n\nion-content ion-grid ion-row ion-col .quantity .plus {\n  float: right;\n  background-color: var(--ion-color-dark);\n  height: 1.8rem;\n  width: 1.8rem;\n  border-top-right-radius: 5px;\n  border-bottom-right-radius: 5px;\n}\n\nion-content ion-grid ion-row ion-col .quantity .plus ion-icon {\n  color: var(--ion-color-light);\n  padding: 0.45rem;\n}\n\nion-content ion-grid ion-row ion-col ion-item {\n  margin: -8px;\n  text-align: center;\n  justify-content: center;\n  --background: transparent;\n}\n\nion-content ion-grid ion-row ion-col ion-item ion-label {\n  font-size: 0.8rem;\n  color: var(--ion-color-light);\n}\n\nion-content ion-grid ion-row ion-col ion-button {\n  margin: 0.5rem;\n  --border-radius: 20px;\n  height: 2rem;\n}\n\n@media screen and (max-width: 550px) {\n  td, th {\n    font-size: 14px;\n  }\n}\n\n@media screen and (max-width: 500px) {\n  td, th {\n    font-size: 12px;\n  }\n}\n\n@media screen and (max-width: 450px) {\n  td, th {\n    font-size: 11px;\n  }\n}\n\n@media screen and (max-width: 400px) {\n  td, th {\n    font-size: 10px;\n  }\n}\n\n@media screen and (max-width: 370px) {\n  td, th {\n    font-size: 9px;\n  }\n}\n\ntable {\n  width: 100%;\n  border-collapse: collapse;\n}\n\n/* Zebra striping */\n\ntr:nth-of-type(odd) {\n  background: #eee;\n}\n\nth {\n  background: #333;\n  color: white;\n}\n\ntd, th {\n  padding: 3px;\n  border: 1px solid #ccc;\n  text-align: left;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL21haW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0NBQUE7QUFDSjs7QUFDQTtFQUNFLDBEQUFBO0FBRUY7O0FBREk7RUFDSSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxxQkFBQTtBQUdSOztBQUZRO0VBQ0ksdUJBQUE7QUFJWjs7QUFIWTtFQUNJLG9DQUFBO0VBQ0Esc0NBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBRUEsbUJBQUE7QUFJaEI7O0FBSGdCO0VBQ0ksdUJBQUE7QUFLcEI7O0FBSm9CO0VBQ0ksV0FBQTtFQUNBLHVDQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7RUFDQSwyQkFBQTtFQUNBLDhCQUFBO0FBTXhCOztBQUx3QjtFQUNJLDZCQUFBO0VBQ0EsZ0JBQUE7QUFPNUI7O0FBSm9CO0VBQ0ksdUNBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7QUFNeEI7O0FBTHdCO0VBQ0ksaUJBQUE7RUFDQSxZQUFBO0FBTzVCOztBQUpvQjtFQUNJLFlBQUE7RUFDQSx1Q0FBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0VBQ0EsNEJBQUE7RUFDQSwrQkFBQTtBQU14Qjs7QUFMd0I7RUFDSSw2QkFBQTtFQUNBLGdCQUFBO0FBTzVCOztBQUhnQjtFQUNJLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0EseUJBQUE7QUFLcEI7O0FBSm9CO0VBQ0ksaUJBQUE7RUFDQSw2QkFBQTtBQU14Qjs7QUFIZ0I7RUFDSSxjQUFBO0VBQ0EscUJBQUE7RUFDQSxZQUFBO0FBS3BCOztBQUVBO0VBQ0k7SUFDSSxlQUFBO0VBQ047QUFDRjs7QUFDQTtFQUNJO0lBQ0ksZUFBQTtFQUNOO0FBQ0Y7O0FBQ0E7RUFDSTtJQUNJLGVBQUE7RUFDTjtBQUNGOztBQUNBO0VBQ0k7SUFDSSxlQUFBO0VBQ047QUFDRjs7QUFDQTtFQUNJO0lBQ0ksY0FBQTtFQUNOO0FBQ0Y7O0FBRUE7RUFDSSxXQUFBO0VBQ0EseUJBQUE7QUFBSjs7QUFFQSxtQkFBQTs7QUFDQTtFQUNJLGdCQUFBO0FBQ0o7O0FBQ0E7RUFDSSxnQkFBQTtFQUNBLFlBQUE7QUFFSjs7QUFBQTtFQUNJLFlBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0FBR0oiLCJmaWxlIjoibWFpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcclxufVxyXG5pb24tY29udGVudCB7XHJcbiAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjNWY4ZmY4LCAjZmZmZmZmKTtcclxuICAgIGlvbi1ncmlkIHtcclxuICAgICAgICBtYXJnaW46IDEwcHg7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgYWxpZ24tY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIGlvbi1yb3cge1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgaW9uLWNvbCB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc3VjY2Vzcyk7XHJcbiAgICAgICAgICAgICAgICBib3gtc2hhZG93OiA0cHggMTBweCAzMHB4IC0zcHggIzA1MDUwNTtcclxuICAgICAgICAgICAgICAgIG1pbi13aWR0aDogMTVyZW07XHJcbiAgICAgICAgICAgICAgICBtYXgtd2lkdGg6IDE1cmVtO1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAxNy41cmVtO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAxcmVtO1xyXG4gICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAvLyBtYXgtaGVpZ2h0OiAxMnJlbTtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICAgICAgICAgICAgICAucXVhbnRpdHl7XHJcbiAgICAgICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgLm1pbnVze1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmbG9hdDpsZWZ0OyBcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDEuOHJlbTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDEuOHJlbTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNXB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlvbi1pY29ue1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAwLjQ1cmVtO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC5pbnB1dHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmbG9hdDpsZWZ0O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogMzAlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBwe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiA2cHggMCAwIDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogcmdiKDI1NSwgMjU1LCAyNTUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIC5wbHVze1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmbG9hdDpyaWdodDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDEuOHJlbTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDEuOHJlbTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaW9uLWljb257XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDAuNDVyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpb24taXRlbSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAtOHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICAgICAgICAgIGlvbi1sYWJlbHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAwLjhyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbjogMC41cmVtO1xyXG4gICAgICAgICAgICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDJyZW07XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDU1MHB4KSB7XHJcbiAgICB0ZCx0aCAge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIH1cclxufVxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA1MDBweCkge1xyXG4gICAgdGQsdGggIHtcclxuICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICB9XHJcbn1cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDUwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgfVxyXG59XHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDQwMHB4KSB7XHJcbiAgICB0ZCx0aCAge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgIH1cclxufVxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAzNzBweCkge1xyXG4gICAgdGQsdGggIHtcclxuICAgICAgICBmb250LXNpemU6IDlweDtcclxuICAgIH1cclxufVxyXG5cclxudGFibGUge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG59XHJcbi8qIFplYnJhIHN0cmlwaW5nICovXHJcbnRyOm50aC1vZi10eXBlKG9kZCkge1xyXG4gICAgYmFja2dyb3VuZDogI2VlZTtcclxufVxyXG50aCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjMzMzO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcbnRkLCB0aCB7XHJcbiAgICBwYWRkaW5nOiAzcHg7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxufVxyXG4iXX0= */";
      /***/
    },

    /***/
    "TIEH":
    /*!***************************************************!*\
      !*** ./src/app/pages/main/main-routing.module.ts ***!
      \***************************************************/

    /*! exports provided: MainPageRoutingModule */

    /***/
    function TIEH(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MainPageRoutingModule", function () {
        return MainPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _main_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./main.page */
      "TQIn");
      /* harmony import */


      var ng2_search_filter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ng2-search-filter */
      "cZdB");

      var routes = [{
        path: '',
        component: _main_page__WEBPACK_IMPORTED_MODULE_3__["MainPage"]
      }];

      var MainPageRoutingModule = function MainPageRoutingModule() {
        _classCallCheck(this, MainPageRoutingModule);
      };

      MainPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [ng2_search_filter__WEBPACK_IMPORTED_MODULE_4__["Ng2SearchPipeModule"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], MainPageRoutingModule);
      /***/
    },

    /***/
    "TQIn":
    /*!*****************************************!*\
      !*** ./src/app/pages/main/main.page.ts ***!
      \*****************************************/

    /*! exports provided: MainPage */

    /***/
    function TQIn(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MainPage", function () {
        return MainPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_main_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./main.page.html */
      "c9wX");
      /* harmony import */


      var _main_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./main.page.scss */
      "8rh1");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! src/app/provider/apicall.service */
      "G1p3");
      /* harmony import */


      var src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/app/provider/global.service */
      "Lb7+");

      var MainPage = /*#__PURE__*/function () {
        function MainPage(toastController, menu, apicall, global) {
          _classCallCheck(this, MainPage);

          this.toastController = toastController;
          this.menu = menu;
          this.apicall = apicall;
          this.global = global;
          this.data = [];
          this.data1 = [];
          this.number = 1;
          this.cart = [];
        }

        _createClass(MainPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.menu.enable(true);
            this.apicall.api_getmedicinedetail();
            this.global.Medicinedetail.subscribe(function (res) {
              _this.dat = null;
              console.log(_this.dat, "ng");
              _this.data = res;
              _this.dat = res;
              console.log(_this.dat);
              _this.cart = [];
            });
          }
        }, {
          key: "function",
          value: function _function(i, num) {
            if (num == 1) {
              if (this.data[i].number != 1) {
                this.data[i].number--;
              }
            } else if (num == 2) {
              if (this.data[i].number < this.data[i].total_quantity) {
                this.data[i].number++;
              }
            }
          }
        }, {
          key: "addcart",
          value: function addcart(a) {
            this.cart.push(a); // this.dat = this.dat.filter(data => data.p_id != a.p_id);

            this.global.set_Cart(this.cart);
            this.presentToast();
          }
        }, {
          key: "filterorder",
          value: function filterorder(evt) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var val;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      this.dat = this.data;
                      val = evt.target.value;

                      if (val && val.trim() != '') {
                        this.dat = this.dat.filter(function (item) {
                          return item.name.toLowerCase().startsWith(val.toLowerCase());
                        });
                      }

                    case 3:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "presentToast",
          value: function presentToast() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var toast;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.toastController.create({
                        message: 'Added to Cart',
                        duration: 2000
                      });

                    case 2:
                      toast = _context2.sent;
                      toast.present();

                    case 4:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }]);

        return MainPage;
      }();

      MainPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"]
        }, {
          type: src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__["ApicallService"]
        }, {
          type: src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__["GlobalService"]
        }];
      };

      MainPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-main',
        template: _raw_loader_main_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_main_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], MainPage);
      /***/
    },

    /***/
    "c9wX":
    /*!*********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/main/main.page.html ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function c9wX(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Dairy Links</ion-title>\n      <ion-icon slot=\"end\" name=\"cart\" routerLink=\"/cart\" style=\"zoom: 2;margin-right: 7px;\" color=\"light\"></ion-icon>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-searchbar [(ngModel)]=\"term\"></ion-searchbar>\n<!--  <ion-grid>-->\n\n<!--    <ion-row color=\"success\" >-->\n<!--      <ion-col *ngFor=\"let a of dat; let i = index\" >-->\n<!--        <ion-item text-center lines=\"none\"><ion-label>Product Name:{{a.name}}</ion-label></ion-item>-->\n<!--        <ion-item text-center lines=\"none\"><ion-label>Avaiable Stock:{{a.total_quantity}}</ion-label></ion-item>-->\n<!--        <ion-item text-center lines=\"none\"><ion-label>Packing Size:{{a.packing_name}}</ion-label></ion-item>-->\n<!--        <ion-item  text-center lines=\"none\"><ion-label>Purchasing Price:{{a.purchasing}}</ion-label></ion-item>-->\n<!--        <ion-item text-center lines=\"none\"><ion-label>Retail Price:{{a.selling}}</ion-label></ion-item>-->\n\n<!--&lt;!&ndash;        <ion-row class=\"quantity\">&ndash;&gt;-->\n<!--&lt;!&ndash;          <div class=\"minus\" (click)=\"function(i,1)\">&ndash;&gt;-->\n<!--&lt;!&ndash;            <ion-icon name=\"remove-outline\"></ion-icon>&ndash;&gt;-->\n<!--&lt;!&ndash;          </div>&ndash;&gt;-->\n<!--&lt;!&ndash;          <div class=\"input\">&ndash;&gt;-->\n<!--&lt;!&ndash;            <p>{{a.number}}</p>&ndash;&gt;-->\n<!--&lt;!&ndash;          </div>&ndash;&gt;-->\n<!--&lt;!&ndash;          <div class=\"plus\" (click)=\"function(i,2)\">&ndash;&gt;-->\n<!--&lt;!&ndash;            <ion-icon name=\"add-outline\"></ion-icon>&ndash;&gt;-->\n<!--&lt;!&ndash;          </div>&ndash;&gt;-->\n<!--&lt;!&ndash;        </ion-row>&ndash;&gt;-->\n<!--        <ion-button color=\"light\" expand=\"block\" (click)=\"addcart(a)\" >Add to Cart</ion-button>-->\n<!--      </ion-col>-->\n<!--    </ion-row>-->\n<!--  </ion-grid>-->\n\n  <table>\n    <thead>\n    <tr>\n      <th style=\"background: #333; \">Product Name:</th>\n      <th style=\"background: #333; \">Packing Size</th>\n      <th style=\"background: #333; \">Avaiable Stock</th>\n      <th style=\"background: #333; \">Purchasing Price</th>\n      <th style=\"background: rgb(204, 13, 13); \">Retail Price</th>\n      <th style=\"background: rgb(204, 13, 13); \">Add to Cart</th>\n    </tr>\n    </thead>\n    <tbody>\n\n    <tr *ngFor=\"let a of dat |filter:term ; let i = index \">\n      <td>{{a.name}}</td>\n      <td>{{a.packing_name}}</td>\n      <td >{{a.total_quantity}}</td>\n      <td >{{a.purchasing}}</td>\n      <td >{{a.selling}}</td>\n      <td > <ion-button color=\"light\" expand=\"block\" (click)=\"addcart(a)\" >Add to Cart</ion-button></td>\n      <!--       <ion-button style=\"margin: 1px\" (click)=\"updatecustomerbalance(a)\"></ion-button>-->\n    </tr>\n    </tbody>\n  </table>\n\n</ion-content>\n";
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-main-main-module-es5.js.map