(function () {
  function _objectDestructuringEmpty(obj) { if (obj == null) throw new TypeError("Cannot destructure undefined"); }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-company-company-module"], {
    /***/
    "0EGn":
    /*!***************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/company/company.page.html ***!
      \***************************************************************************************/

    /*! exports provided: default */

    /***/
    function EGn(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Dairy Links</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-segment color=\"dark\" [(ngModel)]=\"sign\">\n    <ion-segment-button value=\"co\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Company</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"ty\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Type</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"emp\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Employee</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"cu\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Customer</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"se\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Distributer</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"ex\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Expense</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n  <div color=\"success\" class=\"main\" [ngSwitch]=\"sign\">\n    <ion-list class=\"f\" *ngSwitchCase=\"'co'\">\n      <div *ngIf=\"this.idc == 0\">\n\n        <form #form=\"ngForm\" (ngSubmit)=\"addco()\">\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Add Company</ion-label>\n            <ion-input name=\"name\" [(ngModel)]=\"term\" type=\"text\" [(ngModel)]=\"co.name\"></ion-input>\n          </ion-item>\n          <ion-button expand=\"block\" color=\"success\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n        </form>\n\n      </div>\n      <div *ngIf=\"this.idc == 1\">\n\n        <form #form=\"ngForm\" >\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Add Company</ion-label>\n            <ion-input name=\"n ame\"  type=\"text\" [(ngModel)]=\"co1.c_name\"></ion-input>\n          </ion-item>\n          <ion-button expand=\"block\" color=\"success\" type=\"submit\" (click)=\"updatecompany(co1)\">Update</ion-button>\n        </form>\n      </div>\n      <ion-searchbar (ionInput)=\"filterco($event)\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of company |filter:term \">\n        <ion-item>\n          {{a.c_name}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"danger\" (click)=\"deleteco(a.c_id)\">Delete</ion-item-option>\n        </ion-item-options>\n        <ion-item-options side=\"start\">\n          <ion-item-option color=\"success\" (click)=\"updateco(a)\">Update Data</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n\n    </ion-list>\n    <ion-list class=\"f\" *ngSwitchCase=\"'ty'\">\n      <div *ngIf=\"this.idt == 0\">\n        <form #form=\"ngForm\" (ngSubmit)=\"addty()\">\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Add Dosage form</ion-label>\n            <ion-input name=\"name\" [(ngModel)]=\"term1\" type=\"text\" [(ngModel)]=\"ty.name\"></ion-input>\n          </ion-item>\n          <ion-button expand=\"block\" color=\"success\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n        </form>\n      </div>\n      <div *ngIf=\"this.idt == 1\">\n        <form #form=\"ngForm\">\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Add Dosage form</ion-label>\n            <ion-input name=\"name\"  type=\"text\" [(ngModel)]=\"ty2.name\"></ion-input>\n          </ion-item>\n          <ion-button expand=\"block\" color=\"success\" type=\"submit\" (click)=\"updatetype(ty2)\" >Update</ion-button>\n        </form>\n      </div>\n      <ion-searchbar [(ngModel)]=\"term1\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of type |filter:term1\">\n        <ion-item>\n          {{a.name}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"danger\" (click)=\"deletety(a.t_id)\">Delete</ion-item-option>\n        </ion-item-options>\n        <ion-item-options side=\"start\">\n          <ion-item-option color=\"success\" (click)=\"updatety(a)\">Update Data</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n    </ion-list>\n    <ion-list class=\"f\" *ngSwitchCase=\"'emp'\">\n      <form #form=\"ngForm\" (ngSubmit)=\"addemp()\">\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Employee Name</ion-label>\n          <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"emp.name\"></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Employee Address</ion-label>\n          <ion-input name=\"address\" type=\"text\" [(ngModel)]=\"emp.address\"></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Mobile no</ion-label>\n          <ion-input name=\"phone\" type=\"text\" [(ngModel)]=\"emp.phone\"></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Enter ENIC</ion-label>\n          <ion-input name=\"cnic\" type=\"text\" [(ngModel)]=\"emp.cnic\"></ion-input>\n        </ion-item>\n        <ion-button expand=\"block\" color=\"light\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n      </form>\n      <ion-searchbar [(ngModel)]=\"term2\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of employee |filter:term2\">\n        <ion-item>\n          {{a.name}}  {{a.address}} {{a.phone}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"success\" (click)=\"detailemployee(a.e_id)\">See Detail</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n    </ion-list>\n\n    <ion-list class=\"f\" *ngSwitchCase=\"'cu'\">\n      <form #form=\"ngForm\" (ngSubmit)=\"addcu()\">\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Customer Name</ion-label>\n          <ion-input name=\"name\" (ionInput)=\"filtercu($event)\" type=\"text\" [(ngModel)]=\"cu.name\"></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Customer Address</ion-label>\n          <ion-input name=\"address\" type=\"text\" [(ngModel)]=\"cu.address\"></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Mobile No</ion-label>\n          <ion-input name=\"address\" type=\"text\" [(ngModel)]=\"cu.mobile_no\"></ion-input>\n        </ion-item>\n        <ion-button expand=\"block\" color=\"success\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n      </form>\n      <ion-searchbar [(ngModel)]=\"term3\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of customer |filter:term3\">\n        <ion-item>\n          {{a.name}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"success\" (click)=\"detailcustomer(a.customer_id)\">See Detail</ion-item-option>\n        </ion-item-options>\n        <ion-item-options side=\"start\">\n          <ion-item-option color=\"success\" (click)=\"detailcustomer(a.customer_id)\">Update Data</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n    </ion-list>\n\n    <ion-list class=\"f\" *ngSwitchCase=\"'se'\">\n      <div *ngIf=\"this.ids == 0\">\n        <form #form=\"ngForm\" (ngSubmit)=\"addse()\">\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Distributer Name</ion-label>\n            <ion-input name=\"name\" (ionInput)=\"filterse($event)\" type=\"text\" [(ngModel)]=\"se.name\"></ion-input>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Distributer Address</ion-label>\n            <ion-input name=\"address\" type=\"text\" [(ngModel)]=\"se.address\"></ion-input>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Phone No</ion-label>\n            <ion-input name=\"address\" type=\"text\" [(ngModel)]=\"se.phone\"></ion-input>\n          </ion-item>\n          <ion-button expand=\"block\" color=\"success\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n        </form>\n      </div>\n      <div *ngIf=\"this.ids == 1\">\n        <form #form=\"ngForm\">\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Distributer Name</ion-label>\n            <ion-input name=\"name\" (ionInput)=\"filterse($event)\" type=\"text\" [(ngModel)]=\"se2.s_name\"></ion-input>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Distributer Address</ion-label>\n            <ion-input name=\"address\" type=\"text\" [(ngModel)]=\"se2.s_address\"></ion-input>\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-label position=\"floating\">Phone No</ion-label>\n            <ion-input name=\"address\" type=\"text\" [(ngModel)]=\"se2.phone\"></ion-input>\n          </ion-item>\n          <ion-button expand=\"block\" color=\"success\" type=\"submit\" (click)=\"updateseller(se2)\" >Update</ion-button>\n        </form>\n      </div>\n      <ion-searchbar [(ngModel)]=\"term4\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of seller |filter:term4\">\n        <ion-item>\n          {{a.s_name}}&nbsp;{{a.s_address}} {{a.phone}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"success\" (click)=\"deletese(a.s_id)\">See Detail</ion-item-option>\n        </ion-item-options>\n        <ion-item-options side=\"start\">\n          <ion-item-option color=\"success\" (click)=\"updatese(a)\">Update Data</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n    </ion-list>\n    <ion-list class=\"f\" *ngSwitchCase=\"'ex'\">\n      <form #form=\"ngForm\" (ngSubmit)=\"addex()\">\n        <ion-item lines=\"none\">\n          <ion-label position=\"floating\">Add Expense</ion-label>\n          <ion-input name=\"name\" type=\"text\" [(ngModel)]=\"ex.name\"></ion-input>\n        </ion-item>\n        <ion-button expand=\"block\" color=\"light\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n      </form>\n      <ion-searchbar (ionInput)=\"filterex($event)\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of expense\">\n        <ion-item>\n          {{a.name}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"success\" (click)=\"detailex(a.e_id)\">See Detail</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n    </ion-list>\n  </div>\n\n</ion-content>\n";
      /***/
    },

    /***/
    "4hzC":
    /*!*********************************************************!*\
      !*** ./src/app/pages/company/company-routing.module.ts ***!
      \*********************************************************/

    /*! exports provided: CompanyPageRoutingModule */

    /***/
    function hzC(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CompanyPageRoutingModule", function () {
        return CompanyPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _company_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./company.page */
      "lDms");

      var routes = [{
        path: '',
        component: _company_page__WEBPACK_IMPORTED_MODULE_3__["CompanyPage"]
      }];

      var CompanyPageRoutingModule = function CompanyPageRoutingModule() {
        _classCallCheck(this, CompanyPageRoutingModule);
      };

      CompanyPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], CompanyPageRoutingModule);
      /***/
    },

    /***/
    "R/T6":
    /*!*************************************************!*\
      !*** ./src/app/pages/company/company.page.scss ***!
      \*************************************************/

    /*! exports provided: default */

    /***/
    function RT6(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-toolbar {\n  --background: var(--ion-color-success);\n}\n\nion-content {\n  --background: linear-gradient(to bottom, #5f8ff8, #ffffff);\n}\n\nion-content ion-item {\n  --background: transparent;\n}\n\nion-content ion-item ion-input {\n  border-bottom: 1px solid black;\n}\n\nion-content ion-button {\n  margin: 15px 20px 15px 20px;\n  border-radius: 30px;\n  box-shadow: 4px 9px 29px -9px #050505;\n}\n\nion-content ion-list {\n  background: transparent;\n}\n\nion-row {\n  width: 90%;\n}\n\nion-row ion-item {\n  width: 100%;\n  margin-top: 0;\n  margin-bottom: -1rem;\n}\n\nion-row ion-item ion-row {\n  justify-content: center;\n}\n\nion-row ion-item ion-row ion-label {\n  font-size: small;\n  margin-top: 0;\n  margin-bottom: 0;\n  margin-left: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL2NvbXBhbnkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0NBQUE7QUFDSjs7QUFDQTtFQUNJLDBEQUFBO0FBRUo7O0FBREc7RUFDSyx5QkFBQTtBQUdSOztBQUZRO0VBQ0ksOEJBQUE7QUFJWjs7QUFESTtFQUNJLDJCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQ0FBQTtBQUdSOztBQURJO0VBQ0ksdUJBQUE7QUFHUjs7QUFBQTtFQUNJLFVBQUE7QUFHSjs7QUFGSTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0Esb0JBQUE7QUFJUjs7QUFIUTtFQUNJLHVCQUFBO0FBS1o7O0FBSlk7RUFDSSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBTWhCIiwiZmlsZSI6ImNvbXBhbnkucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc3VjY2Vzcyk7XHJcbn1cclxuaW9uLWNvbnRlbnQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjNWY4ZmY4LCAjZmZmZmZmKTtcclxuICAgaW9uLWl0ZW17XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgICBpb24taW5wdXR7XHJcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBibGFjaztcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgIG1hcmdpbjoxNXB4IDIwcHggMTVweCAyMHB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcbiAgICAgICAgYm94LXNoYWRvdzogNHB4IDlweCAyOXB4IC05cHggIzA1MDUwNTtcclxuICAgIH1cclxuICAgIGlvbi1saXN0e1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgfVxyXG59XHJcbmlvbi1yb3d7XHJcbiAgICB3aWR0aDo5MCU7XHJcbiAgICBpb24taXRlbXtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICBtYXJnaW4tdG9wOiAwO1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IC0xcmVtO1xyXG4gICAgICAgIGlvbi1yb3d7XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgICBpb24tbGFiZWx7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IHNtYWxsO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMDtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMjBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSJdfQ== */";
      /***/
    },

    /***/
    "lDms":
    /*!***********************************************!*\
      !*** ./src/app/pages/company/company.page.ts ***!
      \***********************************************/

    /*! exports provided: CompanyPage */

    /***/
    function lDms(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CompanyPage", function () {
        return CompanyPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_company_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./company.page.html */
      "0EGn");
      /* harmony import */


      var _company_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./company.page.scss */
      "R/T6");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! src/app/provider/apicall.service */
      "G1p3");
      /* harmony import */


      var src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! src/app/provider/global.service */
      "Lb7+");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");

      var CompanyPage = /*#__PURE__*/function () {
        function CompanyPage(loadingController, router, alert, actionSheetCtrl, menu, apicall, global) {
          _classCallCheck(this, CompanyPage);

          this.loadingController = loadingController;
          this.router = router;
          this.alert = alert;
          this.actionSheetCtrl = actionSheetCtrl;
          this.menu = menu;
          this.apicall = apicall;
          this.global = global;
          this.idc = 0;
          this.idg = 0;
          this.idt = 0;
          this.ids = 0;
          this.co = {
            name: null,
            other: ""
          };
          this.se = {
            name: null,
            address: null,
            other: ""
          };
          this.ty = {
            name: null,
            address: null,
            other: ""
          };
          this.cu = {
            name: '',
            address: '',
            farm_address: '',
            mobile_no: '',
            total: '',
            remaining: ''
          };
          this.emp = {
            name: null,
            address: null,
            phone: null,
            cnic: null,
            total: null,
            remaining: null
          };
          this.ex = {
            name: null
          };
          this.updatedetail = {
            customer_id: null,
            received: null
          };
          this.del = {
            s_id: null
          };
        }

        _createClass(CompanyPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.sign = "co";
            this.apicall.api_getcompany();
            this.global.Company.subscribe(function (res) {
              _this.compan = res;
              _this.company = res;
              console.log(res);
            });
            this.apicall.api_getseller();
            this.global.Seller.subscribe(function (res) {
              _this.selle = res;
              _this.seller = res;
            });
            this.apicall.api_gettype();
            this.global.Type.subscribe(function (res) {
              _this.typ = res;
              _this.type = res;
            });
            this.apicall.api_getcustomer();
            this.global.Customer.subscribe(function (res) {
              _this.custome = res;
              _this.customer = res;
            });
            this.apicall.api_getemployee();
            this.global.Employee.subscribe(function (res) {
              _this.employe = res;
              _this.employee = res;
              console.log(_this.employee);
            });
            this.apicall.api_getexpense();
            this.global.Expense.subscribe(function (res) {
              _this.expens = res;
              _this.expense = res;
            });
          }
        }, {
          key: "filterco",
          value: function filterco(evt) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var val;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      this.company = this.compan;
                      val = evt.target.value;

                      if (val && val.trim() != '') {
                        this.company = this.company.filter(function (item) {
                          return item.c_name.toLowerCase().startsWith(val.toLowerCase());
                        });
                      }

                    case 3:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "addco",
          value: function addco() {
            this.apicall.api_addcompany(this.co);
            this.co.name = null;
          }
        }, {
          key: "deleteco",
          value: function deleteco(id) {
            this.del.id = id;
            this.apicall.api_deletecompany(this.del);
          }
        }, {
          key: "filterex",
          value: function filterex(evt) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var val;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      this.expense = this.expens;
                      val = evt.target.value;

                      if (val && val.trim() != '') {
                        this.expense = this.expense.filter(function (item) {
                          return item.name.toLowerCase().startsWith(val.toLowerCase());
                        });
                      }

                    case 3:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "addex",
          value: function addex() {
            this.apicall.api_addexpense(this.ex);
            this.ex.name = null;
          }
        }, {
          key: "detailex",
          value: function detailex(id) {
            console.log(id);
            this.apicall.api_getexpensesdetail(id);
          }
        }, {
          key: "filterse",
          value: function filterse(evt) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var val;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      this.seller = this.selle;
                      val = evt.target.value;

                      if (val && val.trim() != '') {
                        this.seller = this.seller.filter(function (item) {
                          return item.s_name.toLowerCase().startsWith(val.toLowerCase());
                        });
                      }

                    case 3:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "addse",
          value: function addse() {
            this.apicall.api_addseller(this.se);
            this.se.name = null;
            this.se.address = null;
          }
        }, {
          key: "deletese",
          value: function deletese(id) {
            this.s_id = id;
            console.log(this.del);
            this.apicall.api_getsellerdetails(this.s_id);
            this.router.navigate(['seller-detail']);
          }
        }, {
          key: "filterty",
          value: function filterty(evt) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var val;
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      this.type = this.typ;
                      val = evt.target.value;

                      if (val && val.trim() != '') {
                        this.type = this.type.filter(function (item) {
                          return item.name.toLowerCase().startsWith(val.toLowerCase());
                        });
                      }

                    case 3:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }, {
          key: "addty",
          value: function addty() {
            this.apicall.api_addtype(this.ty);
            this.ty.name = null;
            this.ty.address = null;
          }
        }, {
          key: "deletety",
          value: function deletety(id) {
            this.del.id = id;
            this.apicall.api_deletetype(this.del);
          }
        }, {
          key: "filtercu",
          value: function filtercu(evt) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
              var val;
              return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      this.customer = this.custome;
                      val = evt.target.value;

                      if (val && val.trim() != '') {
                        this.customer = this.customer.filter(function (item) {
                          return item.name.toLowerCase().startsWith(val.toLowerCase());
                        });
                      }

                    case 3:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee5, this);
            }));
          }
        }, {
          key: "addcu",
          value: function addcu() {
            console.log(this.cu);
            this.apicall.api_addcustomer(this.cu);
            this.cu.name = '';
            this.cu.address = '';
            this.cu.farm_address = '';
            this.cu.total = '';
            this.cu.remaining = '';
          }
        }, {
          key: "addemp",
          value: function addemp() {
            console.log(this.emp);
            this.apicall.api_addemployer(this.emp);
            this.emp.name = null;
            this.emp.address = null;
            this.emp.phone = null;
            this.emp.total = null;
            this.emp.remaining = null;
          }
        }, {
          key: "details",
          value: function details(id) {
            this.apicall.api_getcustomerdetails(id);
          }
        }, {
          key: "customerdetail",
          value: function customerdetail(id) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
              var _this2 = this;

              var buttons, actionSheet;
              return regeneratorRuntime.wrap(function _callee6$(_context6) {
                while (1) {
                  switch (_context6.prev = _context6.next) {
                    case 0:
                      buttons = [{
                        text: 'See Detail',
                        icon: 'eye',
                        handler: function handler() {// this.apicall.api_getcustomerdetails(id);
                        }
                      }, {
                        text: ' Add Credit',
                        icon: 'add',
                        handler: function handler() {
                          _this2.credit(id);
                        }
                      }, {
                        text: 'Cancel',
                        icon: 'close',
                        role: 'cancel'
                      }];
                      _context6.next = 3;
                      return this.actionSheetCtrl.create({
                        header: 'Select One',
                        buttons: buttons
                      });

                    case 3:
                      actionSheet = _context6.sent;
                      _context6.next = 6;
                      return actionSheet.present();

                    case 6:
                    case "end":
                      return _context6.stop();
                  }
                }
              }, _callee6, this);
            }));
          }
        }, {
          key: "credit",
          value: function credit(id) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
              var _this3 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee7$(_context7) {
                while (1) {
                  switch (_context7.prev = _context7.next) {
                    case 0:
                      _context7.next = 2;
                      return this.alert.create({
                        cssClass: 'my-custom-class',
                        header: 'Al-Nafay',
                        mode: 'ios',
                        subHeader: 'Add Credit',
                        inputs: [{
                          name: 'name',
                          type: 'number',
                          placeholder: 'Amount'
                        }],
                        buttons: [{
                          text: 'Cancel',
                          role: 'cancel'
                        }, {
                          text: 'Credit',
                          handler: function handler(alertData) {
                            _this3.updatedetail.customer_id = id;
                            _this3.updatedetail.received = alertData.name;
                            console.log(_this3.updatedetail);

                            _this3.apicall.api_updatecustomerbalance(_this3.updatedetail);
                          }
                        }]
                      });

                    case 2:
                      alert = _context7.sent;
                      _context7.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context7.stop();
                  }
                }
              }, _callee7, this);
            }));
          }
        }, {
          key: "detailcustomer",
          value: function detailcustomer(id) {
            this.presentLoadingWithOptions();
            this.apicall.api_getcustomerdetails(id);

            for (var i = 0; i < this.customer.length; i++) {
              if (this.customer[i].customer_id === id) {
                this.namec = this.customer[i].name;
              }
            }

            this.presentLoadingWithOptions();
            console.log(this.namec);
            this.router.navigate(['customerdetail'], {
              state: {
                data: this.namec
              }
            });
          }
        }, {
          key: "detailemployee",
          value: function detailemployee(id) {
            this.presentLoadingWithOptions();
            this.apicall.api_getemployeedetail(id);
            this.presentLoadingWithOptions();
            this.router.navigate(['employeedetail']);
          }
        }, {
          key: "presentLoadingWithOptions",
          value: function presentLoadingWithOptions() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
              var loading, _yield$loading$onDidD;

              return regeneratorRuntime.wrap(function _callee8$(_context8) {
                while (1) {
                  switch (_context8.prev = _context8.next) {
                    case 0:
                      _context8.next = 2;
                      return this.loadingController.create({
                        spinner: "circular",
                        duration: 200,
                        message: 'Order Is Being Placed',
                        translucent: true,
                        cssClass: 'custom-class custom-loading',
                        backdropDismiss: true
                      });

                    case 2:
                      loading = _context8.sent;
                      _context8.next = 5;
                      return loading.present();

                    case 5:
                      _context8.next = 7;
                      return loading.onDidDismiss();

                    case 7:
                      _yield$loading$onDidD = _context8.sent;

                      _objectDestructuringEmpty(_yield$loading$onDidD);

                    case 9:
                    case "end":
                      return _context8.stop();
                  }
                }
              }, _callee8, this);
            }));
          }
        }, {
          key: "updatecompany",
          value: function updatecompany(value) {
            console.log(value);
            this.company2 = value;
            this.apicall.api_updatecompany(this.company2);
            this.idc = 0;
          }
        }, {
          key: "updateco",
          value: function updateco(value) {
            this.idc = 1;
            console.log(value);
            this.co1 = value;
          }
        }, {
          key: "updatety",
          value: function updatety(value) {
            this.idt = 1;
            console.log(value);
            this.ty2 = value;
          }
        }, {
          key: "updatetype",
          value: function updatetype(value) {
            console.log(value);
            this.type2 = value;
            this.apicall.api_updatetype(this.type2);
            this.idt = 0;
          }
        }, {
          key: "updatese",
          value: function updatese(value) {
            this.ids = 1;
            console.log(value);
            this.se2 = value;
          }
        }, {
          key: "updateseller",
          value: function updateseller(value) {
            console.log(value);
            this.seller2 = value;
            this.apicall.api_updateseller(this.seller2);
            this.seller2 = '';
            this.ids = 0;
          }
        }]);

        return CompanyPage;
      }();

      CompanyPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["MenuController"]
        }, {
          type: src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_5__["ApicallService"]
        }, {
          type: src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_6__["GlobalService"]
        }];
      };

      CompanyPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-company',
        template: _raw_loader_company_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_company_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], CompanyPage);
      /***/
    },

    /***/
    "rXpt":
    /*!*************************************************!*\
      !*** ./src/app/pages/company/company.module.ts ***!
      \*************************************************/

    /*! exports provided: CompanyPageModule */

    /***/
    function rXpt(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CompanyPageModule", function () {
        return CompanyPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _company_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./company-routing.module */
      "4hzC");
      /* harmony import */


      var _company_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./company.page */
      "lDms");
      /* harmony import */


      var ng2_search_filter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ng2-search-filter */
      "cZdB");

      var CompanyPageModule = function CompanyPageModule() {
        _classCallCheck(this, CompanyPageModule);
      };

      CompanyPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _company_routing_module__WEBPACK_IMPORTED_MODULE_5__["CompanyPageRoutingModule"], ng2_search_filter__WEBPACK_IMPORTED_MODULE_7__["Ng2SearchPipeModule"]],
        declarations: [_company_page__WEBPACK_IMPORTED_MODULE_6__["CompanyPage"]]
      })], CompanyPageModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-company-company-module-es5.js.map